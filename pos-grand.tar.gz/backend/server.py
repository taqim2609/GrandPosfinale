from dotenv import load_dotenv
from pathlib import Path
import os

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

UPLOAD_DIR = Path(os.environ.get('UPLOAD_DIR') or (ROOT_DIR / 'uploads'))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
PROJECT_ROOT = ROOT_DIR.parent

from fastapi import FastAPI, APIRouter, HTTPException, Depends, Request, UploadFile, File, Query, BackgroundTasks
from fastapi.responses import StreamingResponse, FileResponse, Response
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ReturnDocument
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional, Literal
from datetime import datetime, timezone, timedelta
import logging, uuid, io, bcrypt, jwt, asyncio, re, zipfile, math, time, json
from bson import json_util

# ------------------------------------------------------------------ DB
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(
    mongo_url,
    # Pooling koneksi: single-proses backend di Pi; batas wajar + timeout jelas
    # supaya trafik tinggi tidak menguras koneksi Mongo (env bisa di-override).
    maxPoolSize=int(os.environ.get("MONGO_MAX_POOL_SIZE", "30")),
    minPoolSize=int(os.environ.get("MONGO_MIN_POOL_SIZE", "1")),
    maxIdleTimeMS=int(os.environ.get("MONGO_MAX_IDLE_MS", "60000")),
    serverSelectionTimeoutMS=int(os.environ.get("MONGO_SERVER_SELECTION_TIMEOUT_MS", "5000")),
    connectTimeoutMS=int(os.environ.get("MONGO_CONNECT_TIMEOUT_MS", "5000")),
)
db = client[os.environ['DB_NAME']]

JWT_SECRET = os.environ['JWT_SECRET']
JWT_ALG = "HS256"
EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY')
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY')
GEMINI_TEXT_MODEL = os.environ.get('GEMINI_MODEL', 'gemini-2.5-flash')
GEMINI_IMAGE_MODEL = os.environ.get('GEMINI_IMAGE_MODEL', 'gemini-2.5-flash-image')
OPENAI_COMPAT_BASE_URL = os.environ.get('OPENAI_COMPAT_BASE_URL')
OPENAI_COMPAT_API_KEY = os.environ.get('OPENAI_COMPAT_API_KEY')
OPENAI_COMPAT_MODEL = os.environ.get('OPENAI_COMPAT_MODEL') or 'gpt-4o-mini'
CHENZK_BASE_URL = "https://chenzk.top/v1"  # default base url provider "chenzk" (ezkielyna.store)
GEMINI_REST_URL = "https://generativelanguage.googleapis.com/v1beta/models"

# ---- Rotasi otomatis API key Gemini ----
# Daftar key dari DB (settings.ai.gemini_keys) + env GEMINI_API_KEY sebagai cadangan.
# Bila satu key kena limit harian (429/403/quota), otomatis coba key berikutnya.
_gemini_cursor = {"i": 0}

async def _gemini_keys(extra=None):
    doc = await db.settings.find_one({"_id": "ai"}) or {}
    keys = []
    seen = set()
    if extra:
        e = (extra or "").strip()
        if e:
            keys.append(e); seen.add(e)
    for k in (doc.get("gemini_keys") or []):
        k = (k or "").strip()
        if k and k not in seen:
            keys.append(k); seen.add(k)
    if GEMINI_API_KEY and GEMINI_API_KEY not in seen:
        keys.append(GEMINI_API_KEY)
    return keys

def _rotate_quota(status, text):
    t = (text or "").lower()
    return status in (429, 403) or (status == 400 and any(
        w in t for w in ("quota", "limit", "api key", "permission", "invalid key", "resource exhausted")))

app = FastAPI(title="Grand Aceh Kuliner POS")
api = APIRouter(prefix="/api")
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("gak-pos")

PRODUCT_TYPES = ["makanan", "minuman", "retail"]
ORDER_TYPES = ["dine_in", "take_away", "retail"]

def now_utc():
    return datetime.now(timezone.utc)

WIB = timezone(timedelta(hours=7))
LOW_STOCK_THRESHOLD = 10

def wib_today():
    return now_utc().astimezone(WIB).strftime("%Y-%m-%d")

def wib_day_range(date_str):
    """Given a WIB calendar date 'YYYY-MM-DD', return (start_utc_iso, end_utc_iso)."""
    try:
        start = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=WIB)
    except (ValueError, TypeError):
        raise HTTPException(400, f"Tanggal tidak valid: '{date_str}'. Gunakan format YYYY-MM-DD.")
    end = start + timedelta(days=1)
    return start.astimezone(timezone.utc).isoformat(), end.astimezone(timezone.utc).isoformat()

def wib_day_of(iso_str):
    return datetime.fromisoformat(iso_str).astimezone(WIB).strftime("%Y-%m-%d")

def new_id():
    return str(uuid.uuid4())

def _order_pay_parts(o):
    """Bagian pembayaran order: 2 metode (payment_splits) atau 1 metode lama.
    Return [(nama, tipe, jumlah)]."""
    sp = o.get("payment_splits")
    if sp:
        out = []
        for x in sp:
            if not isinstance(x, dict):
                continue
            try:
                amt = round(float(x.get("amount") or 0), 2)
            except (TypeError, ValueError):
                amt = 0.0
            out.append((str(x.get("payment_method_name") or "?"),
                        str(x.get("payment_method_type") or ""), amt))
        return out or [(str(o.get("payment_method_name") or "?"),
                        str(o.get("payment_method_type") or ""), round(float(o.get("total") or 0), 2))]
    return [(str(o.get("payment_method_name") or "?"),
             str(o.get("payment_method_type") or ""), round(float(o.get("total") or 0), 2))]

def _cash_paid(o):
    """Total bagian tunai dari sebuah order (mendukung 2 metode)."""
    return sum(a for _, t, a in _order_pay_parts(o) if t == "cash")

# ------------------------------------------------------------------ Security
def _bcrypt_rounds():
    """Biaya bcrypt (default 11; di Pi cost 12 membuat login 400-900ms+).
    Hash lama dengan cost lain tetap valid (rounds tersimpan di hash)."""
    try:
        return max(8, min(15, int(os.environ.get("BCRYPT_ROUNDS", "11"))))
    except (TypeError, ValueError):
        return 11

def hash_password(p: str) -> str:
    return bcrypt.hashpw(p.encode(), bcrypt.gensalt(rounds=_bcrypt_rounds())).decode()

def verify_password(p: str, h: str) -> bool:
    try:
        return bcrypt.checkpw(p.encode(), h.encode())
    except Exception:
        return False

def create_token(user: dict) -> str:
    payload = {"sub": user["id"], "role": user["role"],
               "email": user.get("email") or user.get("username") or "",
               "exp": now_utc() + timedelta(hours=12), "type": "access"}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

async def get_current_user(request: Request) -> dict:
    auth = request.headers.get("Authorization", "")
    token = auth[7:] if auth.startswith("Bearer ") else request.cookies.get("access_token")
    if not token:
        raise HTTPException(401, "Not authenticated")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Invalid token")
    user = await db.users.find_one({"id": payload["sub"]}, {"_id": 0, "password_hash": 0})
    if not user or not user.get("active", True):
        raise HTTPException(401, "User not found or inactive")
    return user

def _mod_allowed(mod, allowed, path):
    """mod ada di daftar role, ATAU endpoint laporan ringkasan/rentang yang dipakai
    Dashboard boleh diakses role bermodul dashboard (tanpa harus punya modul laporan)."""
    if mod in allowed:
        return True
    if mod == "laporan" and str(path).rstrip("/").endswith(("/reports/summary", "/reports/range")) and "dashboard" in allowed:
        return True
    return False

async def require_admin(request: Request, user: dict = Depends(get_current_user)) -> dict:
    """Admin ATAU role lain yang daftar izinnya (full custom) memuat modul route ini."""
    base, allowed = await _access(user.get("role") or "kasir")
    if base == "admin":
        return user
    mod = _route_module(request)
    route = getattr(getattr(request, "scope", {}), "route", None)
    path = getattr(route, "path", "") or ""
    if mod and _mod_allowed(mod, allowed, path):
        return user
    raise HTTPException(403, "Admin access required")

def require_roles(*roles):
    """Akses menulis utk role dasar tertentu. FULL CUSTOM: bila role tsb dikustomisasi
    (daftar izin penuh), modul route HARUS ada di daftarnya — keanggotaan nama role saja
    tidak lagi otomatis memberi akses modul. Route tanpa pemetaan modul: fallback nama/base."""
    async def _dep(request: Request, user: dict = Depends(get_current_user)) -> dict:
        base, allowed = await _access(user.get("role") or "kasir")
        if base == "admin":
            return user
        mod = _route_module(request)
        if mod:
            route = getattr(getattr(request, "scope", {}), "route", None)
            path = getattr(route, "path", "") or ""
            if _mod_allowed(mod, allowed, path):
                return user
            raise HTTPException(403, "Akses ditolak untuk peran ini (modul tidak diizinkan role ini)")
        if user.get("role") in roles or base in roles:
            return user
        raise HTTPException(403, "Akses ditolak untuk peran ini")
    return _dep

def require_any_module(*mods):
    """Akses bila role admin ATAU daftar izin penuh role memuat salah satu mod yang diminta."""
    async def _dep(request: Request, user: dict = Depends(get_current_user)) -> dict:
        base, allowed = await _access(user.get("role") or "kasir")
        if base == "admin":
            return user
        if any(m in mods for m in allowed):
            return user
        raise HTTPException(403, "Akses ditolak untuk peran ini")
    return _dep

# ================================================================== RBAC DINAMIS
# Role & izin bisa dikustomisasi admin (Pengaturan → Roles & Izin) tanpa mengubah kode:
#   - role bawaan: admin (super), kasir, input — masing-masing punya modul dasar.
#   - role kustom: admin bisa membuat role baru dengan role dasar kasir/input + izin ekstra.
#   - izin = per MODUL; server memeriksa modul route (dari request.scope["route"].path)
#     lalu membandingkan dengan daftar izin role tsb. Data disimpan di settings._id="rbac".
BUILTIN_ROLES = ("superadmin", "admin", "kasir", "input", "input_pembayaran", "stok_opname")
RBAC_BASE_MODULES = {
    "superadmin": None,  # pemilik (owner) — semua modul
    "admin": None,  # None = semua modul
    "kasir": {"dashboard", "pos", "pengeluaran", "shift", "laporan", "ai", "reservasi"},
    "input": {"dashboard", "produk"},
    # Input Pembayaran: khusus mencatat pembayaran/pengeluaran kas
    "input_pembayaran": {"dashboard", "pengeluaran"},
    # Stok Opname: hitung stok bahan & produk retail (tanpa hak ubah master produk)
    "stok_opname": {"dashboard", "produk", "opname_bahan", "opname_produk"},
}
RBAC_MODULE_LABELS = {
    "dashboard": "Dashboard",
    "pos": "POS Kasir",
    "pengeluaran": "Pengeluaran & Kas",
    "shift": "Shift",
    "laporan": "Laporan",
    "ai": "AI / Asisten",
    "reservasi": "Reservasi Meja",
    "produk": "Produk, Kategori & Stok",
    "member": "Member & Poin",
    "promo": "Promo",
    "resep": "Resep & HPP",
    "kupon": "Kupon",
    "meja": "Manajemen Meja",
    "transaksi": "Riwayat Transaksi",
    "vendor": "Vendor",
    "pengguna": "Kelola Pengguna",
    "whatsapp": "WhatsApp",
    "pengaturan": "Pengaturan Aplikasi/Platform",
    "belanja_bahan": "Pembelian Bahan & Daftar Belanja",
    "opname_bahan": "Stok Opname Bahan",
    "belanja_produk": "Belanja / Pembelian Produk Retail",
    "opname_produk": "Stok Opname Produk Retail",
    "superadmin": "Super Admin (Kelola Role & Izin)",
}
RBAC_PATH_MODULE = {
    "products": "produk", "categories": "produk", "inventory": "produk",
    "products/opname-bulk": "opname_produk", "products/{pid}/opname": "opname_produk",
    "purchases": "belanja_produk", "purchases/bulk": "belanja_produk", "stock-opname": "opname_produk",
    "recipes": "resep", "members": "member", "promos": "promo", "coupons": "kupon",
    "tables": "meja", "reservations": "reservasi", "orders": "transaksi",
    "vendors": "vendor", "users": "pengguna", "whatsapp": "whatsapp",
    "reports": "laporan", "ai": "ai", "shifts": "shift", "cash": "pengeluaran",
    "custom-widgets": "pengaturan", "settings": "pengaturan", "admin": "pengaturan",
    "update": "pengaturan", "rbac": "pengaturan", "features": "pengaturan",
    # Bahan: jalur per-aksi dipetakan ke izin granular (fallback = "produk" utk master).
    "ingredients/{iid}/purchase": "belanja_bahan",
    "ingredients/{iid}/opname": "opname_bahan",
    "ingredients": "produk", "ingredient-purchases": "belanja_bahan",
    "ingredient-opname": "opname_bahan", "shopping-list": "belanja_bahan",
}
_rbac_cache = {"at": 0.0, "roles": None}

async def _rbac_doc(force=False):
    if force or _rbac_cache["roles"] is None or time.time() - _rbac_cache["at"] > 6:
        doc = await db.settings.find_one({"_id": "rbac"}, {"_id": 0}) or {}
        _rbac_cache["roles"] = doc.get("roles") or {}
        _rbac_cache["at"] = time.time()
    return _rbac_cache["roles"]

async def _access(role):
    """(role_dasar, set modul yang BOLEH diakses) — daftar PENUH (full custom).

    - admin                : semua modul (super).
    - Role dgn flag full:1 : persis daftar `perms` yang disimpan admin
                            (boleh kosong = role tanpa akses operasional).
    - Tanpa flag full      : migrasi lama → modul dasar role + izin ekstra lama,
                            supaya pengaturan sebelum fitur ini tetap berlaku.
    """
    role = str(role or "kasir")
    rbac = await _rbac_doc()
    info = rbac.get(role)
    if role == "superadmin" or (info and info.get("base") == "superadmin"):
        return "admin", _base_modules("superadmin")
    if role == "admin" or (info and info.get("base") == "admin" and not info.get("full")):
        return "admin", _base_modules("admin")
    if role in BUILTIN_ROLES:
        if info and info.get("full"):
            return role, set(info.get("perms") or [])
        dflt = _base_modules(role) | set(info.get("perms") or []) if info else _base_modules(role)
        return role, dflt
    if info:
        base = info.get("base") if info.get("base") in BUILTIN_ROLES else "kasir"
        if info.get("full"):
            return base, set(info.get("perms") or [])
        dflt = _base_modules(base) | set(info.get("perms") or [])
        return base, dflt
    return "kasir", _base_modules("kasir")

def _route_module(request):
    """Modul (izin) untuk request saat ini berdasarkan route yang cocok."""
    route = getattr(getattr(request, "scope", {}), "route", None)
    path = getattr(route, "path", "") or ""
    segs = [s for s in path.split("/") if s]
    if segs and segs[0] == "api":
        segs = segs[1:]
    if not segs:
        return None
    # /orders dipakai POS (kasir) & riwayat transaksi (admin) — bedakan per METHOD
    if segs[0] == "orders":
        m = (getattr(request, "method", "") or "GET").upper()
        if len(segs) == 1 and m == "POST":
            return "pos"                      # buat order di POS
        if len(segs) >= 2 and segs[-1] in ("items", "pay") and m in ("PATCH", "POST"):
            return "pos"                      # edit keranjang / bayar di POS
        return "transaksi"
    # izin granular utk aksi bahan per-bahan (purchase/opname) sebelum fallback induk
    if len(segs) >= 3 and "/".join(segs[:3]) in RBAC_PATH_MODULE:
        return RBAC_PATH_MODULE["/".join(segs[:3])]
    if len(segs) >= 2 and "/".join(segs[:2]) in RBAC_PATH_MODULE:
        return RBAC_PATH_MODULE["/".join(segs[:2])]
    return RBAC_PATH_MODULE.get(segs[0])

def _owner_identifiers():
    """Identitas akun pemilik (owner) dari env: ADMIN_EMAIL dan username turunannya."""
    email = (os.environ.get("ADMIN_EMAIL") or "").strip().lower()
    if not email:
        return set()
    return {email, email.split("@")[0]}

async def _is_super(role_or_user):
    """True bila: role bawaan 'superadmin', role kustom dgn dasar superadmin,
    ATAU akun itu sendiri adalah AKUN OWNER (ADMIN_EMAIL) — jaring pengaman supaya
    pemilik tidak pernah terkunci dari Pengaturan → Roles & Izin meskipun kolom
    role di database belum/tidak berisi superadmin."""
    role = role_or_user
    if isinstance(role_or_user, dict):
        ident = _owner_identifiers()
        if ident:
            uname = str(role_or_user.get("username") or "").lower()
            mail = str(role_or_user.get("email") or "").lower()
            if uname and uname in ident:
                return True
            if mail and mail in ident:
                return True
        role = role_or_user.get("role")
    role = str(role or "")
    if role == "superadmin":
        return True
    info = (await _rbac_doc()).get(role)
    return bool(info and info.get("base") == "superadmin")

async def _no_superadmin_exists():
    return not await db.users.find_one({"role": "superadmin"}, {"_id": 1})

# Jejak transaksi per-akun (dipakai aturan hapus akun: yang sudah punya riwayat hanya
# boleh DINONAKTIFKAN, tidak boleh dihapus permanen).
USER_HISTORY_COLLECTIONS = (
    ("orders", "cashier_id", "pesanan"),
    ("shifts", "cashier_id", "shift"),
    ("cash_movements", "cashier_id", "kas masuk/keluar"),
    ("audit_logs", "by_id", "catatan audit"),
)

async def _user_history(uid):
    counts, total = {}, 0
    for coll, field, label in USER_HISTORY_COLLECTIONS:
        try:
            n = await getattr(db, coll).count_documents({field: uid})
        except Exception:
            n = 0
        if n:
            counts[label] = n
            total += n
    return {"has_history": total > 0, "total": total, "counts": counts}

async def _super_accounts_count():
    """Jumlah akun Super Admin (termasuk akun owner dari env ADMIN_EMAIL)."""
    n = 0
    async for u in db.users.find({}, {"_id": 0, "role": 1, "email": 1, "username": 1}):
        if await _is_super(u):
            n += 1
    return n

async def _can_manage_roles(user):
    """Boleh mengatur Role & Izin bila: super admin/owner, ATAU (mode bootstrap)
    BELUM ADA superadmin sama sekali dan user ini admin — supaya pemilik tidak
    pernah terkunci permanen dari menu Roles & Izin."""
    if await _is_super(user):
        return True
    if str(user.get("role") or "") in ("admin", "superadmin") and await _no_superadmin_exists():
        return True
    return False

async def require_superadmin(user: dict = Depends(get_current_user)) -> dict:
    """Endpoint pengaturan Role & Izin — Super Admin/owner (atau mode bootstrap)."""
    if not await _can_manage_roles(user):
        raise HTTPException(403, "Hanya Super Admin (owner) yang boleh mengatur role & izin")
    return user

@api.post("/settings/rbac/claim-superadmin")
async def claim_superadmin(user: dict = Depends(require_admin)):
    """Angkat akun pemanggil menjadi Super Admin — HANYA bila belum ada Super Admin
    sama sekali (pemulihan mandiri saat owner terkunci)."""
    if await _is_super(user):
        return {"ok": True, "already": True, "role": user.get("role")}
    if not await _no_superadmin_exists():
        raise HTTPException(403, "Sudah ada Super Admin — minta Super Admin menaikkan role akun Anda di Pengaturan → Roles & Izin")
    await db.users.update_one({"id": user["id"]}, {"$set": {"role": "superadmin"}})
    logger.info(f"bootstrap: akun {user.get('username')} diangkat menjadi superadmin")
    return {"ok": True, "role": "superadmin"}

def _base_modules(base):
    """Daftar modul yang memang sudah dimiliki sebuah role dasar (bawaan)."""
    m = RBAC_BASE_MODULES.get(base)
    if m is None:
        return set(RBAC_MODULE_LABELS.keys())
    return set(m)

async def _valid_role_name(role):
    """Role valid = bawaan ATAU role kustom yang tersimpan di settings rbac."""
    if role in BUILTIN_ROLES:
        return role
    rbac = await _rbac_doc()
    return role if role in rbac else None

async def _user_view(u):
    """Tambahan role_base & perms utk dipakai frontend (gating menu/halaman).
    perms = daftar PENUH modul yang boleh diakses (full custom) — frontend tinggal cek
    include. Selalu buang _id (ObjectId tak serializable) & password_hash."""
    base, perms = await _access(u.get("role") or "kasir")
    role = u.get("role") or "kasir"
    info = (await _rbac_doc()).get(role)
    full = bool(info and info.get("full"))
    # password_plain = password terlihat (hanya Super Admin, lihat GET /users) — JANGAN
    # pernah ikut di respons /auth/me & /auth/login.
    out = {k: v for k, v in u.items() if k not in ("_id", "password_hash", "password_plain")}
    out["role_base"] = base
    out["perms_full"] = full or base == "admin"
    out["perms"] = sorted(perms)
    out["is_superadmin"] = await _can_manage_roles(u)
    out["bootstrap_owner"] = (not out["is_superadmin"]) and str(u.get("role")) == "admin" and await _no_superadmin_exists()
    out["username"] = u.get("username") or ""
    out["email"] = u.get("email") or ""
    # Wajib ganti password saat login pertama (mis. role Stok Opname) — dibaca frontend
    # di ProtectedRoute untuk menahan akses sampai password diganti.
    out["must_change_password"] = bool(u.get("must_change_password"))
    return out

@api.get("/rbac/my")
async def my_rbac(user: dict = Depends(get_current_user)):
    uv = await _user_view(user)
    return {"role": user.get("role"), "role_base": uv["role_base"],
            "perms_full": uv["perms_full"], "perms": uv["perms"],
            "is_superadmin": uv["is_superadmin"],
            # batas role yang boleh dibuat/ditugaskan admin (ditentukan Super Admin)
            "assignable": sorted(await _assignable_roles()) if not uv["is_superadmin"] else []}

@api.get("/settings/rbac")
async def get_rbac(admin: dict = Depends(require_superadmin)):
    roles = await _rbac_doc(force=True)
    doc = await db.settings.find_one({"_id": "rbac"}, {"_id": 0}) or {}
    rbac_roles = doc.get("roles") or {}
    default_assignable = [r for r in BUILTIN_ROLES if r not in ("superadmin", "admin")] + \
                        [r for r in rbac_roles if r not in BUILTIN_ROLES]
    return {
        "roles": roles,
        "modules": [{"code": k, "label": v} for k, v in RBAC_MODULE_LABELS.items()],
        "base_defaults": {r: sorted(_base_modules(r)) for r in BUILTIN_ROLES},
        "builtin": list(BUILTIN_ROLES),
        # role yang boleh DIBUAT/DITUGASKAN oleh admin biasa (ditentukan super admin)
        "assignable": doc.get("assignable") if isinstance(doc.get("assignable"), list) else default_assignable,
    }

@api.put("/settings/rbac")
async def put_rbac(body: dict, admin: dict = Depends(require_superadmin)):
    """Simpan matriks role & izin. Body: {"roles": {nama_role: {base?, perms[]}}}.
    Role yang dihapus → penggunanya dikembalikan ke role dasar."""
    incoming = body.get("roles") if isinstance(body.get("roles"), dict) else {}
    old = await _rbac_doc(force=True)
    new = {}
    for name, info in incoming.items():
        if not isinstance(info, dict):
            continue
        name = str(name).strip()
        if not name or len(name) > 30:
            continue
        base = str(info.get("base") or "kasir")
        if base not in ("admin", "kasir", "input"):
            continue
        if name == "admin":
            continue  # admin = super, tidak bisa diedit
        # FULL CUSTOM: perms = daftar PENUH modul yang boleh diakses role ini
        perms = set()
        rawp = info.get("perms") if isinstance(info.get("perms"), list) else []
        for p in rawp:
            if p in RBAC_MODULE_LABELS:
                perms.add(str(p))
        entry = {"base": base, "perms": sorted(perms), "full": True}
        new[name] = entry
    # hapus role yang tidak ada lagi
    removed = [r for r in old if r not in new and r not in BUILTIN_ROLES]
    for r in removed:
        base = (old[r] or {}).get("base") or "kasir"
        await db.users.update_many({"role": r}, {"$set": {"role": base}})
    upd = {"roles": new}
    if isinstance(body.get("assignable"), list):
        known = set(new.keys()) | set(BUILTIN_ROLES)
        assignable = [str(x) for x in body["assignable"] if str(x) in known and str(x) != "superadmin"]
        upd["assignable"] = assignable
    await db.settings.update_one({"_id": "rbac"}, {"$set": upd}, upsert=True)
    await _rbac_doc(force=True)
    return {"ok": True, "roles": new, "assignable": upd.get("assignable")}

async def _assignable_roles():
    """Daftar role yang boleh dibuat/ditugaskan admin biasa (super admin yg menentukan)."""
    doc = await db.settings.find_one({"_id": "rbac"}, {"_id": 0}) or {}
    if isinstance(doc.get("assignable"), list) and doc["assignable"]:
        return set(str(x) for x in doc["assignable"])
    rbac_roles = doc.get("roles") or {}
    return set([r for r in BUILTIN_ROLES if r not in ("superadmin", "admin")] +
               [r for r in rbac_roles if r not in BUILTIN_ROLES])

class RoleAssignIn(BaseModel):
    role: str

admin_or_input = require_roles("admin", "input")
admin_or_kasir = require_roles("admin", "kasir")

# ------------------------------------------------------------------ Models
class LoginIn(BaseModel):
    # Akun tanpa email: login memakai USERNAME. `email` tetap diterima agar
    # aplikasi/APK versi lama (yang mengirim email) tidak langsung rusak.
    username: Optional[str] = None
    email: Optional[str] = None
    password: str

    def ident(self) -> str:
        return str(self.username or self.email or "").strip().lower()

class UserCreate(BaseModel):
    name: str
    username: str
    password: str
    role: str = "kasir"
    # None = bawaan (True: semua akun baru wajib ganti password saat login pertama),
    # bisa dimatikan per akun lewat PATCH /users/{uid}/must-change-password.
    must_change_password: Optional[bool] = None

class ChangePasswordIn(BaseModel):
    current_password: str
    new_password: str

class ResetPasswordIn(BaseModel):
    new_password: str
    must_change_password: Optional[bool] = None

class MustChangePasswordIn(BaseModel):
    value: bool

class ResetDataIn(BaseModel):
    scope: Literal["transactions", "all"]
    password: str

class CategoryIn(BaseModel):
    name: str
    type: Literal["makanan", "minuman", "retail", "vendor"]
    sort_order: int = 0
    active: bool = True

class ProductIn(BaseModel):
    name: str
    sku: str
    category_id: str
    type: Literal["makanan", "minuman", "retail", "vendor"]
    price: float
    cost: float = 0
    vendor_id: Optional[str] = None
    vendor_share_percent: Optional[float] = None
    description: Optional[str] = ""
    image: Optional[str] = ""
    active: bool = True
    sold_out: bool = False
    stock: Optional[int] = 0
    min_stock: Optional[int] = 10
    weight_sale: bool = False   # jual per berat (F&B): harga per satuan berat
    weight_unit: str = ""       # satuan berat: ons / gram / kg / porsi

class VendorIn(BaseModel):
    name: str
    contact: Optional[str] = ""
    note: Optional[str] = ""
    active: bool = True

class TableIn(BaseModel):
    name: str
    area: str = "Umum"
    capacity: int = 4
    active: bool = True

class ReservationIn(BaseModel):
    table_id: str
    customer_name: str
    phone: str = ""
    pax: int = Field(default=1, ge=1)
    date: str = ""          # YYYY-MM-DD
    time: str = ""          # HH:MM
    note: str = ""

class ReservationUpdateIn(BaseModel):
    status: Optional[Literal["pending", "confirmed", "arrived", "cancelled", "done"]] = None
    pax: Optional[int] = Field(default=None, ge=1)
    note: Optional[str] = None

class RecipeIn(BaseModel):
    product_id: str
    ingredients: List[dict] = []   # [{product_id (bahan), qty, unit?}]
    yield_units: float = 1         # berapa unit hasil produksi

class RecipeIngredientIn(BaseModel):
    product_id: str
    qty: float = Field(gt=0)
    unit: str = ""

class PaymentMethodIn(BaseModel):
    name: str
    type: Literal["cash", "qris", "card"]
    active: bool = True

class OrderItem(BaseModel):
    product_id: str
    name: Optional[str] = ""
    price: Optional[float] = 0
    qty: int = Field(gt=0)
    type: Optional[str] = ""
    weight: Optional[float] = None   # berat (untuk produk jual-per-berat)

class CouponIn(BaseModel):
    code: str
    type: Literal["percent", "amount"]
    value: float = Field(ge=0)
    max_uses: int = Field(default=0, ge=0)   # 0 = tak terbatas
    expires_at: Optional[str] = ""            # YYYY-MM-DD
    active: bool = True

class OrderIn(BaseModel):
    order_type: Literal["dine_in", "take_away", "retail"]
    table_id: Optional[str] = None
    items: List[OrderItem]
    discount_type: Literal["none", "percent", "amount"] = "none"
    discount_value: float = Field(0, ge=0)
    note: Optional[str] = ""
    pay_now: bool = False
    payment_method: Optional[str] = None
    amount_paid: Optional[float] = None   # utk bayar langsung (pay_now) sekali request
    client_ref: Optional[str] = None
    member_id: Optional[str] = None
    redeem_points: float = 0
    discount_reason: Optional[str] = None
    coupon_code: Optional[str] = None
    splits: Optional[List[dict]] = None  # 2 metode sekaligus: [{payment_method, amount}]

class ItemsUpdate(BaseModel):
    items: List[OrderItem]

class PayIn(BaseModel):
    payment_method: str
    discount_type: Literal["none", "percent", "amount"] = "none"
    discount_value: float = Field(0, ge=0)
    amount_paid: Optional[float] = None
    member_id: Optional[str] = None
    redeem_points: float = 0
    discount_reason: Optional[str] = None
    coupon_code: Optional[str] = None
    payment_ref: Optional[str] = None   # kunci idempotensi: retry jaringan yg sama tidak menggandakan pembayaran
    splits: Optional[List[dict]] = None  # 2 metode sekaligus: [{payment_method, amount}]

class VoidIn(BaseModel):
    reason: str
    action: Literal["void", "refund"] = "void"

class ShiftOpenIn(BaseModel):
    opening_cash: float = 0

class ShiftCloseIn(BaseModel):
    closing_cash: float = 0
    vendor_payments: Optional[List[dict]] = None  # [{vendor_id, paid}]

class AIDescIn(BaseModel):
    name: str
    type: str
    category: Optional[str] = ""
    keywords: Optional[str] = ""

class AIImageIn(BaseModel):
    name: str
    description: Optional[str] = ""

class AISummaryIn(BaseModel):
    date: Optional[str] = None

# ------------------------------------------------------------------ helpers
def compute_totals(items, discount_type, discount_value):
    subtotal = sum(i["price"] * i["qty"] for i in items)
    discount_value = max(0, discount_value)
    if discount_type == "percent":
        discount = round(subtotal * (min(discount_value, 100) / 100.0), 2)
    elif discount_type == "amount":
        discount = min(discount_value, subtotal)
    else:
        discount = 0
    total = max(0, round(subtotal - discount, 2))
    return round(subtotal, 2), round(discount, 2), total

async def _apply_coupon(code, subtotal):
    """Validasi kupon & hitung diskon. Pemakaian (used_count) dihitung di _finalize_payment
    saat transaksi benar-benar lunas (agar retry/gagal bayar tidak menghabiskan kuota)."""
    if not code or not code.strip():
        return 0.0, ""
    c = await db.coupons.find_one({"code": code.strip().upper()}, {"_id": 0})
    if not c:
        raise HTTPException(400, f"Kupon '{code}' tidak ditemukan")
    if not c.get("active", True):
        raise HTTPException(400, f"Kupon '{c['code']}' sudah nonaktif")
    max_uses = int(c.get("max_uses") or 0)
    if max_uses > 0 and int(c.get("used_count") or 0) >= max_uses:
        raise HTTPException(400, f"Kupon '{c['code']}' sudah habis dipakai")
    exp = (c.get("expires_at") or "").strip()
    if exp and exp < wib_today():
        raise HTTPException(400, f"Kupon '{c['code']}' sudah kedaluwarsa")
    value = float(c.get("value") or 0)
    if c["type"] == "percent":
        d = round(subtotal * (min(value, 100) / 100.0), 2)
    else:
        d = min(value, subtotal)
    d = round(d, 2)
    return d, c["code"]

# ================================================================== PROMO & MEMBER (fitur baru)
async def _active_promos():
    return await db.promos.find({"active": True}, {"_id": 0}).to_list(100)

async def _apply_promos(items, subtotal, now=None):
    """Hitung diskon otomatis dari promo aktif. Return (promo_discount, [nama_promo])."""
    now = now or datetime.now(WIB)
    t = now.strftime("%H:%M")
    wd = now.weekday()  # 0=Senin..6=Minggu
    names = []
    d = 0.0
    for p in await _active_promos():
        try:
            days = p.get("days") or []
            if days and wd not in days:
                continue
            ptype = p.get("type")
            if ptype in ("percent", "happy_hour"):
                if ptype == "happy_hour":
                    st, en = p.get("start_time", ""), p.get("end_time", "")
                    if not (st and en) or not (st <= t <= en):
                        continue
                pct = min(float(p.get("value") or 0), 100)
                d += round(subtotal * pct / 100.0, 2)
                names.append(p.get("name"))
            elif ptype == "min_spend":
                if subtotal >= float(p.get("value") or 0):
                    bonus = float(p.get("bonus") or 0)
                    d += min(bonus, subtotal)
                    names.append(p.get("name"))
            elif ptype == "package":
                # paket: semua produk dalam paket harus ada di keranjang (cocokkan nama)
                pkg = p.get("package_items") or []
                ok = True
                for need in pkg:
                    nm = (need.get("product_name") or "").lower().strip()
                    q = int(need.get("qty") or 1)
                    if nm:
                        have = sum(i["qty"] for i in items if (i["name"] or "").lower().strip() == nm)
                        if have < q:
                            ok = False
                            break
                if ok:
                    bundle = float(p.get("value") or 0)
                    normal = 0.0
                    for need in pkg:
                        nm = (need.get("product_name") or "").lower().strip()
                        q = int(need.get("qty") or 1)
                        for i in items:
                            if (i["name"] or "").lower().strip() == nm:
                                normal += i["price"] * q
                                break
                    d += max(0.0, normal - bundle)
                    names.append(p.get("name"))
            elif ptype == "bogo":
                # beli N gratis 1 (produk sama, unit paling murah dihitung)
                buy = int(p.get("value") or 2)
                for it in items:
                    if it["qty"] >= buy + 1:
                        free = it["price"]
                        d += min(free, subtotal)
                        names.append(p.get("name"))
                        break
        except Exception:
            continue
    promo_discount = min(d, subtotal)
    return round(promo_discount, 2), names

# ================================================================== PENGATURAN APLIKASI (admin, tanpa kode)
BIZ_DEFAULTS = {
    "order_prefix": "GAK-",
    "labels": {"fnb": "F&B", "retail": "Retail"},
    "discount_reason_percent": 15,
    "discount_reason_amount": 50000,
    "member_earn_per_rupiah": 10000,   # 1 poin per RpX belanja
    "member_redeem_per_point": 100,     # 1 poin = RpX
    "low_stock_threshold": 10,
    "service_tax_percent": 0,           # pajak layanan opsional (%)
}

async def _business():
    if await _feat("perf.cache_master"):
        hit = _cache_get("biz")
        if hit is not None:
            return hit
    doc = await db.settings.find_one({"_id": "business"}, {"_id": 0}) or {}
    out = {}
    for k, v in BIZ_DEFAULTS.items():
        if k == "labels":
            out[k] = {**BIZ_DEFAULTS["labels"], **(doc.get("labels") or {})}
        else:
            out[k] = doc.get(k, v)
    if await _feat("perf.cache_master"):
        _cache_set("biz", out, 8.0)
    return out

async def _biz_val(key):
    return (await _business()).get(key)

# ================================================================== FEATURE FLAGS & OPS TERPUSAT (admin, tanpa deploy)
# Semua fitur berat/eksternal punya saklar di sini (default ON = perilaku lama).
# Dokumen: db.settings._id = "features". Dokumentasi: docs/ANALISIS-FITUR-PRIORITAS.md.
FEATURE_DEFAULTS = {
    "ai": {"enabled": True, "summary": True, "vision": True, "description": True, "image": True, "assistant": True},
    "wa": {"enabled": True},
    "ota": {"autocheck": True},
    "update": {"banner": True},
    "perf": {"cache_master": True, "cache_reports": True},
    "maint": {"orphan_auto": False, "orphan_hour": 4, "orphan_day": 6},  # Minggu 04:00 (0=Senin)
    "webhook": {"enabled": False},
    "dbg": {"slowlog": False, "slowlog_ms": 1500, "metrics": True},
    "guard": {"breaker": True},
}

_feature_mem = {"at": 0.0, "doc": None}
FEATURE_CACHE_TTL = 3.0

def _merge_dict(base, over):
    out = dict(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            out[k] = _merge_dict(base[k], v)
        else:
            out[k] = v
    return out

async def _features():
    """Merge default + tersimpan, dengan cache in-memory singkat (murah dipanggil per-request)."""
    import time as _t
    now = _t.time()
    if _feature_mem["doc"] is not None and (now - _feature_mem["at"]) < FEATURE_CACHE_TTL:
        return _feature_mem["doc"]
    doc = await db.settings.find_one({"_id": "features"}, {"_id": 0}) or {}
    merged = _merge_dict(FEATURE_DEFAULTS, doc)
    _feature_mem.update({"at": now, "doc": merged})
    return merged

async def _feat(path, default=None):
    """Baca satu flag bertitik, mis. _feat('ai.summary'), _feat('perf.cache_master')."""
    cur = await _features()
    for part in str(path).split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return default
    return cur

async def _invalidate_features():
    _feature_mem["doc"] = None

FEATURE_LABELS = {
    "ai": "AI (Master)",
    "ai.summary": "AI — Analisis Laporan",
    "ai.vision": "AI — Baca Faktur (Vision)",
    "ai.description": "AI — Deskripsi Produk",
    "ai.image": "AI — Gambar Produk",
    "ai.assistant": "AI — Asisten",
    "wa": "WhatsApp",
    "ota.autocheck": "Pemeriksaan OTA otomatis (APK)",
    "update.banner": "Banner 'Versi Baru' di Dashboard",
    "perf.cache_master": "Cache data master (produk/kategori/metode)",
    "perf.cache_reports": "Cache laporan harian/periode",
    "maint.orphan_auto": "Cek data yatim otomatis (Minggu 04:00)",
    "dbg.slowlog": "Log query lambat",
    "dbg.metrics": "Statistik performa endpoint",
    "guard.breaker": "Circuit breaker layanan luar (WA/AI/update)",
}

async def _ai_allowed(feature):
    """True bila AI master ON dan fitur AI tsb ON."""
    if not await _feat("ai.enabled"):
        return False
    return bool(await _feat(f"ai.{feature}", True))

# ---- Cache in-memory sederhana (master data + laporan; TTL pendek) -------------
_CACHE = {}          # key -> (expires, value)
_RCACHE = {}         # laporan: key -> (gen, expires, value)
_RS_GEN = 0          # bertambah saat data order berubah -> laporan ter-cache invalid

def _cache_get(key):
    e = _CACHE.get(key)
    if e is None:
        return None
    if e[0] < __import__("time").time():
        _CACHE.pop(key, None)
        return None
    return e[1]

def _cache_set(key, value, ttl=20.0):
    import time as _t
    _CACHE[key] = (_t.time() + ttl, value)

def _cache_del(prefix=""):
    for k in [k for k in _CACHE if k.startswith(prefix)]:
        _CACHE.pop(k, None)

def _rcache_get(key):
    import time as _t
    e = _RCACHE.get(key)
    if e is None:
        return None
    gen, exp, val = e
    if gen != _RS_GEN or exp < _t.time():
        _RCACHE.pop(key, None)
        return None
    return val

def _rcache_set(key, value, ttl=3600.0):
    import time as _t
    _RCACHE[key] = (_RS_GEN, _t.time() + ttl, value)

def _bump_rs_gen():
    global _RS_GEN
    _RS_GEN += 1

async def _cached(key, ttl, builder, flag="perf.cache_master"):
    """Generic read-through cache. Flag mati -> selalu bangun ulang."""
    if await _feat(flag):
        hit = _cache_get(key)
        if hit is not None:
            return hit
        val = await builder()
        _cache_set(key, val, ttl)
        return val
    return await builder()

# ---- Circuit breaker layanan eksternal (WA/AI/update center) -------------------
_BREAKERS = {}       # name -> {"fails": int, "open_until": float}
_BREAK_MAX_FAILS = 3
_BREAK_COOLDOWN = 30.0

async def _breaker_check(name):
    if not await _feat("guard.breaker"):
        return
    b = _BREAKERS.get(name)
    if not b:
        return
    import time as _t
    if b["open_until"] and _t.time() < b["open_until"]:
        raise HTTPException(503, f"Layanan {name} sedang gangguan — dicoba lagi otomatis beberapa saat lagi.")
    if b["open_until"]:  # masa cooldown habis -> setengah terbuka, reset
        _BREAKERS[name] = {"fails": 0, "open_until": 0.0}

def _breaker_success(name):
    b = _BREAKERS.get(name)
    if b:
        b["fails"] = 0
        b["open_until"] = 0.0

def _breaker_fail(name):
    import time as _t
    b = _BREAKERS.setdefault(name, {"fails": 0, "open_until": 0.0})
    b["fails"] += 1
    if b["fails"] >= _BREAK_MAX_FAILS:
        b["open_until"] = _t.time() + _BREAK_COOLDOWN
        logger.warning(f"circuit breaker '{name}' terbuka selama {_BREAK_COOLDOWN}s ({b['fails']} gagal berturut-turut)")

def _breaker_status():
    import time as _t
    out = {}
    for name, b in _BREAKERS.items():
        out[name] = {"open": bool(b.get("open_until") and b["open_until"] > _t.time()),
                     "fails": b.get("fails", 0)}
    return out

# ---- Metrik endpoint & slow query log (ring buffer in-memory) ------------------
_PROC_START = __import__("time").time()
_METRICS = {"total": 0, "errors": 0, "total_ms": 0.0, "by_path": {}, "slow": []}

async def _slowlog_threshold():
    try:
        return float(await _feat("dbg.slowlog_ms") or 1500)
    except Exception:
        return 1500.0

def _metric_record(method, path, ms, status):
    import time as _t
    m = _METRICS
    m["total"] += 1
    m["total_ms"] += ms
    if status >= 400:
        m["errors"] += 1
    seg = path.split("/api/")[-1].split("/")[0] if "/api/" in path else path
    key = f"{method} /api/{seg}"
    p = m["by_path"].setdefault(key, {"count": 0, "ms": 0.0, "errors": 0})
    p["count"] += 1
    p["ms"] += ms
    if status >= 400:
        p["errors"] += 1

async def _record_slow_if_needed(method, path, ms):
    try:
        if not await _feat("dbg.slowlog"):
            return
        thr = await _slowlog_threshold()
        if ms >= thr:
            _METRICS["slow"].append({"at": datetime.now(WIB).strftime("%H:%M:%S"),
                                     "method": method, "path": path, "ms": round(ms, 0)})
            _METRICS["slow"] = _METRICS["slow"][-20:]
            logger.warning(f"SLOW {method} {path} {ms:.0f}ms")
    except Exception:
        pass

# ---- Webhook keluar (integrasi pihak ketiga) -----------------------------------
WEBHOOK_DEFAULTS = {"enabled": False, "url": "", "secret": "", "events": [], "last": None}

async def _webhook_cfg():
    doc = await db.settings.find_one({"_id": "webhook"}, {"_id": 0}) or {}
    out = dict(WEBHOOK_DEFAULTS)
    for k in out:
        if k in doc:
            out[k] = doc[k]
    return out

def _webhook_sign(body: bytes, secret: str):
    import hmac, hashlib
    if not secret:
        return ""
    return "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()

async def _fire_webhook(event, payload, force=False):
    """Kirim event ke URL webhook (fire-and-forget). Catat status terakhir di settings."""
    import httpx
    try:
        cfg = await _webhook_cfg()
        if not (cfg.get("url") or "").strip():
            return
        if not force and not (cfg.get("enabled") and event in (cfg.get("events") or [])):
            return
        url = str(cfg.get("url") or "").strip()
        body = {"event": event, "at": now_utc().isoformat(), "data": payload}
        raw = __import__("json").dumps(body, ensure_ascii=False, default=str).encode("utf-8")
        sig = _webhook_sign(raw, str(cfg.get("secret") or ""))
        headers = {"Content-Type": "application/json"}
        if sig:
            headers["X-Gak-Webhook-Signature"] = sig
        try:
            async with httpx.AsyncClient(timeout=6) as c:
                r = await c.post(url, content=raw, headers=headers)
            ok = r.status_code < 400
            last = {"ok": ok, "event": event, "at": now_utc().isoformat(),
                    "status": r.status_code, "error": "" if ok else r.text[:200]}
        except Exception as e:
            last = {"ok": False, "event": event, "at": now_utc().isoformat(), "status": 0, "error": str(e)[:200]}
        await db.settings.update_one({"_id": "webhook"}, {"$set": {"last": last}}, upsert=True)
    except Exception as e:
        logger.error(f"webhook {event} gagal: {e}")

# ---- Pemeriksaan data yatim (orphan records) -----------------------------------
async def _run_orphan_check():
    """Cek referensi putus antar koleksi. Aman: read-only, proyeksi minimal."""
    cat_ids = {c["id"] for c in await db.categories.find({}, {"id": 1}).to_list(5000)}
    prod_ids = {p["id"] for p in await db.products.find({}, {"id": 1}).to_list(20000)}
    prod_by_id = {p["id"]: p for p in await db.products.find({}, {"id": 1, "name": 1, "category_id": 1, "vendor_id": 1}).to_list(20000)}
    ven_ids = {v["id"] for v in await db.vendors.find({}, {"id": 1}).to_list(2000)}
    tab_ids = {t["id"] for t in await db.tables.find({}, {"id": 1}).to_list(2000)}
    shift_ids = {s["id"] for s in await db.shifts.find({}, {"id": 1}).to_list(5000)}
    rec_ids = {r["id"] for r in await db.recipes.find({}, {"id": 1}).to_list(5000)}

    res = []

    def add(name, count, samples, note=""):
        res.append({"name": name, "count": count, "samples": samples[:5], "note": note})

    # 1) Produk -> kategori hilang
    miss = [p["name"] for p in prod_by_id.values()
            if p.get("category_id") and p["category_id"] not in cat_ids]
    add("Produk dengan kategori hilang", len(miss), miss, "Kategori terhapus tapi produk masih menunjuknya. Produk tersembunyi dari katalog.")

    # 2) Produk -> vendor hilang
    miss = [p["name"] for p in prod_by_id.values()
            if p.get("vendor_id") and p["vendor_id"] not in ven_ids]
    add("Produk dengan vendor hilang", len(miss), miss, "Vendor titipan terhapus. Periksa bagi hasil & penjualan produk ini.")

    # 3) Item order -> produk hilang (produk tak pernah di-hard-delete jika terpakai; muncul bila restore parsial)
    broken = {}
    for o in await db.orders.find({}, {"id": 1, "order_number": 1, "items": 1}).to_list(50000):
        for it in (o.get("items") or []):
            if it.get("product_id") and it["product_id"] not in prod_ids:
                broken.setdefault(it.get("product_id"), {"qty": 0, "orders": set()})
                broken[it["product_id"]]["qty"] += it.get("qty", 0)
                broken[it["product_id"]]["orders"].add(o.get("order_number", "?"))
    add("Item order dengan produk hilang", len(broken),
        [f"produk {pid} ({len(v['orders'])} order)" for pid, v in list(broken.items())[:5]],
        "Laba & laporan produk terdampak.")

    # 4) Order dine-in -> meja hilang
    miss = (await db.orders.count_documents({"order_type": "dine_in", "table_id": {"$nin": list(tab_ids)}})) if tab_ids else 0
    add("Order dine-in dengan meja hilang", miss, [], "Meja dine-in harus selalu menunjuk meja yang ada.")

    # 5) Order -> shift hilang
    miss = (await db.orders.count_documents({"shift_id": {"$exists": True, "$nin": list(shift_ids)}})) if shift_ids else 0
    add("Order dengan shift hilang", miss, [], "Laporan shift tidak lengkap.")

    # 6) Kas keluar/masuk -> shift hilang
    miss = (await db.cash_movements.count_documents({"shift_id": {"$exists": True, "$nin": list(shift_ids)}})) if shift_ids else 0
    add("Catatan kas dengan shift hilang", miss, [], "Kas tidak masuk hitungan shift.")

    # 7) Reservasi -> meja hilang
    miss = (await db.reservations.count_documents({"table_id": {"$nin": list(tab_ids)}})) if tab_ids else 0
    add("Reservasi dengan meja hilang", miss, [], "Meja yang direservasi sudah dihapus.")

    # 8) Resep -> produk hilang / bahan hilang
    miss = 0
    for r in await db.recipes.find({}, {"product_id": 1, "ingredients": 1}).to_list(5000):
        if r.get("product_id") not in prod_ids:
            miss += 1
        for b in (r.get("ingredients") or []):
            if b.get("product_id") and b["product_id"] not in prod_ids:
                miss += 1
    add("Resep dengan produk/bahan hilang", miss, [], "HPP otomatis tidak akurat.")

    result = {"at": now_utc().isoformat(), "results": res}
    await db.settings.update_one({"_id": "orphan"}, {"$set": {"last": result}}, upsert=True)
    return result

async def _maybe_orphan_auto():
    """Jadwal: 1× per minggu (default Minggu 04:00) bila flag maint.orphan_auto ON."""
    if not await _feat("maint.orphan_auto"):
        return
    try:
        doc = await db.settings.find_one({"_id": "orphan"}, {"_id": 0}) or {}
        last = (doc.get("last") or {}).get("at", "")[:10]
        today = wib_today()
        if last == today:
            return
        noww = datetime.now(WIB)
        hour = int(await _feat("maint.orphan_hour", 4))
        day = int(await _feat("maint.orphan_day", 6))
        if noww.hour == hour and noww.weekday() == day:
            await _run_orphan_check()
            logger.info("orphan check otomatis mingguan selesai")
    except Exception as e:
        logger.error(f"orphan auto check failed: {e}")

async def _service_tax(net_total):
    """Pajak layanan opsional (%) — dibebankan di atas total bersih (setelah semua diskon)."""
    biz = await _business()
    rate = float(biz.get("service_tax_percent") or 0)
    if rate <= 0 or net_total <= 0:
        return rate if rate else 0.0, 0.0
    return rate, round(net_total * rate / 100.0, 2)

async def _discount_needs_reason(discount_type, discount_value, subtotal):
    biz = await _business()
    if discount_type == "percent":
        return discount_value > float(biz.get("discount_reason_percent") or 15)
    if discount_type == "amount":
        return discount_value > float(biz.get("discount_reason_amount") or 50000)
    return False

async def _apply_redeem(member_id, redeem_points, total_before):
    """Validasi & hitung potongan poin member (1 poin = Rp100).
    Poin baru benar-benar dipotong di _finalize_payment saat pembayaran sukses."""
    if not member_id or not redeem_points or redeem_points <= 0:
        return 0.0, None
    m = await db.members.find_one({"id": member_id})
    if not m:
        raise HTTPException(400, "Member tidak ditemukan")
    pts = float(m.get("points") or 0)
    if redeem_points > pts:
        raise HTTPException(400, f"Poin member tidak cukup (sisa {pts:,.0f})")
    rate = float((await _business()).get("member_redeem_per_point") or 100)
    value = round(redeem_points * rate, 2)
    value = min(value, total_before)
    return value, m

async def _award_member_points(order):
    """Setelah order lunas, tambah poin & total belanja member + kirim notifikasi WA."""
    mid = order.get("member_id")
    if not mid:
        return
    m = await db.members.find_one({"id": mid})
    if not m:
        return
    earn_rp = float((await _business()).get("member_earn_per_rupiah") or 10000)
    redeem_rp = float((await _business()).get("member_redeem_per_point") or 100)
    pts = int(order.get("total", 0) // earn_rp) if earn_rp > 0 else 0
    if pts <= 0:
        return
    await db.members.update_one({"id": mid}, {"$inc": {"points": pts, "total_spend": order.get("total", 0)}})
    await db.orders.update_one({"id": order["id"]}, {"$set": {"points_earned": pts}})
    phone = m.get("phone", "")
    if phone and await _wa_configured():
        try:
            await _send_whatsapp([phone],
                f"*Grand Aceh Kuliner*\nTerima kasih sudah berbelanja!\nTotal: Rp{order.get('total',0):,.0f}\nPoin +{pts} (total poin {float(m.get('points') or 0)+pts:,.0f})\nTukarkan poin 1pt=Rp{redeem_rp:,.0f} saat pembayaran.")
        except Exception:
            pass

async def gen_order_number():
    import re as _re
    prefix = str((await _business()).get("order_prefix") or "GAK-").strip() or "GAK-"
    today = wib_today().replace("-", "")
    cid = f"order-{today}"
    # migration-safe init: seed counter from any orders already created today
    if not await db.counters.find_one({"_id": cid}):
        cnt = await db.orders.count_documents({"order_number": {"$regex": f"^{_re.escape(prefix)}{today}-"}})
        await db.counters.update_one({"_id": cid}, {"$setOnInsert": {"seq": cnt}}, upsert=True)
    doc = await db.counters.find_one_and_update(
        {"_id": cid}, {"$inc": {"seq": 1}}, return_document=ReturnDocument.AFTER
    )
    return f"{prefix}{today}-{doc['seq']:04d}"

# ================================================================== AUTH
def _hash_cost(h):
    """Cost bcrypt dari string hash ("$2b$12$...") → int; None bila tak terurai."""
    try:
        return int(str(h or "").split("$")[2])
    except (IndexError, ValueError):
        return None

USERNAME_RE = re.compile(r"^[a-z0-9._-]{3,32}$")

def _slug_username(src: str, taken=None):
    """Turunkan username aman dari teks (mis. bagian depan email)."""
    base = re.sub(r"[^a-z0-9._-]+", "", str(src or "").strip().lower())[:24] or "user"
    base = base.strip("._-") or "user"
    if len(base) < 3:
        base = (base + "user")[:32]
    taken = taken or set()
    if base not in taken:
        return base
    i = 2
    while f"{base}{i}" in taken and i < 500:
        i += 1
    return f"{base}{i}"

@api.post("/auth/login")
async def login(body: LoginIn):
    ident = body.ident()
    if not ident:
        raise HTTPException(400, "Username wajib diisi")
    user = await db.users.find_one({"$or": [{"username": ident}, {"email": ident}]})
    if not user or not verify_password(body.password, user["password_hash"]):
        raise HTTPException(401, "Username atau password salah")
    # Transparan re-hash bila hash lama memakai cost lebih tinggi (login lebih cepat).
    # Hash lama cost 12 (default lama) membuat login 400-900ms+ di Pi; cost 11 ±2x lebih cepat.
    try:
        hc = _hash_cost(user.get("password_hash"))
        if hc is not None and hc > _bcrypt_rounds():
            await db.users.update_one({"id": user["id"]},
                                      {"$set": {"password_hash": hash_password(body.password)}})
    except Exception:
        pass
    if not user.get("active", True):
        raise HTTPException(403, "Akun dinonaktifkan")
    safe = {"id": user["id"], "name": user["name"], "email": user["email"], "role": user["role"]}
    uv = await _user_view(user)
    uv["id"], uv["name"], uv["email"], uv["role"] = user["id"], user["name"], user["email"], user["role"]
    return {"token": create_token(safe), "user": uv}

@api.get("/auth/me")
async def me(user: dict = Depends(get_current_user)):
    return await _user_view(user)

@api.get("/users")
async def list_users(user: dict = Depends(require_admin)):
    """Daftar akun. Hanya Super Admin yang menerima kolom `password` (password terlihat,
    direkam saat akun dibuat / password direset — lihat create_user & reset_user_password).
    Akun lama (dibuat sebelum fitur ini) tidak punya rekaman → `password` kosong."""
    is_super = await _is_super(user)
    q = {} if is_super else {"role": {"$ne": "superadmin"}}
    rows = await db.users.find(q, {"_id": 0, "password_hash": 0}).sort("created_at", 1).to_list(500)
    out = []
    for u in rows:
        plain = u.pop("password_plain", None)
        u.pop("_id", None)
        if is_super:
            u["password"] = plain or ""
        out.append(u)
    return out

@api.post("/users")
async def create_user(body: UserCreate, user: dict = Depends(require_admin)):
    role = body.role.strip() or "kasir"
    if not await _valid_role_name(role):
        raise HTTPException(400, f"Role '{role}' tidak dikenal — minta Super Admin membuatnya di Pengaturan → Roles & Izin")
    is_super = await _is_super(user)
    # Admin biasa HANYA boleh membuat akun dengan role yang diizinkan Super Admin.
    if not is_super:
        allowed = await _assignable_roles()
        if role not in allowed:
            raise HTTPException(403, f"Role '{role}' tidak boleh dibuat oleh admin — hanya Super Admin yang menentukan daftar role akun")
    uname = (body.username or "").strip().lower()
    if not USERNAME_RE.match(uname):
        raise HTTPException(400, "Username 3-32 karakter, hanya huruf kecil/angka/titik/garis bawah/minus (tanpa spasi)")
    if await db.users.find_one({"username": uname}):
        raise HTTPException(400, f"Username '{uname}' sudah dipakai")
    if not (body.name or "").strip():
        raise HTTPException(400, "Nama wajib diisi")
    forced = True if body.must_change_password is None else bool(body.must_change_password)
    doc = {"id": new_id(), "name": body.name.strip(), "username": uname, "email": "",
           "password_hash": hash_password(body.password),
           # password terlihat (hanya dikirim ke Super Admin lewat GET /users)
           "password_plain": body.password,
           "must_change_password": forced,
           "role": role,
           "active": True, "created_at": now_utc().isoformat(), "created_by": user.get("username") or user.get("name")}
    await db.users.insert_one(doc)
    return {"id": doc["id"], "name": doc["name"], "username": doc["username"], "role": doc["role"],
            "must_change_password": forced}

@api.patch("/users/{uid}/role")
async def set_user_role(uid: str, body: RoleAssignIn, user: dict = Depends(require_admin)):
    role = body.role.strip()
    if not await _valid_role_name(role):
        raise HTTPException(400, f"Role '{role}' tidak dikenal — minta Super Admin membuatnya di Pengaturan → Roles & Izin")
    target = await db.users.find_one({"id": uid}, {"_id": 0, "role": 1})
    if not target:
        raise HTTPException(404, "User tidak ditemukan")
    is_super = await _is_super(user)
    if not is_super:
        if await _is_super(target):
            raise HTTPException(403, "Akun Super Admin hanya bisa diubah oleh Super Admin")
        allowed = await _assignable_roles()
        if role not in allowed:
            raise HTTPException(403, f"Role '{role}' tidak boleh ditugaskan oleh admin — hanya Super Admin yang menentukan")
    r = await db.users.update_one({"id": uid}, {"$set": {"role": role}})
    if not r.matched_count:
        raise HTTPException(404, "User tidak ditemukan")
    return {"ok": True, "role": role}

@api.patch("/users/{uid}/toggle")
async def toggle_user(uid: str, user: dict = Depends(require_admin)):
    u = await db.users.find_one({"id": uid})
    if not u:
        raise HTTPException(404, "User tidak ditemukan")
    if await _is_super(u) and not await _is_super(user):
        raise HTTPException(403, "Akun Super Admin hanya bisa diubah oleh Super Admin")
    await db.users.update_one({"id": uid}, {"$set": {"active": not u.get("active", True)}})
    return {"active": not u.get("active", True)}

@api.post("/auth/change-password")
async def change_password(body: ChangePasswordIn, user: dict = Depends(get_current_user)):
    if len(body.new_password) < 6:
        raise HTTPException(400, "Password baru minimal 6 karakter")
    full = await db.users.find_one({"id": user["id"]})
    if not full or not verify_password(body.current_password, full["password_hash"]):
        raise HTTPException(400, "Password lama salah")
    # must_change_password ikut dimatikan: kewajiban ganti password saat login pertama selesai.
    await db.users.update_one({"id": user["id"]},
                              {"$set": {"password_hash": hash_password(body.new_password),
                                        # password terlihat ikut diperbarui agar Super Admin
                                        # tidak melihat password basi di daftar akun.
                                        "password_plain": body.new_password,
                                        "must_change_password": False}})
    return {"ok": True}

@api.post("/users/{uid}/reset-password")
async def reset_user_password(uid: str, body: ResetPasswordIn, user: dict = Depends(require_admin)):
    if len(body.new_password) < 6:
        raise HTTPException(400, "Password minimal 6 karakter")
    u = await db.users.find_one({"id": uid})
    if not u:
        raise HTTPException(404, "User tidak ditemukan")
    if await _is_super(u) and not await _is_super(user):
        raise HTTPException(403, "Akun Super Admin hanya bisa diubah oleh Super Admin")
    forced = True if body.must_change_password is None else bool(body.must_change_password)
    await db.users.update_one({"id": uid},
                              {"$set": {"password_hash": hash_password(body.new_password),
                                        "password_plain": body.new_password,
                                        "must_change_password": forced}})
    # password dikembalikan supaya admin dapat menyalinnya untuk diberikan ke pemilik akun.
    return {"ok": True, "password": body.new_password, "must_change_password": forced}

@api.patch("/users/{uid}/must-change-password")
async def set_must_change_password(uid: str, body: MustChangePasswordIn, user: dict = Depends(require_admin)):
    """Nyalakan/matikan kewajiban ganti password saat login berikutnya (per akun)."""
    target = await db.users.find_one({"id": uid}, {"_id": 0, "role": 1, "email": 1, "username": 1})
    if not target:
        raise HTTPException(404, "User tidak ditemukan")
    if await _is_super(target) and not await _is_super(user):
        raise HTTPException(403, "Akun Super Admin hanya bisa diubah oleh Super Admin")
    await db.users.update_one({"id": uid}, {"$set": {"must_change_password": bool(body.value)}})
    return {"ok": True, "must_change_password": bool(body.value)}

@api.get("/users/{uid}/delete-check")
async def user_delete_check(uid: str, admin: dict = Depends(require_superadmin)):
    """Info sebelum hapus akun: apakah akun punya riwayat transaksi (→ hanya nonaktif)."""
    target = await db.users.find_one({"id": uid}, {"_id": 0, "password_hash": 0, "password_plain": 0})
    if not target:
        raise HTTPException(404, "User tidak ditemukan")
    hist = await _user_history(uid)
    return {"id": uid, "name": target.get("name") or "",
            "username": target.get("username") or target.get("email") or "",
            "role": target.get("role") or "",
            "active": bool(target.get("active", True)),
            "is_superadmin": await _is_super(target),
            "self": uid == admin["id"],
            **hist}

@api.delete("/users/{uid}")
async def delete_user(uid: str, admin: dict = Depends(require_superadmin)):
    """Hapus akun (Super Admin). Akun yang SUDAH punya riwayat transaksi tidak dihapus
    permanen — hanya dinonaktifkan (arsip) agar laporan lama tetap utuh."""
    target = await db.users.find_one({"id": uid}, {"_id": 0, "role": 1, "email": 1, "username": 1, "name": 1})
    if not target:
        raise HTTPException(404, "User tidak ditemukan")
    if uid == admin["id"]:
        raise HTTPException(400, "Tidak bisa menghapus akun Anda sendiri")
    if await _is_super(target) and await _super_accounts_count() <= 1:
        raise HTTPException(400, "Akun Super Admin terakhir tidak bisa dihapus — angkat Super Admin lain lebih dulu")
    hist = await _user_history(uid)
    who = target.get("username") or target.get("email") or target.get("name") or uid
    if hist["has_history"]:
        await db.users.update_one({"id": uid}, {"$set": {"active": False,
                                                        "archived_at": now_utc().isoformat(),
                                                        "archived_by": admin.get("username") or admin.get("name")}})
        logger.info(f"akun {who} dinonaktifkan (punya riwayat: {hist['counts']})")
        return {"action": "deactivated", "username": who, **hist}
    await db.users.delete_one({"id": uid})
    logger.info(f"akun {who} dihapus permanen (tanpa riwayat transaksi)")
    return {"action": "deleted", "username": who, **hist}

@api.post("/admin/reset-data")
async def reset_data(body: ResetDataIn, admin: dict = Depends(require_admin)):
    """Destructive: wipe transactional (and optionally catalog) data. Keeps users, settings, payment methods."""
    full = await db.users.find_one({"id": admin["id"]})
    if not full or not verify_password(body.password, full["password_hash"]):
        raise HTTPException(400, "Password admin salah")
    tx = ["orders", "cash_movements", "shifts", "stock_opname", "purchases", "counters", "import_logs", "audit_logs"]
    catalog = ["products", "categories", "tables"]
    cols = tx + (catalog if body.scope == "all" else [])
    deleted = {}
    for col in cols:
        r = await db[col].delete_many({})
        deleted[col] = r.deleted_count
    return {"ok": True, "scope": body.scope, "deleted": deleted}

# ================================================================== CATEGORIES
@api.get("/categories")
async def list_categories(include_inactive: bool = True, user: dict = Depends(get_current_user)):
    q = {} if include_inactive else {"active": True}
    key = f"categories:{int(include_inactive)}"
    if await _feat("perf.cache_master"):
        hit = _cache_get(key)
        if hit is not None:
            return hit
    rows = await db.categories.find(q, {"_id": 0}).sort("sort_order", 1).to_list(500)
    if await _feat("perf.cache_master"):
        _cache_set(key, rows, 20.0)
    return rows

@api.post("/categories")
async def create_category(body: CategoryIn, admin: dict = Depends(admin_or_input)):
    if await db.categories.find_one({"name": {"$regex": f"^{re.escape(body.name.strip())}$", "$options": "i"}, "type": body.type}):
        raise HTTPException(400, f"Kategori '{body.name}' sudah ada untuk tipe ini")
    doc = body.model_dump()
    doc.update({"id": new_id(), "created_at": now_utc().isoformat()})
    await db.categories.insert_one(doc)
    _cache_del("categories:")
    doc.pop("_id", None)
    return doc

@api.put("/categories/{cid}")
async def update_category(cid: str, body: CategoryIn, admin: dict = Depends(admin_or_input)):
    if not await db.categories.find_one({"id": cid}):
        raise HTTPException(404, "Kategori tidak ditemukan")
    if await db.categories.find_one({"name": {"$regex": f"^{re.escape(body.name.strip())}$", "$options": "i"}, "type": body.type, "id": {"$ne": cid}}):
        raise HTTPException(400, f"Kategori '{body.name}' sudah ada untuk tipe ini")
    await db.categories.update_one({"id": cid}, {"$set": body.model_dump()})
    _cache_del("categories:")
    return await db.categories.find_one({"id": cid}, {"_id": 0})

@api.delete("/categories/{cid}")
async def delete_category(cid: str, admin: dict = Depends(admin_or_input)):
    used = await db.products.count_documents({"category_id": cid})
    if used:
        # soft deactivate instead of hard delete
        await db.categories.update_one({"id": cid}, {"$set": {"active": False}})
        _cache_del("categories:")
        return {"soft_deleted": True, "reason": f"Kategori dipakai {used} produk, dinonaktifkan (tidak dihapus)."}
    await db.categories.delete_one({"id": cid})
    _cache_del("categories:")
    return {"deleted": True}

# ================================================================== PRODUCTS
@api.get("/products")
async def list_products(type: Optional[str] = None, category_id: Optional[str] = None,
                        active_only: bool = False, user: dict = Depends(get_current_user)):
    q = {}
    if type:
        q["type"] = type
    if category_id:
        q["category_id"] = category_id
    if active_only:
        q["active"] = True
    key = f"products:{type or '-'}:{category_id or '-'}:{int(active_only)}"
    if await _feat("perf.cache_master"):
        hit = _cache_get(key)
        if hit is not None:
            return hit
    rows = await db.products.find(q, {"_id": 0}).sort("name", 1).to_list(2000)
    if await _feat("perf.cache_master"):
        _cache_set(key, rows, 20.0)  # katalog jarang berubah; 20 dtk cukup
    return rows

@api.post("/products")
async def create_product(body: ProductIn, admin: dict = Depends(admin_or_input)):
    if body.price < 0 or body.cost < 0:
        raise HTTPException(400, "Harga/HPP tidak boleh negatif")
    if await db.products.find_one({"sku": body.sku}):
        raise HTTPException(400, f"SKU '{body.sku}' sudah dipakai")
    if not await db.categories.find_one({"id": body.category_id}):
        raise HTTPException(400, "Kategori tidak valid")
    doc = body.model_dump()
    doc["track_stock"] = body.type == "retail"
    doc.update({"id": new_id(), "created_at": now_utc().isoformat()})
    await db.products.insert_one(doc)
    _cache_del("products:")
    doc.pop("_id", None)
    return doc

@api.put("/products/{pid}")
async def update_product(pid: str, body: ProductIn, admin: dict = Depends(admin_or_input)):
    if body.price < 0 or body.cost < 0:
        raise HTTPException(400, "Harga/HPP tidak boleh negatif")
    existing = await db.products.find_one({"id": pid})
    if not existing:
        raise HTTPException(404, "Produk tidak ditemukan")
    dup = await db.products.find_one({"sku": body.sku, "id": {"$ne": pid}})
    if dup:
        raise HTTPException(400, f"SKU '{body.sku}' sudah dipakai produk lain")
    doc = body.model_dump(exclude_unset=True)
    if "type" in doc:
        doc["track_stock"] = doc["type"] == "retail"
    await db.products.update_one({"id": pid}, {"$set": doc})
    _cache_del("products:")
    return await db.products.find_one({"id": pid}, {"_id": 0})

@api.patch("/products/{pid}/sold-out")
async def toggle_sold_out(pid: str, user: dict = Depends(get_current_user)):
    p = await db.products.find_one({"id": pid})
    if not p:
        raise HTTPException(404, "Produk tidak ditemukan")
    val = not p.get("sold_out", False)
    await db.products.update_one({"id": pid}, {"$set": {"sold_out": val}})
    _cache_del("products:")
    return {"sold_out": val}

@api.delete("/products/{pid}")
async def delete_product(pid: str, admin: dict = Depends(admin_or_input)):
    used = await db.orders.count_documents({"items.product_id": pid})
    if used:
        await db.products.update_one({"id": pid}, {"$set": {"active": False}})
        _cache_del("products:")
        return {"soft_deleted": True, "reason": "Produk pernah dipakai transaksi, dinonaktifkan."}
    await db.products.delete_one({"id": pid})
    _cache_del("products:")
    return {"deleted": True}

# ================================================================== RESEP & HPP OTOMATIS
async def _calc_recipe_hpp(recipe):
    """Hitung HPP (modal) per unit hasil dari daftar bahan.
    Tiap baris bahan: ingredient_id (master Bahan) ATAU product_id (produk retail lama)."""
    ing = []
    total = 0.0
    for b in recipe.get("ingredients", []):
        qty = float(b.get("qty") or 0)
        if qty <= 0:
            continue
        iid = b.get("ingredient_id")
        pid = b.get("product_id")
        name = b.get("name", "")
        unit = b.get("unit", "")
        cost = 0.0
        if iid:
            ib = await db.ingredients.find_one({"id": iid}, {"_id": 0, "name": 1, "unit": 1, "cost": 1})
            if not ib:
                continue
            name = name or ib.get("name", "?")
            unit = unit or ib.get("unit", "")
            cost = float(ib.get("cost") or 0)  # HPP bahan = harga beli terakhir
        elif pid:
            p = await db.products.find_one({"id": pid}, {"_id": 0, "name": 1, "cost": 1, "price": 1})
            if not p:
                continue
            name = name or p["name"]
            cost = float(p.get("cost") or 0) or float(p.get("price") or 0)  # bahan produk: pakai HPP, fallback harga jual
        if qty == 0:
            continue
        line = round(cost * qty, 2)
        total += line
        ing.append({"ingredient_id": iid, "product_id": pid, "name": name, "qty": qty,
                    "unit": unit, "kind": "ingredient" if iid else "product",
                    "cost": line, "unit_cost": round(cost, 2)})
    yield_units = float(recipe.get("yield_units") or 1) or 1
    return {"ingredients": ing, "total_cost": round(total, 2),
            "hpp_per_unit": round(total / yield_units, 2), "yield_units": yield_units}

@api.get("/recipes")
async def list_recipes(admin: dict = Depends(admin_or_input)):
    recipes = await db.recipes.find({}, {"_id": 0}).to_list(1000)
    out = []
    for r in recipes:
        r["hpp"] = await _calc_recipe_hpp(r)
        out.append(r)
    return {"recipes": out}

@api.get("/recipes/{product_id}")
async def get_recipe(product_id: str, admin: dict = Depends(admin_or_input)):
    r = await db.recipes.find_one({"product_id": product_id}, {"_id": 0})
    if not r:
        raise HTTPException(404, "Resep belum dibuat")
    r["hpp"] = await _calc_recipe_hpp(r)
    return r

@api.post("/recipes")
async def create_recipe(body: RecipeIn, admin: dict = Depends(admin_or_input)):
    if not await db.products.find_one({"id": body.product_id}):
        raise HTTPException(400, "Produk tidak valid")
    await db.recipes.delete_many({"product_id": body.product_id})  # upsert: satu resep per produk
    doc = {"id": new_id(), "product_id": body.product_id, "ingredients": body.ingredients,
           "yield_units": body.yield_units, "created_at": now_utc().isoformat()}
    await db.recipes.insert_one(doc)
    doc.pop("_id", None)
    doc["hpp"] = await _calc_recipe_hpp(doc)
    return doc

@api.put("/recipes/{product_id}")
async def update_recipe(product_id: str, body: RecipeIn, admin: dict = Depends(admin_or_input)):
    doc = {"product_id": product_id, "ingredients": body.ingredients,
           "yield_units": body.yield_units, "updated_at": now_utc().isoformat()}
    r = await db.recipes.update_one({"product_id": product_id}, {"$set": doc}, upsert=True)
    out = await db.recipes.find_one({"product_id": product_id}, {"_id": 0})
    out["hpp"] = await _calc_recipe_hpp(out)
    return out

@api.post("/recipes/{product_id}/apply-hpp")
async def apply_recipe_hpp(product_id: str, admin: dict = Depends(require_admin)):
    """Terapkan HPP hasil resep ke kolom cost produk (HPP otomatis)."""
    r = await db.recipes.find_one({"product_id": product_id})
    if not r:
        raise HTTPException(404, "Resep belum dibuat")
    hpp = await _calc_recipe_hpp(r)
    await db.products.update_one({"id": product_id}, {"$set": {"cost": hpp["hpp_per_unit"]}})
    _cache_del("products:")
    return {"ok": True, "cost": hpp["hpp_per_unit"]}

@api.delete("/recipes/{product_id}")
async def delete_recipe(product_id: str, admin: dict = Depends(require_admin)):
    await db.recipes.delete_one({"product_id": product_id})
    return {"ok": True}

# ================================================================== VENDORS
@api.get("/vendors")
async def list_vendors(active_only: bool = False, user: dict = Depends(get_current_user)):
    q = {"active": True} if active_only else {}
    return await db.vendors.find(q, {"_id": 0}).sort("name", 1).to_list(500)

@api.post("/vendors")
async def create_vendor(body: VendorIn, admin: dict = Depends(admin_or_input)):
    if await db.vendors.find_one({"name": {"$regex": f"^{re.escape(body.name.strip())}$", "$options": "i"}}):
        raise HTTPException(400, f"Vendor '{body.name}' sudah ada")
    doc = body.model_dump()
    doc.update({"id": new_id(), "created_at": now_utc().isoformat()})
    await db.vendors.insert_one(doc)
    doc.pop("_id", None)
    return doc

@api.put("/vendors/{vid}")
async def update_vendor(vid: str, body: VendorIn, admin: dict = Depends(admin_or_input)):
    if not await db.vendors.find_one({"id": vid}):
        raise HTTPException(404, "Vendor tidak ditemukan")
    if await db.vendors.find_one({"name": {"$regex": f"^{re.escape(body.name.strip())}$", "$options": "i"}, "id": {"$ne": vid}}):
        raise HTTPException(400, f"Vendor '{body.name}' sudah ada")
    await db.vendors.update_one({"id": vid}, {"$set": body.model_dump()})
    return await db.vendors.find_one({"id": vid}, {"_id": 0})

@api.delete("/vendors/{vid}")
async def delete_vendor(vid: str, admin: dict = Depends(admin_or_input)):
    used = await db.products.count_documents({"vendor_id": vid})
    if used:
        await db.vendors.update_one({"id": vid}, {"$set": {"active": False}})
        return {"soft_deleted": True, "reason": f"Vendor dipakai {used} produk, dinonaktifkan (tidak dihapus)."}
    await db.vendors.delete_one({"id": vid})
    return {"deleted": True}

# ================================================================== TABLES
@api.get("/tables")
async def list_tables(user: dict = Depends(get_current_user)):
    tables = await db.tables.find({"deleted": {"$ne": True}}, {"_id": 0}).sort("area", 1).to_list(500)
    open_orders = await db.orders.find({"order_type": "dine_in", "status": "open"}, {"_id": 0, "table_id": 1, "id": 1, "total": 1}).to_list(1000)
    open_map = {}
    for o in open_orders:
        open_map[o["table_id"]] = o
    for t in tables:
        oo = open_map.get(t["id"])
        t["status"] = "open_bill" if oo else "empty"
        t["open_order_id"] = oo["id"] if oo else None
        t["reservation"] = await _table_reservation(t["id"])
    return tables

async def _table_reservation(table_id):
    """Reservasi aktif untuk meja (hari ini / belum selesai)."""
    today = wib_today()
    r = await db.reservations.find_one({
        "table_id": table_id,
        "status": {"$in": ["pending", "confirmed", "arrived"]},
        "date": today,
    }, {"_id": 0})
    return r

@api.get("/reservations")
async def list_reservations(date_str: Optional[str] = Query(None, alias="date"), user: dict = Depends(get_current_user)):
    d = date_str or wib_today()
    rows = await db.reservations.find({"date": d}, {"_id": 0}).sort("time", 1).to_list(500)
    tables = {t["id"]: t["name"] for t in await db.tables.find({}, {"_id": 0, "id": 1, "name": 1}).to_list(500)}
    for r in rows:
        r["table_name"] = tables.get(r.get("table_id"), "?")
    return {"date": d, "reservations": rows}

@api.post("/reservations")
async def create_reservation(body: ReservationIn, user: dict = Depends(get_current_user)):
    if not body.customer_name.strip():
        raise HTTPException(400, "Nama pemesan wajib")
    if not body.table_id or not await db.tables.find_one({"id": body.table_id, "deleted": {"$ne": True}}):
        raise HTTPException(400, "Meja tidak valid")
    doc = {"id": new_id(), "table_id": body.table_id, "customer_name": body.customer_name.strip(),
           "phone": body.phone.strip(), "pax": body.pax, "date": body.date or wib_today(),
           "time": body.time or "12:00", "note": body.note, "status": "confirmed",
           "created_by": user["name"], "created_at": now_utc().isoformat()}
    await db.reservations.insert_one(doc)
    doc.pop("_id", None)
    return doc

@api.patch("/reservations/{rid}")
async def update_reservation(rid: str, body: ReservationUpdateIn, user: dict = Depends(get_current_user)):
    upd = body.model_dump(exclude_none=True)
    if not upd:
        raise HTTPException(400, "Tidak ada perubahan")
    r = await db.reservations.update_one({"id": rid}, {"$set": upd})
    if not r.matched_count:
        raise HTTPException(404, "Reservasi tidak ditemukan")
    return {"ok": True}

@api.post("/reservations/{rid}/status")
async def set_reservation_status(rid: str, body: dict, user: dict = Depends(get_current_user)):
    status = (body or {}).get("status", "")
    if status not in ("pending", "confirmed", "arrived", "cancelled", "done"):
        raise HTTPException(400, "Status tidak valid")
    r = await db.reservations.update_one({"id": rid}, {"$set": {"status": status}})
    if not r.matched_count:
        raise HTTPException(404, "Reservasi tidak ditemukan")
    return {"ok": True}

@api.delete("/reservations/{rid}")
async def delete_reservation(rid: str, admin: dict = Depends(require_admin)):
    await db.reservations.delete_one({"id": rid})
    return {"ok": True}

@api.post("/tables")
async def create_table(body: TableIn, admin: dict = Depends(require_admin)):
    if await db.tables.find_one({"name": body.name, "deleted": {"$ne": True}}):
        raise HTTPException(400, f"Nama/kode meja '{body.name}' sudah ada")
    doc = body.model_dump()
    doc.update({"id": new_id(), "deleted": False, "created_at": now_utc().isoformat()})
    await db.tables.insert_one(doc)
    doc.pop("_id", None)
    return doc

@api.put("/tables/{tid}")
async def update_table(tid: str, body: TableIn, admin: dict = Depends(require_admin)):
    t = await db.tables.find_one({"id": tid})
    if not t:
        raise HTTPException(404, "Meja tidak ditemukan")
    dup = await db.tables.find_one({"name": body.name, "id": {"$ne": tid}, "deleted": {"$ne": True}})
    if dup:
        raise HTTPException(400, f"Nama/kode meja '{body.name}' sudah ada")
    if t.get("active") and not body.active:
        open_bill = await db.orders.find_one({"table_id": tid, "status": "open"})
        if open_bill:
            raise HTTPException(400, "Meja punya open bill aktif, tidak bisa dinonaktifkan")
    await db.tables.update_one({"id": tid}, {"$set": body.model_dump()})
    return await db.tables.find_one({"id": tid}, {"_id": 0})

@api.delete("/tables/{tid}")
async def delete_table(tid: str, admin: dict = Depends(require_admin)):
    open_bill = await db.orders.find_one({"table_id": tid, "status": "open"})
    if open_bill:
        raise HTTPException(400, "Meja punya open bill aktif, tidak bisa dihapus")
    used = await db.orders.count_documents({"table_id": tid})
    if used:
        await db.tables.update_one({"id": tid}, {"$set": {"active": False}})
        return {"soft_deleted": True, "reason": "Meja pernah dipakai transaksi, dinonaktifkan (tidak dihapus)."}
    await db.tables.update_one({"id": tid}, {"$set": {"deleted": True, "active": False}})
    return {"deleted": True}

# ================================================================== PAYMENT METHODS
@api.get("/payment-methods")
async def list_payment_methods(user: dict = Depends(get_current_user)):
    if await _feat("perf.cache_master"):
        hit = _cache_get("payment-methods")
        if hit is not None:
            return hit
    rows = await db.payment_methods.find({}, {"_id": 0}).sort("name", 1).to_list(100)
    if await _feat("perf.cache_master"):
        _cache_set("payment-methods", rows, 30.0)
    return rows

@api.post("/payment-methods")
async def create_pm(body: PaymentMethodIn, admin: dict = Depends(require_admin)):
    doc = body.model_dump()
    doc.update({"id": new_id()})
    await db.payment_methods.insert_one(doc)
    _cache_del("payment-methods")
    doc.pop("_id", None)
    return doc

@api.patch("/payment-methods/{pmid}/toggle")
async def toggle_pm(pmid: str, admin: dict = Depends(require_admin)):
    pm = await db.payment_methods.find_one({"id": pmid})
    if not pm:
        raise HTTPException(404, "Metode tidak ditemukan")
    await db.payment_methods.update_one({"id": pmid}, {"$set": {"active": not pm.get("active", True)}})
    _cache_del("payment-methods")
    return {"active": not pm.get("active", True)}

# ================================================================== ORDERS
async def _resolve_items(raw_items):
    """Rebuild every line item from the products collection (server-authoritative).
    Produk diambil SEKALI per keranjang (query $in) — bukan per-baris — supaya
    transaksi dengan banyak item tidak membayar N round-trip ke MongoDB."""
    ids = list({it.product_id for it in raw_items if it.product_id})
    if not ids:
        raise HTTPException(400, "Keranjang kosong")
    prods = {p["id"]: p for p in await db.products.find({"id": {"$in": ids}}, {"_id": 0}).to_list(len(ids) + 10)}
    resolved = []
    for it in raw_items:
        p = prods.get(it.product_id)
        if not p:
            raise HTTPException(400, f"Produk tidak ditemukan: {it.product_id}")
        if not p.get("active", True):
            raise HTTPException(400, f"Produk nonaktif tidak bisa dijual: {p['name']}")
        if p.get("sold_out"):
            raise HTTPException(400, f"Produk sold out: {p['name']}")
        line = {"product_id": p["id"], "name": p["name"], "price": p["price"],
                "cost": float(p.get("cost") or 0),
                "qty": it.qty, "type": p["type"], "track_stock": p.get("track_stock", False)}
        # Produk jual per berat (F&B): harga = harga per satuan berat × berat
        if p.get("weight_sale") and it.weight and float(it.weight) > 0:
            w = float(it.weight)
            line["price"] = round(float(p["price"]) * w, 2)
            line["cost"] = round(line["cost"] * w, 2)  # HPP ikut skala berat
            line["weight"] = round(w, 2)
            line["weight_unit"] = p.get("weight_unit", "")
            line["base_price"] = float(p["price"])
            line["name"] = f"{p['name']} ({w:.2f} {p.get('weight_unit', '')})".strip()
        if p["type"] == "vendor" and p.get("vendor_id"):
            share = float(p.get("vendor_share_percent") or 0)
            line["vendor_id"] = p["vendor_id"]
            line["vendor_share_percent"] = share
            # Bagi hasil vendor dihitung dari HARGA JUAL baris (sudah × berat bila jual per berat).
            # Diskon order TIDAK memotong bagian vendor — yang menanggung diskon adalah outlet.
            line["vendor_total"] = round(line["price"] * it.qty * share / 100, 2)
        resolved.append(line)
    return resolved

async def _validate_order_rules(order_type, table_id, items):
    types = {i["type"] for i in items}
    if order_type == "retail":
        if any(t != "retail" for t in types):
            raise HTTPException(400, "Alur retail hanya boleh berisi item retail")
    else:  # dine_in / take_away
        if "retail" in types:
            raise HTTPException(400, "Item retail tidak boleh masuk alur F&B (dine-in/take away)")
    if order_type == "dine_in":
        if not table_id:
            raise HTTPException(400, "Dine-in wajib memilih meja")
        t = await db.tables.find_one({"id": table_id, "deleted": {"$ne": True}})
        if not t or not t.get("active", True):
            raise HTTPException(400, "Meja tidak valid atau nonaktif")
    elif table_id:
        raise HTTPException(400, "Take away/retail tidak boleh memakai meja")

async def _current_shift(user):
    return await db.shifts.find_one({"cashier_id": user["id"], "status": "open"}, {"_id": 0})

async def _finalize_payment(order, payment_method, amount_paid, user, splits=None):
    payment_splits = None
    # ---- Pembayaran 2 metode sekaligus (splits) ----
    # Jumlah seluruh bagian harus PAS total tagihan; tidak ada uang kembalian di mode ini.
    if splits and len(splits) >= 2:
        resolved = []
        tot = 0.0
        for sp in splits:
            if not isinstance(sp, dict) or not sp.get("payment_method"):
                raise HTTPException(400, "Data metode pembayaran tidak valid")
            pm = await db.payment_methods.find_one({"id": str(sp["payment_method"]), "active": True}, {"_id": 0})
            if not pm:
                raise HTTPException(400, "Metode pembayaran tidak valid/aktif")
            try:
                amt = round(float(sp.get("amount") or 0), 2)
            except (TypeError, ValueError):
                raise HTTPException(400, "Jumlah bagian pembayaran tidak valid")
            if amt <= 0:
                raise HTTPException(400, "Jumlah tiap metode harus lebih dari 0")
            resolved.append({"pm": pm, "amount": amt})
            tot += amt
        if abs(tot - order["total"]) > 0.01:
            raise HTTPException(400, f"Total metode bayar ({tot:,.0f}) harus PAS total tagihan ({order['total']:,.0f})")
        if len({m["pm"]["id"] for m in resolved}) < 2:
            raise HTTPException(400, "Gunakan 2 metode yang berbeda")
        method_name = " + ".join(m["pm"]["name"] for m in resolved)
        payment_splits = [{"payment_method_id": m["pm"]["id"], "payment_method_name": m["pm"]["name"],
                           "payment_method_type": m["pm"]["type"], "amount": m["amount"]} for m in resolved]
        pm = resolved[0]["pm"]
        payment_method = pm["id"]
        paid = round(tot, 2)
        cash_change = 0.0
    else:
        pm = await db.payment_methods.find_one({"id": payment_method, "active": True})
        if not pm:
            raise HTTPException(400, "Metode pembayaran tidak valid/aktif")
        paid = amount_paid if amount_paid is not None else order["total"]
        if pm["type"] == "cash" and paid < order["total"]:
            raise HTTPException(400, "Jumlah bayar kurang dari total")
        cash_change = round(paid - order["total"], 2)
    shift = await _current_shift(user)
    # Validasi stok (baca) — decrement dilakukan SETELAH klaim berhasil.
    for it in order["items"]:
        if it.get("type") == "retail":
            p = await db.products.find_one({"id": it["product_id"]}, {"_id": 0})
            if p and p.get("track_stock") and p.get("stock", 0) < it["qty"]:
                raise HTTPException(400, f"Stok '{it['name']}' tidak cukup (sisa {p.get('stock', 0)})")
    upd = {"status": "paid", "payment_method_id": payment_method, "payment_method_name": pm["name"],
           "payment_method_type": pm["type"], "amount_paid": paid,
           "change": cash_change,
           "payment_splits": payment_splits,
           "paid_at": now_utc().isoformat(), "shift_id": shift["id"] if shift else None}
    if order.get("payment_ref"):
        upd["payment_ref"] = str(order["payment_ref"]).strip()
    # Klaim ATOMIK: hanya request yang berhasil mengubah status open -> paid yang boleh
    # menjalankan efek samping (stok/poin/kupon/award). Dua request bayar bersamaan utk
    # order yg sama => satu menang, yang lain melihat status sudah paid dan langsung pulang.
    res = await db.orders.update_one({"id": order["id"], "status": "open"}, {"$set": upd})
    if res.matched_count == 0:
        existing = await db.orders.find_one({"id": order["id"]}, {"_id": 0})
        if existing:
            return existing  # sudah dibayar request lain — kembalikan hasil, tanpa efek ganda
        raise HTTPException(404, "Order tidak ditemukan")
    # ---- efek "hanya saat lunas" — dijalankan SEKALI oleh pemenang klaim ----
    for it in order["items"]:
        if it.get("type") == "retail":
            await db.products.update_one({"id": it["product_id"], "track_stock": True},
                                         {"$inc": {"stock": -it["qty"]}})
    if order.get("member_id") and (order.get("redeem_points_used") or 0) > 0:
        await db.members.update_one({"id": order["member_id"]},
                                    {"$inc": {"points": -float(order["redeem_points_used"])}})
    if order.get("coupon_code"):
        cou = await db.coupons.find_one({"code": str(order["coupon_code"]).strip().upper()}, {"_id": 0})
        if cou:
            upd["coupon_counted"] = True  # penanda utk void — diset SEKALIGUS dgn klaim
    # Klaim ATOMIK: hanya request yang berhasil mengubah status open -> paid yang boleh
    # menjalankan efek samping (stok/poin/kupon/award). Dua request bayar bersamaan utk
    # order yg sama => satu menang, yang lain melihat status sudah paid dan langsung pulang.
    res = await db.orders.update_one({"id": order["id"], "status": "open"}, {"$set": upd})
    if res.matched_count == 0:
        existing = await db.orders.find_one({"id": order["id"]}, {"_id": 0})
        if existing:
            return existing  # sudah dibayar request lain — kembalikan hasil, tanpa efek ganda
        raise HTTPException(404, "Order tidak ditemukan")
    # ---- efek "hanya saat lunas" — dijalankan SEKALI oleh pemenang klaim ----
    for it in order["items"]:
        if it.get("type") == "retail":
            await db.products.update_one({"id": it["product_id"], "track_stock": True},
                                         {"$inc": {"stock": -it["qty"]}})
    if order.get("member_id") and (order.get("redeem_points_used") or 0) > 0:
        await db.members.update_one({"id": order["member_id"]},
                                    {"$inc": {"points": -float(order["redeem_points_used"])}})
    if order.get("coupon_code") and upd.get("coupon_counted"):
        await db.coupons.update_one({"code": str(order["coupon_code"]).strip().upper()},
                                    {"$inc": {"used_count": 1}})
    await _award_member_points({**order, **upd})
    # Data berubah -> cache laporan & stok produk yang terlihat usang dibatalkan.
    _bump_rs_gen()
    _cache_del("products:")
    try:
        import asyncio as _aio
        _aio.create_task(_fire_webhook("order.paid", {
            "order_id": order["id"], "order_number": order.get("order_number"),
            "order_type": order.get("order_type"), "total": order.get("total"),
            "payment": pm.get("name"), "cashier": user.get("name"),
            "shift_id": shift["id"] if shift else None,
        }))
    except Exception as e:
        logger.error(f"webhook order.paid task gagal: {e}")
    return {**order, **upd}

@api.post("/orders")
async def create_order(body: OrderIn, user: dict = Depends(admin_or_kasir)):
    if not body.items:
        raise HTTPException(400, "Keranjang kosong")
    if body.pay_now and not body.payment_method:
        raise HTTPException(400, "Pilih metode pembayaran")
    if body.client_ref:
        dup = await db.orders.find_one({"client_ref": body.client_ref}, {"_id": 0})
        if dup:
            return dup  # idempotent: offline sync retry won't duplicate
    items = await _resolve_items(body.items)
    await _validate_order_rules(body.order_type, body.table_id, items)
    subtotal, discount, total = compute_totals(items, body.discount_type, body.discount_value)
    promo_discount, promo_names = await _apply_promos(items, subtotal)
    if await _discount_needs_reason(body.discount_type, body.discount_value, subtotal) and not (body.discount_reason or "").strip():
        raise HTTPException(400, "Alasan diskon wajib diisi untuk diskon besar (lihat ambang di Pengaturan Aplikasi)")
    total = max(0.0, round(total - promo_discount, 2))
    coupon_discount = 0.0
    coupon_code = ""
    if body.coupon_code:
        coupon_discount, coupon_code = await _apply_coupon(body.coupon_code, total)
        total = max(0.0, round(total - coupon_discount, 2))
    redeem_discount = 0.0
    if body.member_id and body.redeem_points:
        rd, m = await _apply_redeem(body.member_id, body.redeem_points, total)
        redeem_discount = rd
        total = max(0.0, round(total - rd, 2))
    srv_rate, srv_amt = await _service_tax(total)
    total = round(total + srv_amt, 2)
    doc = {
        "id": new_id(), "order_number": await gen_order_number(),
        "order_type": body.order_type, "table_id": body.table_id, "items": items,
        "subtotal": subtotal, "discount_type": body.discount_type, "discount_value": body.discount_value,
        "discount": discount, "promo_discount": promo_discount, "promos_applied": promo_names,
        "coupon_code": coupon_code, "coupon_discount": coupon_discount,
        "redeem_discount": redeem_discount, "member_id": body.member_id,
        "redeem_points_used": float(body.redeem_points or 0),
        "service_tax_rate": srv_rate, "service_tax": srv_amt,
        "discount_reason": body.discount_reason, "total": total, "note": body.note,
        "status": "open", "cashier_id": user["id"], "cashier_name": user["name"],
        "client_ref": body.client_ref,
        "created_at": now_utc().isoformat(),
    }
    await db.orders.insert_one(doc)
    doc.pop("_id", None)
    if body.pay_now:
        if not body.payment_method and not body.splits:
            raise HTTPException(400, "Pilih metode pembayaran")
        doc = await _finalize_payment(doc, body.payment_method, body.amount_paid, user, splits=body.splits)
    return doc

@api.get("/orders")
async def list_orders(status: Optional[str] = None, order_type: Optional[str] = None,
                      date_str: Optional[str] = Query(None, alias="date"),
                      user: dict = Depends(admin_or_kasir)):
    q = {}
    if status:
        q["status"] = status
    if order_type:
        q["order_type"] = order_type
    if date_str:
        start, end = wib_day_range(date_str)
        q["created_at"] = {"$gte": start, "$lt": end}
    return await db.orders.find(q, {"_id": 0}).sort("created_at", -1).to_list(1000)

@api.get("/orders/{oid}")
async def get_order(oid: str, user: dict = Depends(admin_or_kasir)):
    o = await db.orders.find_one({"id": oid}, {"_id": 0})
    if not o:
        raise HTTPException(404, "Order tidak ditemukan")
    return o

@api.patch("/orders/{oid}/items")
async def update_order_items(oid: str, body: ItemsUpdate, user: dict = Depends(admin_or_kasir)):
    o = await db.orders.find_one({"id": oid})
    if not o:
        raise HTTPException(404, "Order tidak ditemukan")
    if o["status"] != "open":
        raise HTTPException(400, "Hanya open bill yang bisa ditambah item")
    items = await _resolve_items(body.items)
    await _validate_order_rules(o["order_type"], o.get("table_id"), items)
    subtotal, discount, total = compute_totals(items, o["discount_type"], o["discount_value"])
    promo_discount, promo_names = await _apply_promos(items, subtotal)
    total = max(0.0, round(total - promo_discount, 2))
    srv_rate, srv_amt = await _service_tax(total)
    total = round(total + srv_amt, 2)
    await db.orders.update_one({"id": oid}, {"$set": {"items": items, "subtotal": subtotal,
                                                       "discount": discount, "promo_discount": promo_discount,
                                                       "promos_applied": promo_names,
                                                       "service_tax_rate": srv_rate, "service_tax": srv_amt,
                                                       "total": total}})
    return await db.orders.find_one({"id": oid}, {"_id": 0})

@api.post("/orders/{oid}/pay")
async def pay_order(oid: str, body: PayIn, user: dict = Depends(admin_or_kasir)):
    o = await db.orders.find_one({"id": oid}, {"_id": 0})
    if not o:
        raise HTTPException(404, "Order tidak ditemukan")
    # Idempotensi: retry dengan payment_ref yang sama tidak menggandakan pembayaran.
    if body.payment_ref:
        prev = await db.orders.find_one({"payment_ref": body.payment_ref, "status": "paid"}, {"_id": 0})
        if prev:
            if prev["id"] == oid:
                return prev  # request sebelumnya sudah berhasil — kembalikan hasilnya
            raise HTTPException(409, "payment_ref sudah dipakai transaksi lain")
    if o["status"] != "open":
        raise HTTPException(400, "Order sudah lunas / tidak bisa dibayar")
    subtotal, discount, total = compute_totals(o["items"], body.discount_type, body.discount_value)
    promo_discount, promo_names = await _apply_promos(o["items"], subtotal)
    if await _discount_needs_reason(body.discount_type, body.discount_value, subtotal) and not (body.discount_reason or "").strip():
        raise HTTPException(400, "Alasan diskon wajib diisi untuk diskon besar (lihat ambang di Pengaturan Aplikasi)")
    total = max(0.0, round(total - promo_discount, 2))
    coupon_discount = 0.0
    coupon_code = ""
    if body.coupon_code:
        # Pemakaian kupon (used_count) dihitung di _finalize_payment saat transaksi lunas — sekali.
        coupon_discount, coupon_code = await _apply_coupon(body.coupon_code, total)
        total = max(0.0, round(total - coupon_discount, 2))
    redeem_discount = 0.0
    if body.member_id and body.redeem_points:
        rd, m = await _apply_redeem(body.member_id, body.redeem_points, total)
        redeem_discount = rd
        total = max(0.0, round(total - rd, 2))
    srv_rate, srv_amt = await _service_tax(total)
    total = round(total + srv_amt, 2)
    await db.orders.update_one({"id": oid}, {"$set": {"discount_type": body.discount_type,
                                                      "discount_value": body.discount_value,
                                                      "discount": discount, "promo_discount": promo_discount,
                                                      "promos_applied": promo_names,
                                                      "coupon_code": coupon_code, "coupon_discount": coupon_discount,
                                                      "redeem_discount": redeem_discount,
                                                      "member_id": body.member_id,
                                                      "redeem_points_used": float(body.redeem_points or 0),
                                                      "discount_reason": body.discount_reason,
                                                      "service_tax_rate": srv_rate, "service_tax": srv_amt,
                                                      "total": total, "subtotal": subtotal}})
    o.update({"discount": discount, "promo_discount": promo_discount, "promos_applied": promo_names,
              "redeem_discount": redeem_discount, "member_id": body.member_id,
              "redeem_points_used": float(body.redeem_points or 0),
              "coupon_code": coupon_code, "coupon_discount": coupon_discount,
              "service_tax_rate": srv_rate, "service_tax": srv_amt,
              "discount_reason": body.discount_reason, "total": total, "subtotal": subtotal,
              "payment_ref": body.payment_ref})
    return await _finalize_payment(o, body.payment_method, body.amount_paid, user, splits=body.splits)

@api.post("/orders/{oid}/void")
async def void_order(oid: str, body: VoidIn, admin: dict = Depends(require_admin)):
    o = await db.orders.find_one({"id": oid})
    if not o:
        raise HTTPException(404, "Order tidak ditemukan")
    if o["status"] in ("void", "refunded"):
        raise HTTPException(400, "Order sudah dibatalkan/refund")
    new_status = "refunded" if body.action == "refund" else "void"
    # restore retail stock & efek lain bila transaksi sudah lunas
    if o["status"] == "paid":
        for it in o["items"]:
            if it["type"] == "retail":
                await db.products.update_one({"id": it["product_id"], "track_stock": True},
                                             {"$inc": {"stock": it["qty"]}})
        # balik pemakaian kupon (hanya bila benar-benar sudah dihitung saat lunas)
        if o.get("coupon_code") and o.get("coupon_counted"):
            cou = await db.coupons.find_one({"code": str(o["coupon_code"]).strip().upper()}, {"_id": 0})
            if cou:
                await db.coupons.update_one({"code": cou["code"]}, {"$inc": {"used_count": -1}})
        # balik poin member: poin yang didapat dari transaksi ini diambil, poin yang ditukar dikembalikan
        if o.get("member_id"):
            mem_adj = {}
            if o.get("points_earned"):
                mem_adj["points"] = -float(o["points_earned"])
                mem_adj["total_spend"] = -float(o.get("total", 0))
            if o.get("redeem_points_used"):
                mem_adj["points"] = mem_adj.get("points", 0) + float(o["redeem_points_used"])
            if mem_adj:
                await db.members.update_one({"id": o["member_id"]}, {"$inc": mem_adj})
    audit = {"id": new_id(), "order_id": oid, "order_number": o["order_number"],
             "action": body.action, "reason": body.reason, "prev_status": o["status"],
             "by": admin["name"], "by_id": admin["id"], "amount": o["total"],
             "at": now_utc().isoformat()}
    await db.audit_logs.insert_one(audit)
    await db.orders.update_one({"id": oid}, {"$set": {"status": new_status,
                                                      "voided_at": now_utc().isoformat(),
                                                      "void_reason": body.reason, "voided_by": admin["name"]}})
    await db.orders.update_one({"id": oid}, {"$unset": {"coupon_counted": 1}})
    _bump_rs_gen()
    _cache_del("products:")
    audit.pop("_id", None)
    return {"status": new_status, "audit": audit}

@api.get("/audit-logs")
async def audit_logs(admin: dict = Depends(require_admin)):
    return await db.audit_logs.find({}, {"_id": 0}).sort("at", -1).to_list(500)

# ================================================================== SHIFTS
@api.get("/shifts/current")
async def current_shift(user: dict = Depends(admin_or_kasir)):
    return await _current_shift(user)

@api.post("/shifts/open")
async def open_shift(body: ShiftOpenIn, user: dict = Depends(admin_or_kasir)):
    if await _current_shift(user):
        raise HTTPException(400, "Sudah ada shift terbuka")
    doc = {"id": new_id(), "cashier_id": user["id"], "cashier_name": user["name"],
           "opening_cash": body.opening_cash, "status": "open",
           "opened_at": now_utc().isoformat(), "closed_at": None}
    await db.shifts.insert_one(doc)
    doc.pop("_id", None)
    return doc

@api.post("/shifts/close")
async def close_shift(body: ShiftCloseIn, user: dict = Depends(admin_or_kasir)):
    shift = await _current_shift(user)
    if not shift:
        raise HTTPException(400, "Tidak ada shift terbuka")
    report = await _shift_report(shift)
    # Hitung bagian vendor (yang seharusnya) & yang diberikan dari input
    vendor_rows = report.get("vendor_share", [])
    paid_map = {str(v.get("vendor_id")): float(v.get("paid") or 0) for v in (body.vendor_payments or [])}
    total_share = 0.0
    total_paid = 0.0
    for v in vendor_rows:
        v["paid"] = paid_map.get(str(v["vendor_id"]), 0.0)
        v["difference"] = round(v["share"] - v["paid"], 2)
        total_share += v["share"]
        total_paid += v["paid"]
    total_diff = round(total_share - total_paid, 2)
    # Bagian outlet per vendor = omzet - bagi hasil REAL (yang diberikan)
    for v in vendor_rows:
        v["outlet_share"] = round(v["gross"] - v["paid"], 2)
    total_outlet = round(sum(v.get("outlet_share", 0) for v in vendor_rows), 2)
    report["vendor_share"] = vendor_rows
    report["vendor_total_share"] = round(total_share, 2)
    report["vendor_total_paid"] = round(total_paid, 2)
    report["vendor_total_difference"] = total_diff
    report["vendor_total_outlet"] = total_outlet
    # Uang bersih dihitung ulang SETELAH paid diketahui (nilai awal di _shift_report belum
    # memperhitungkan vendor). Produk vendor hanya dijual lewat alur F&B, jadi seluruh uang
    # yang diberikan ke vendor mengurangi kas F&B.
    report["net_cash_fnb"] = round(report["fnb_total"] - report["cash_out_fnb"] - total_paid, 2)
    report["net_cash_retail"] = round(report["retail_total"] - report["cash_out_retail"], 2)
    report["net_cash"] = round(report["net_cash_fnb"] + report["net_cash_retail"], 2)
    await db.shifts.update_one({"id": shift["id"]}, {"$set": {
        "status": "closed", "closed_at": now_utc().isoformat(),
        "closing_cash": body.closing_cash, "report": report}})
    _bump_rs_gen()
    try:
        import asyncio as _aio
        _aio.create_task(_fire_webhook("shift.closed", {
            "shift_id": shift["id"], "cashier": user.get("name"),
            "total_sales": report.get("total_sales"), "net_cash": report.get("net_cash"),
        }))
    except Exception as e:
        logger.error(f"webhook shift.closed task gagal: {e}")
    return {**shift, "closing_cash": body.closing_cash, "report": report, "status": "closed"}

async def _vendor_share_from_orders(orders):
    """Kumpulkan bagian vendor dari order (per vendor): gross & share (yang seharusnya) + detail per produk."""
    per = {}
    for o in orders:
        for it in o.get("items", []):
            if it.get("type") == "vendor" and it.get("vendor_id"):
                vid = it["vendor_id"]
                v = per.get(vid)
                if not v:
                    v = {"vendor_id": vid, "vendor_name": it.get("vendor_name") or "Vendor",
                         "gross": 0.0, "share": 0.0, "_items": {}}
                    per[vid] = v
                line = it["price"] * it["qty"]
                v["gross"] = round(v["gross"] + line, 2)
                v["share"] = round(v["share"] + (it.get("vendor_total") or 0), 2)
                im = v["_items"].setdefault(it.get("product_id") or it["name"], {
                    "product_id": it.get("product_id"), "name": it["name"],
                    "qty": 0, "gross": 0.0, "vendor_share": 0.0})
                im["qty"] += it["qty"]
                im["gross"] = round(im["gross"] + line, 2)
                im["vendor_share"] = round(im["vendor_share"] + (it.get("vendor_total") or 0), 2)
    # isi nama vendor dari koleksi bila belum ada di item
    for vid in list(per.keys()):
        if per[vid]["vendor_name"] == "Vendor":
            vd = await db.vendors.find_one({"id": vid}, {"_id": 0, "name": 1})
            if vd:
                per[vid]["vendor_name"] = vd["name"]
        per[vid]["items"] = [{"product_id": x["product_id"], "name": x["name"], "qty": x["qty"],
                              "gross": round(x["gross"], 2), "vendor_share": round(x["vendor_share"], 2)}
                             for x in sorted(per[vid]["_items"].values(), key=lambda y: y["gross"], reverse=True)]
        per[vid].pop("_items", None)
    return list(per.values())

async def _shift_report(shift):
    orders = await db.orders.find({"shift_id": shift["id"], "status": "paid"}, {"_id": 0}).to_list(5000)
    by_type = {"dine_in": 0, "take_away": 0, "retail": 0}
    by_pm = {}
    total = 0
    cost_fnb = 0.0
    cost_retail = 0.0
    for o in orders:
        by_type[o["order_type"]] = by_type.get(o["order_type"], 0) + o["total"]
        for _pn, _pt, _pa in _order_pay_parts(o):
            by_pm[_pn] = by_pm.get(_pn, 0) + _pa
        total += o["total"]
        for it in o.get("items", []):
            if it.get("type") == "retail":
                cost_retail += (it.get("cost") or 0) * it["qty"]
            else:
                cost_fnb += (it.get("cost") or 0) * it["qty"]
    fnb_total = by_type["dine_in"] + by_type["take_away"]
    retail_total = by_type["retail"]
    cash = sum(_cash_paid(o) for o in orders)
    # Kas keluar (pengeluaran) per scope — TANPA kas masuk (keuangan murni dari penjualan & pengeluaran)
    moves = await db.cash_movements.find({"shift_id": shift["id"]}, {"_id": 0}).to_list(2000)
    cash_out = sum(m["amount"] for m in moves if m["type"] == "out")
    def _out_scope(sc):
        return round(sum(m["amount"] for m in moves if m["type"] == "out" and m.get("scope") == sc), 2)
    out_fnb = _out_scope("fnb"); out_retail = _out_scope("retail")
    vendor_rows = await _vendor_share_from_orders(orders)
    vendor_expected = round(sum(v.get("share", 0) for v in vendor_rows), 2)
    # CATATAN: "diberikan ke vendor" (paid) belum diketahui di tahap ini — diisi saat penutupan
    # (close_shift). Uang bersih dihitung ulang di close_shift SETELAH paid diketahui.
    # Uang bersih per toko: penjualan toko - pengeluaran scope toko - vendor yang dibayar.
    net_cash_fnb0 = round(fnb_total - out_fnb, 2)          # placeholder; dihitung ulang saat tutup
    net_cash_retail0 = round(retail_total - out_retail, 2)  # vendor hanya ada di alur F&B
    return {"order_count": len(orders), "total_sales": round(total, 2), "by_type": by_type,
            "fnb_total": round(fnb_total, 2), "retail_total": round(retail_total, 2),
            # Laba kotor F&B = pendapatan F&B − HPP F&B − bagian vendor (omzet titipan milik vendor)
            "gross_profit_fnb": round(fnb_total - cost_fnb - vendor_expected, 2),
            "gross_profit_retail": round(retail_total - cost_retail, 2),
            "by_payment": by_pm,
            # Perkiraan kas = kas awal + penjualan tunai − uang keluar
            "expected_cash": round(shift["opening_cash"] + cash - cash_out, 2),
            "cash_out": round(cash_out, 2),
            "cash_out_fnb": out_fnb, "cash_out_retail": out_retail,
            "vendor_share": vendor_rows,
            "vendor_expected_share": vendor_expected,
            "vendor_total_share": round(sum(v["share"] for v in vendor_rows), 2),
            "vendor_total_paid": 0.0,  # diisi close_shift setelah kasir input nominal diberikan
            "net_cash_fnb": net_cash_fnb0, "net_cash_retail": net_cash_retail0,
            "net_cash": round(net_cash_fnb0 + net_cash_retail0, 2)}

@api.get("/shifts/current/vendor")
async def shift_vendor_preview(user: dict = Depends(admin_or_kasir)):
    """Preview bagian vendor dari shift yang sedang berjalan (untuk form penutupan)."""
    shift = await _current_shift(user)
    if not shift:
        raise HTTPException(400, "Tidak ada shift terbuka")
    orders = await db.orders.find({"shift_id": shift["id"], "status": "paid"}, {"_id": 0}).to_list(5000)
    return {"vendors": await _vendor_share_from_orders(orders)}

@api.get("/shifts")
async def list_shifts(admin: dict = Depends(require_admin)):
    return await db.shifts.find({}, {"_id": 0}).sort("opened_at", -1).to_list(200)

@api.get("/shifts/history")
async def shift_history(admin: dict = Depends(admin_or_kasir)):
    """Histori laporan shift tertutup — ringkasan untuk ditampilkan di UI."""
    shifts = await db.shifts.find({"status": "closed"}, {"_id": 0}).sort("opened_at", -1).to_list(200)
    out = []
    for s in shifts:
        r = s.get("report") or {}
        out.append({
            "id": s["id"], "cashier_name": s.get("cashier_name", "-"),
            "opened_at": s.get("opened_at"), "closed_at": s.get("closed_at"),
            "opening_cash": s.get("opening_cash", 0), "closing_cash": s.get("closing_cash", 0),
            "total_sales": r.get("total_sales", 0), "order_count": r.get("order_count", 0),
            "fnb_total": r.get("fnb_total", 0), "retail_total": r.get("retail_total", 0),
            "expected_cash": r.get("expected_cash", 0), "net_cash": r.get("net_cash", 0),
            "cash_out": r.get("cash_out", 0),
            "vendor_total_share": r.get("vendor_total_share", 0),
            "vendor_total_paid": r.get("vendor_total_paid", 0),
        })
    return {"shifts": out}

def _shift_report_lines(r):
    L = ["*LAPORAN SHIFT — Grand Aceh Kuliner*", ""]
    L.append(f"Total Penjualan: Rp{r.get('total_sales', 0):,.0f} ({r.get('order_count', 0)} order)")
    L.append(f"*F&B*: Rp{r.get('fnb_total', 0):,.0f}")
    L.append(f"  Dine-in: Rp{r.get('by_type', {}).get('dine_in', 0):,.0f}")
    L.append(f"  Take Away: Rp{r.get('by_type', {}).get('take_away', 0):,.0f}")
    L.append(f"*Retail*: Rp{r.get('retail_total', 0):,.0f}")
    L.append("")
    L.append(f"Pengeluaran F&B: Rp{r.get('cash_out_fnb', 0):,.0f}")
    L.append(f"Pengeluaran Retail: Rp{r.get('cash_out_retail', 0):,.0f}")
    L.append(f"Perkiraan kas: Rp{r.get('expected_cash', 0):,.0f}")
    L.append("")
    L.append("*UANG BERSIH*")
    L.append(f"F&B: Rp{r.get('net_cash_fnb', 0):,.0f}")
    L.append(f"Retail: Rp{r.get('net_cash_retail', 0):,.0f}")
    L.append(f"Total: Rp{r.get('net_cash', 0):,.0f}")
    for v in (r.get("vendor_share") or []):
        L.append(f"Vendor {v.get('vendor_name', '?')}: bagi hasil {v.get('share', 0):,.0f} | diberikan {v.get('paid', 0):,.0f} | selisih {v.get('difference', 0):,.0f}")
        for im in (v.get("items") or []):
            L.append(f"   - {im.get('name', '?')} (x{im.get('qty', 0)}): Rp{im.get('gross', 0):,.0f} (Vendor Rp{im.get('vendor_share', 0):,.0f})")
    if r.get("vendor_total_share"):
        L.append(f"Total vendor: share {r.get('vendor_total_share', 0):,.0f} | diberikan {r.get('vendor_total_paid', 0):,.0f}")
    return L

@api.post("/shifts/{sid}/send-wa")
async def shift_send_wa(sid: str, admin: dict = Depends(require_admin)):
    """Kirim laporan shift ke WhatsApp (nomor tujuan dari Pengaturan Laporan)."""
    s = await db.shifts.find_one({"id": sid}, {"_id": 0})
    if not s:
        raise HTTPException(404, "Shift tidak ditemukan")
    r = s.get("report") or {}
    doc = await db.settings.find_one({"_id": "report"}) or {}
    recips = doc.get("recipients", [])
    if not recips:
        raise HTTPException(400, "Belum ada nomor WhatsApp tujuan. Atur di Pengaturan → Laporan & WhatsApp.")
    text = await _tpl_fill("shift", _shift_wa_env(r, s.get("cashier_name", ""), (s.get("opened_at") or "")[:10]))
    result = await _send_whatsapp(recips, text)
    if not any(x.get("ok") for x in result):
        raise HTTPException(400, f"Gagal kirim WhatsApp: {result[0].get('error') if result else 'tidak diketahui'}")
    return {"sent": result, "recipients": recips}

@api.get("/shifts/{sid}/print")
async def shift_print_preview(sid: str, admin: dict = Depends(require_admin)):
    """Pratinjau teks laporan shift utk dicetak — memakai TEMPLATE laporan shift
    (bisa dirancang sendiri di Pengaturan → WhatsApp & Laporan → Template WhatsApp)."""
    s = await db.shifts.find_one({"id": sid}, {"_id": 0})
    if not s:
        raise HTTPException(404, "Shift tidak ditemukan")
    r = s.get("report") or {}
    text = await _tpl_fill("shift", _shift_wa_env(r, s.get("cashier_name", ""), (s.get("opened_at") or "")[:10]))
    return {"text": text, "shift_id": sid, "shift_number": s.get("shift_number") or (s.get("opened_at") or "")[:10]}

# ================================================================== REPORTS
@api.get("/reports/summary")
async def report_summary(date_str: Optional[str] = Query(None, alias="date"),
                         admin: dict = Depends(admin_or_kasir)):
    d = date_str or wib_today()
    # Cache laporan: tanggal HARI INI pendek (20 dtk), tanggal lampau lama (immutable).
    # Data dibatalkan otomatis lewat _bump_rs_gen() saat ada pay/void/refund.
    if await _feat("perf.cache_reports"):
        hit = _rcache_get(f"rs:{d}")
        if hit is not None:
            return hit
    start, end = wib_day_range(d)
    q = {"status": "paid", "created_at": {"$gte": start, "$lt": end}}
    orders = await db.orders.find(q, {"_id": 0}).to_list(5000)
    by_type = {"dine_in": {"count": 0, "total": 0}, "take_away": {"count": 0, "total": 0}, "retail": {"count": 0, "total": 0}}
    by_pm = {}
    product_sales = {}
    total = 0
    total_discount = 0
    total_cost = 0
    prods = await db.products.find({}, {"_id": 0, "id": 1, "category_id": 1, "type": 1}).to_list(5000)
    prod_map = {p["id"]: p for p in prods}
    cats_all = await db.categories.find({}, {"_id": 0}).to_list(1000)
    cat_map = {c["id"]: c for c in cats_all}
    cat_sales = {}
    group_totals = {"makanan": 0, "minuman": 0, "retail": 0}
    for o in orders:
        bt = by_type[o["order_type"]]
        bt["count"] += 1
        bt["total"] += o["total"]
        total += o["total"]
        total_discount += o.get("discount", 0)
        for _pn, _pt, _pa in _order_pay_parts(o):
            by_pm[_pn] = by_pm.get(_pn, 0) + _pa
        for it in o["items"]:
            line = it["price"] * it["qty"]
            ps = product_sales.setdefault(it["name"], {"qty": 0, "total": 0, "cost": 0})
            ps["qty"] += it["qty"]
            ps["total"] += line
            ps["cost"] += it.get("cost", 0) * it["qty"]
            total_cost += it.get("cost", 0) * it["qty"]
            pinfo = prod_map.get(it.get("product_id"), {})
            itype = pinfo.get("type") or it.get("type") or "retail"
            if itype in group_totals:
                group_totals[itype] += line
            cid = pinfo.get("category_id")
            if cid:
                cinfo = cat_map.get(cid, {})
                cs = cat_sales.setdefault(cid, {"category_id": cid, "name": cinfo.get("name", "?"),
                                                "type": cinfo.get("type", itype), "qty": 0, "total": 0})
                cs["qty"] += it["qty"]
                cs["total"] += line
    top = []
    for k, v in sorted(product_sales.items(), key=lambda x: x[1]["total"], reverse=True)[:20]:
        profit = v["total"] - v["cost"]
        margin = round(profit / v["total"] * 100, 1) if v["total"] else 0
        pid = next((pid for pid, p in prod_map.items() if p.get("type") == "retail" and any(o.get("items") and it.get("name") == k for o in orders for it in o["items"] if it.get("product_id") == pid)), None)
        # tipe dari product_sales kita tidak simpan; ambil dari item orders
        itype = "retail"
        for o in orders:
            for it in o.get("items", []):
                if it["name"] == k:
                    itype = it.get("type") or itype
        top.append({"name": k, "qty": v["qty"], "total": round(v["total"], 2),
                    "cost": round(v["cost"], 2), "profit": round(profit, 2), "margin": margin, "type": itype})
    fnb_total = by_type["dine_in"]["total"] + by_type["take_away"]["total"]
    # laba kotor per toko
    cost_fnb = 0.0; cost_retail = 0.0; vendor_exp_fnb = 0.0
    for o in orders:
        for it in o.get("items", []):
            if it.get("type") == "retail":
                cost_retail += (it.get("cost") or 0) * it["qty"]
            else:
                cost_fnb += (it.get("cost") or 0) * it["qty"]
            if it.get("type") == "vendor":
                vendor_exp_fnb += (it.get("vendor_total") or 0)
    # Laba F&B outlet = pendapatan − HPP − bagian vendor (omzet titipan bukan pendapatan outlet)
    gross_fnb = round(fnb_total - cost_fnb - vendor_exp_fnb, 2)
    gross_retail = round(by_type["retail"]["total"] - cost_retail, 2)
    # top_products per tipe (F&B = makanan+minuman; retail)
    top_fnb = [t for t in top if t.get("type") in ("makanan", "minuman")]
    top_retail = [t for t in top if t.get("type") == "retail"]
    by_cat = sorted(cat_sales.values(), key=lambda x: x["total"], reverse=True)
    for c in by_cat:
        c["total"] = round(c["total"], 2)
    category_report = {
        "makanan": {"total": round(group_totals["makanan"], 2),
                    "categories": [c for c in by_cat if c["type"] == "makanan"]},
        "minuman": {"total": round(group_totals["minuman"], 2),
                    "categories": [c for c in by_cat if c["type"] == "minuman"]},
        "retail": {"total": round(group_totals["retail"], 2),
                   "categories": [c for c in by_cat if c["type"] == "retail"]},
    }
    low_stock_thr = float((await _business()).get("low_stock_threshold") or 10)
    low_stock = await db.products.aggregate([
        {"$match": {"track_stock": True, "active": True}},
        {"$addFields": {"eff_min": {"$ifNull": ["$min_stock", low_stock_thr]}}},
        {"$match": {"$expr": {"$lte": ["$stock", "$eff_min"]}}},
        {"$project": {"_id": 0, "name": 1, "sku": 1, "stock": 1, "min_stock": "$eff_min"}},
        {"$sort": {"stock": 1}},
        {"$limit": 100},
    ]).to_list(100)
    cash_moves = await db.cash_movements.find({"created_at": {"$gte": start, "$lt": end}}, {"_id": 0}).to_list(2000)
    cash_out = sum(m["amount"] for m in cash_moves if m["type"] == "out")
    def _out_scope(sc):
        return round(sum(m["amount"] for m in cash_moves if m["type"] == "out" and m.get("scope") == sc), 2)
    cash_sales = sum(_cash_paid(o) for o in orders)
    cash_sales_fnb = sum(_cash_paid(o) for o in orders if o.get("order_type") != "retail")
    cash_sales_retail = sum(_cash_paid(o) for o in orders if o.get("order_type") == "retail")
    vendor_summary = await _vendor_report(date_str=d)
    summary = {"date": d, "vendor_summary": vendor_summary, "total_sales": round(total, 2), "order_count": len(orders),
               "total_discount": round(total_discount, 2), "by_type": by_type, "by_payment": by_pm,
               "fnb_total": round(fnb_total, 2), "retail_total": round(by_type["retail"]["total"], 2),
               "top_products": top, "top_fnb": top_fnb, "top_retail": top_retail,
               "low_stock": low_stock, "low_stock_threshold": low_stock_thr,
               "total_cost": round(total_cost, 2), "gross_profit": round(total - total_cost, 2),
               "gross_profit_fnb": gross_fnb, "gross_profit_retail": gross_retail,
               "cash_out": round(cash_out, 2),
               "cash_out_fnb": _out_scope("fnb"), "cash_out_retail": _out_scope("retail"),
               "cash_sales": round(cash_sales, 2),
               "cash_sales_fnb": round(cash_sales_fnb, 2), "cash_sales_retail": round(cash_sales_retail, 2),
               # Kas bersih laci per toko & total = penjualan TUNAI − pengambilan keluar (TANPA kas masuk)
               "cash_net_fnb": round(cash_sales_fnb - _out_scope("fnb"), 2),
               "cash_net_retail": round(cash_sales_retail - _out_scope("retail"), 2),
               "cash_net": round(cash_sales - cash_out, 2),
               "category_report": category_report}
    if await _feat("perf.cache_reports"):
        _rcache_set(f"rs:{d}", summary, 20.0 if d == wib_today() else 90000.0)
    return summary

@api.get("/reports/range")
async def report_range(start: str, end: str, admin: dict = Depends(admin_or_kasir)):
    s_utc, _ = wib_day_range(start)
    _, e_utc = wib_day_range(end)
    q = {"status": "paid", "created_at": {"$gte": s_utc, "$lt": e_utc}}
    orders = await db.orders.find(q, {"_id": 0}).to_list(20000)
    daily = {}
    for o in orders:
        day = wib_day_of(o["created_at"])
        daily.setdefault(day, {"date": day, "total": 0, "count": 0, "fnb": 0, "retail": 0})
        daily[day]["total"] += o["total"]
        daily[day]["count"] += 1
        if o["order_type"] == "retail":
            daily[day]["retail"] += o["total"]
        else:
            daily[day]["fnb"] += o["total"]
    return {"daily": sorted(daily.values(), key=lambda x: x["date"])}

async def _period_report(start: str, end: str):
    if await _feat("perf.cache_reports"):
        try:
            if end.replace("-", "") < wib_today().replace("-", ""):  # periode lampau = immutable
                hit = _rcache_get(f"pr:{start}:{end}")
                if hit is not None:
                    return hit
        except Exception:
            pass
    s_utc, _ = wib_day_range(start)
    _, e_utc = wib_day_range(end)
    q = {"status": "paid", "created_at": {"$gte": s_utc, "$lt": e_utc}}
    orders = await db.orders.find(q, {"_id": 0}).to_list(50000)
    prods = await db.products.find({}, {"_id": 0, "id": 1, "category_id": 1, "type": 1}).to_list(5000)
    prod_map = {p["id"]: p for p in prods}
    cats_all = await db.categories.find({}, {"_id": 0}).to_list(1000)
    cat_map = {c["id"]: c for c in cats_all}
    by_type = {"dine_in": {"count": 0, "total": 0}, "take_away": {"count": 0, "total": 0}, "retail": {"count": 0, "total": 0}}
    by_pm = {}
    cat_sales = {}
    group_totals = {"makanan": 0, "minuman": 0, "retail": 0}
    product_sales = {}
    total = 0; total_discount = 0; total_cost = 0
    for o in orders:
        bt = by_type[o["order_type"]]
        bt["count"] += 1
        bt["total"] += o["total"]
        total += o["total"]
        total_discount += o.get("discount", 0)
        for _pn, _pt, _pa in _order_pay_parts(o):
            by_pm[_pn] = by_pm.get(_pn, 0) + _pa
        for it in o["items"]:
            line = it["price"] * it["qty"]
            ps = product_sales.setdefault(it["name"], {"qty": 0, "total": 0, "cost": 0})
            ps["qty"] += it["qty"]; ps["total"] += line; ps["cost"] += it.get("cost", 0) * it["qty"]
            total_cost += it.get("cost", 0) * it["qty"]
            pinfo = prod_map.get(it.get("product_id"), {})
            itype = pinfo.get("type") or it.get("type") or "retail"
            if itype in group_totals:
                group_totals[itype] += line
            cid = pinfo.get("category_id")
            if cid:
                cinfo = cat_map.get(cid, {})
                cs = cat_sales.setdefault(cid, {"category_id": cid, "name": cinfo.get("name", "?"),
                                                "type": cinfo.get("type", itype), "qty": 0, "total": 0})
                cs["qty"] += it["qty"]; cs["total"] += line
    # laba kotor per toko (F&B vs retail) — untuk KPI di halaman Laporan
    cost_fnb = 0.0; cost_retail = 0.0; vendor_exp_fnb = 0.0
    for o in orders:
        for it in o.get("items", []):
            if it.get("type") == "retail":
                cost_retail += (it.get("cost") or 0) * it["qty"]
            else:
                cost_fnb += (it.get("cost") or 0) * it["qty"]
            if it.get("type") == "vendor":
                vendor_exp_fnb += (it.get("vendor_total") or 0)
    fnb_total = by_type["dine_in"]["total"] + by_type["take_away"]["total"]
    retail_total = by_type["retail"]["total"]
    by_cat = sorted(cat_sales.values(), key=lambda x: x["total"], reverse=True)
    for c in by_cat:
        c["total"] = round(c["total"], 2)
    category_report = {
        "makanan": {"total": round(group_totals["makanan"], 2), "categories": [c for c in by_cat if c["type"] == "makanan"]},
        "minuman": {"total": round(group_totals["minuman"], 2), "categories": [c for c in by_cat if c["type"] == "minuman"]},
        "retail": {"total": round(group_totals["retail"], 2), "categories": [c for c in by_cat if c["type"] == "retail"]},
    }
    top = []
    for k, v in sorted(product_sales.items(), key=lambda x: x[1]["total"], reverse=True)[:10]:
        profit = v["total"] - v["cost"]
        margin = round(profit / v["total"] * 100, 1) if v["total"] else 0
        top.append({"name": k, "qty": v["qty"], "total": round(v["total"], 2), "profit": round(profit, 2), "margin": margin})
    vendor = await _vendor_report(start=start, end=end)
    rep = {"start": start, "end": end, "total_sales": round(total, 2), "order_count": len(orders),
           "total_discount": round(total_discount, 2), "total_cost": round(total_cost, 2),
           "gross_profit": round(total - total_cost, 2), "by_type": by_type, "by_payment": by_pm,
           "fnb_total": round(fnb_total, 2), "retail_total": round(retail_total, 2),
           "gross_profit_fnb": round(fnb_total - cost_fnb - vendor_exp_fnb, 2),
           "gross_profit_retail": round(retail_total - cost_retail, 2),
           "category_report": category_report, "top_products": top, "vendor": vendor}
    if await _feat("perf.cache_reports"):
        try:
            if end.replace("-", "") < wib_today().replace("-", ""):
                _rcache_set(f"pr:{start}:{end}", rep, 604800.0)  # 7 hari
        except Exception:
            pass
    return rep

@api.get("/reports/period")
async def report_period(start: str, end: str, admin: dict = Depends(admin_or_kasir)):
    return await _period_report(start, end)

def _period_report_lines(rep):
    cr = rep["category_report"]
    L = ["*Laporan Grand Aceh Kuliner*", f"Periode: {rep['start']} s/d {rep['end']}", "",
         f"Total Penjualan: Rp{rep['total_sales']:,.0f}",
         f"Jumlah Order: {rep['order_count']}",
         f"Laba Kotor: Rp{rep['gross_profit']:,.0f}",
         f"Total Diskon: Rp{rep['total_discount']:,.0f}", ""]
    for key, label in [("makanan", "Makanan"), ("minuman", "Minuman"), ("retail", "Retail")]:
        g = cr[key]
        L.append(f"{label}: Rp{g['total']:,.0f}")
        for c in g["categories"]:
            L.append(f"  - {c['name']} (x{c['qty']}): Rp{c['total']:,.0f}")
    v = rep.get("vendor", {})
    L += ["", f"Bagi Hasil Vendor: Rp{v.get('total_vendor_share', 0):,.0f} (omzet Rp{v.get('total_gross', 0):,.0f})"]
    for r in v.get("rows", []):
        L.append(f"  - {r['vendor_name']}: Rp{r['vendor_share']:,.0f}")
    return L

@api.get("/reports/period/export/excel")
async def export_period_excel(start: str, end: str, admin: dict = Depends(admin_or_kasir)):
    import openpyxl
    rep = await _period_report(start, end)
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Laporan"
    ws.append(["Laporan Grand Aceh Kuliner"])
    ws.append(["Periode", f"{start} s/d {end}"])
    ws.append([])
    ws.append(["Total Penjualan", rep["total_sales"]])
    ws.append(["Jumlah Order", rep["order_count"]])
    ws.append(["Laba Kotor", rep["gross_profit"]])
    ws.append(["Total Diskon", rep["total_discount"]])
    ws.append([])
    for key, label in [("makanan", "Makanan"), ("minuman", "Minuman"), ("retail", "Retail")]:
        g = rep["category_report"][key]
        ws.append([label, "", g["total"]])
        for c in g["categories"]:
            ws.append(["  " + c["name"], c["qty"], c["total"]])
        ws.append([])
    v = rep.get("vendor", {})
    ws.append(["Bagi Hasil Vendor"])
    ws.append(["Vendor", "Qty", "Omzet", "Bagi Hasil Vendor", "Bagian Outlet"])
    for r in v.get("rows", []):
        ws.append([r["vendor_name"], r["qty"], r["gross"], r["vendor_share"], r["outlet_share"]])
    ws.append(["TOTAL", "", v.get("total_gross", 0), v.get("total_vendor_share", 0), v.get("total_outlet_share", 0)])
    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f"attachment; filename=laporan-{start}_{end}.xlsx"})

@api.get("/reports/period/export/pdf")
async def export_period_pdf(start: str, end: str, admin: dict = Depends(admin_or_kasir)):
    from fpdf import FPDF
    rep = await _period_report(start, end)
    pdf = FPDF(); pdf.add_page(); pdf.set_font("Helvetica", size=12)
    for ln in _period_report_lines(rep):
        txt = ln.replace("*", "").encode("latin-1", "replace").decode("latin-1")
        pdf.multi_cell(pdf.epw, 7, txt or " ")
    out = io.BytesIO(bytes(pdf.output()))
    return StreamingResponse(out, media_type="application/pdf",
                             headers={"Content-Disposition": f"attachment; filename=laporan-{start}_{end}.pdf"})

# ================================================================== INVENTORY (Retail)
class PurchaseIn(BaseModel):
    product_id: str
    qty: int = Field(gt=0)
    unit_cost: float = Field(ge=0)
    note: Optional[str] = ""

@api.post("/purchases")
async def create_purchase(body: PurchaseIn, admin: dict = Depends(require_any_module("belanja_produk", "produk"))):
    p = await db.products.find_one({"id": body.product_id}, {"_id": 0})
    if not p:
        raise HTTPException(404, "Produk tidak ditemukan")
    if not p.get("track_stock"):
        raise HTTPException(400, "Pembelian stok hanya untuk produk retail")
    await db.products.update_one({"id": body.product_id},
                                 {"$inc": {"stock": body.qty}, "$set": {"cost": body.unit_cost}})
    doc = {"id": new_id(), "product_id": p["id"], "product_name": p["name"], "sku": p["sku"],
           "qty": body.qty, "unit_cost": body.unit_cost, "total_cost": round(body.qty * body.unit_cost, 2),
           "note": body.note, "by": admin["name"], "created_at": now_utc().isoformat()}
    await db.purchases.insert_one(doc)
    _cache_del("products:")
    doc.pop("_id", None)
    return {**doc, "new_stock": p.get("stock", 0) + body.qty}

class BulkPurchaseItemIn(BaseModel):
    product_id: Optional[str] = None
    create_new: bool = False
    name: Optional[str] = None
    category_id: Optional[str] = None
    price: Optional[float] = None
    qty: int = Field(gt=0)
    unit_cost: float = Field(ge=0)

class BulkPurchaseIn(BaseModel):
    items: List[BulkPurchaseItemIn]
    note: Optional[str] = "Faktur AI"

@api.post("/purchases/bulk")
async def create_purchases_bulk(body: BulkPurchaseIn, admin: dict = Depends(require_any_module("belanja_produk", "produk"))):
    if not body.items:
        raise HTTPException(400, "Tidak ada item untuk disimpan")
    # Validate all items before writing anything
    for it in body.items:
        if it.create_new:
            if not (it.name and it.name.strip()) or not it.category_id:
                raise HTTPException(400, f"Produk baru '{it.name or '?'}' butuh nama & kategori")
            if not await db.categories.find_one({"id": it.category_id}):
                raise HTTPException(400, f"Kategori untuk '{it.name}' tidak valid")
        else:
            if not it.product_id:
                raise HTTPException(400, "Item lama butuh product_id")
            p = await db.products.find_one({"id": it.product_id}, {"_id": 0})
            if not p:
                raise HTTPException(404, f"Produk '{it.name or it.product_id}' tidak ditemukan")
            if not p.get("track_stock"):
                raise HTTPException(400, f"'{p['name']}' bukan produk retail (tidak melacak stok)")
    saved, created_products = [], 0
    for it in body.items:
        if it.create_new:
            prod = {"id": new_id(), "name": it.name.strip(), "sku": "AI-" + new_id()[:6],
                    "category_id": it.category_id, "type": "retail",
                    "price": float(it.price if it.price is not None else it.unit_cost),
                    "cost": float(it.unit_cost), "description": "", "image": "", "active": True,
                    "sold_out": False, "stock": 0, "min_stock": 10, "track_stock": True,
                    "created_at": now_utc().isoformat()}
            await db.products.insert_one(prod)
            pid, pname, psku, base_stock = prod["id"], prod["name"], prod["sku"], 0
            created_products += 1
        else:
            p = await db.products.find_one({"id": it.product_id}, {"_id": 0})
            pid, pname, psku, base_stock = p["id"], p["name"], p["sku"], p.get("stock", 0)
        await db.products.update_one({"id": pid}, {"$inc": {"stock": it.qty}, "$set": {"cost": it.unit_cost}})
        doc = {"id": new_id(), "product_id": pid, "product_name": pname, "sku": psku,
               "qty": it.qty, "unit_cost": it.unit_cost, "total_cost": round(it.qty * it.unit_cost, 2),
               "note": body.note, "by": admin["name"], "created_at": now_utc().isoformat()}
        await db.purchases.insert_one(doc)
        doc.pop("_id", None)
        saved.append({**doc, "new_stock": base_stock + it.qty})
    _cache_del("products:")
    return {"saved": len(saved), "created_products": created_products,
            "total_cost": round(sum(s["total_cost"] for s in saved), 2), "items": saved}

@api.get("/purchases")
async def list_purchases(date_str: Optional[str] = Query(None, alias="date"), admin: dict = Depends(require_any_module("belanja_produk", "produk"))):
    q = {}
    if date_str:
        s, e = wib_day_range(date_str)
        q["created_at"] = {"$gte": s, "$lt": e}
    return await db.purchases.find(q, {"_id": 0}).sort("created_at", -1).to_list(1000)

class OpnameIn(BaseModel):
    product_id: str
    counted_stock: int = Field(ge=0)
    note: Optional[str] = ""

@api.post("/stock-opname")
async def create_opname(body: OpnameIn, admin: dict = Depends(require_any_module("opname_produk", "produk"))):
    p = await db.products.find_one({"id": body.product_id}, {"_id": 0})
    if not p:
        raise HTTPException(404, "Produk tidak ditemukan")
    if not p.get("track_stock"):
        raise HTTPException(400, "Stok opname hanya untuk produk retail")
    system_stock = p.get("stock", 0)
    diff = body.counted_stock - system_stock
    await db.products.update_one({"id": body.product_id}, {"$set": {"stock": body.counted_stock}})
    doc = {"id": new_id(), "product_id": p["id"], "product_name": p["name"], "sku": p["sku"],
           "system_stock": system_stock, "counted_stock": body.counted_stock, "difference": diff,
           "note": body.note, "by": admin["name"], "created_at": now_utc().isoformat()}
    await db.stock_opname.insert_one(doc)
    _cache_del("products:")
    doc.pop("_id", None)
    return doc

@api.get("/stock-opname")
async def list_opname(date_str: Optional[str] = Query(None, alias="date"), admin: dict = Depends(require_any_module("opname_produk", "produk"))):
    q = {}
    if date_str:
        s, e = wib_day_range(date_str)
        q["created_at"] = {"$gte": s, "$lt": e}
    return await db.stock_opname.find(q, {"_id": 0}).sort("created_at", -1).to_list(1000)

class ProductOpnameBulkItemIn(BaseModel):
    product_id: str
    counted_stock: float = Field(ge=0)
    note: Optional[str] = ""

class ProductOpnameBulkIn(BaseModel):
    items: List[ProductOpnameBulkItemIn] = []

@api.post("/products/opname-bulk")
async def bulk_product_opname(body: ProductOpnameBulkIn, admin: dict = Depends(require_any_module("opname_produk", "produk"))):
    """Opname massal produk retail (dipakai thin-client & tab Stok Opname Produk)."""
    if not body.items:
        raise HTTPException(400, "Tidak ada item")
    out = []
    for it in body.items:
        p = await db.products.find_one({"id": it.product_id}, {"_id": 0})
        if not p or not p.get("track_stock"):
            continue
        system = float(p.get("stock") or 0)
        counted = round(float(it.counted_stock), 2)
        diff = round(counted - system, 2)
        await db.products.update_one({"id": it.product_id}, {"$set": {"stock": counted}})
        doc = {"id": new_id(), "product_id": p["id"], "product_name": p["name"], "sku": p["sku"],
               "system_stock": system, "counted_stock": counted, "difference": diff,
               "note": it.note or "", "by": admin["name"], "created_at": now_utc().isoformat()}
        await db.stock_opname.insert_one(doc)
        out.append({"product_id": it.product_id, "name": p["name"],
                    "system_stock": system, "counted_stock": counted, "difference": diff})
    _cache_del("products:")
    return {"ok": True, "count": len(out), "rows": out}

# ================================================================== MASTER BAHAN (bahan baku resep + daftar belanja)
# Bahan = stok gudang yg TIDAK dijual langsung; dipakai di resep (HPP), punya
# pembelian & stok opname sendiri, dan menjadi dasar daftar belanja harian.

class IngredientIn(BaseModel):
    name: str
    unit: str = ""
    stock: float = 0
    min_stock: float = 0
    cost: float = 0          # harga beli per unit (HPP bahan)
    note: Optional[str] = ""
    active: bool = True

@api.get("/ingredients")
async def list_ingredients(active_only: bool = False, q: Optional[str] = None,
                           user: dict = Depends(require_any_module("produk", "belanja_bahan", "opname_bahan"))):
    flt = {"active": True} if active_only else {}
    cur = db.ingredients.find(flt, {"_id": 0}).sort("name", 1)
    rows = await cur.to_list(2000)
    if q:
        ql = q.lower()
        rows = [r for r in rows if ql in r["name"].lower() or ql in (r.get("sku") or "").lower()]
    # status stok rendah utk UI
    for r in rows:
        st = float(r.get("stock") or 0)
        mn = float(r.get("min_stock") or 0)
        r["low"] = mn > 0 and st <= mn
    return rows

@api.post("/ingredients")
async def create_ingredient(body: IngredientIn, admin: dict = Depends(require_any_module("produk", "belanja_bahan"))):
    name = body.name.strip()
    if not name:
        raise HTTPException(400, "Nama bahan wajib diisi")
    if await db.ingredients.find_one({"name": name}):
        raise HTTPException(400, f"Bahan '{name}' sudah ada")
    doc = {"id": new_id(), "name": name, "unit": body.unit.strip(),
           "stock": round(float(body.stock or 0), 2), "min_stock": round(float(body.min_stock or 0), 2),
           "cost": round(float(body.cost or 0), 2), "note": body.note, "active": bool(body.active),
           "created_at": now_utc().isoformat()}
    await db.ingredients.insert_one(doc)
    doc.pop("_id", None)
    return doc

@api.put("/ingredients/{iid}")
async def update_ingredient(iid: str, body: IngredientIn, admin: dict = Depends(require_any_module("produk", "belanja_bahan"))):
    cur = await db.ingredients.find_one({"id": iid}, {"_id": 0})
    if not cur:
        raise HTTPException(404, "Bahan tidak ditemukan")
    name = body.name.strip()
    if not name:
        raise HTTPException(400, "Nama bahan wajib diisi")
    dup = await db.ingredients.find_one({"name": name, "id": {"$ne": iid}})
    if dup:
        raise HTTPException(400, f"Bahan '{name}' sudah ada")
    upd = {"name": name, "unit": body.unit.strip(), "min_stock": round(float(body.min_stock or 0), 2),
           "cost": round(float(body.cost or 0), 2), "note": body.note,
           "active": bool(body.active), "updated_at": now_utc().isoformat()}
    await db.ingredients.update_one({"id": iid}, {"$set": upd})
    return {**cur, **upd, "id": iid}

@api.delete("/ingredients/{iid}")
async def delete_ingredient(iid: str, admin: dict = Depends(require_any_module("produk", "belanja_bahan"))):
    used = await db.recipes.find_one({"ingredients.ingredient_id": iid}, {"_id": 0, "product_id": 1, "name": 1})
    if used:
        raise HTTPException(400, f"Bahan sedang dipakai resep (produk {used.get('name') or used.get('product_id')}) — hapus dari resep dulu")
    await db.ingredients.delete_one({"id": iid})
    await db.ingredient_purchases.delete_many({"ingredient_id": iid})
    await db.ingredient_opname.delete_many({"ingredient_id": iid})
    return {"ok": True}

class IngPurchaseIn(BaseModel):
    qty: float = Field(gt=0)
    unit_cost: float = Field(ge=0)
    note: Optional[str] = ""

@api.post("/ingredients/{iid}/purchase")
async def create_ingredient_purchase(iid: str, body: IngPurchaseIn, admin: dict = Depends(require_any_module("belanja_bahan", "produk"))):
    ing = await db.ingredients.find_one({"id": iid}, {"_id": 0})
    if not ing:
        raise HTTPException(404, "Bahan tidak ditemukan")
    qty = round(float(body.qty), 2)
    cost = round(float(body.unit_cost), 2)
    new_stock = round(float(ing.get("stock") or 0) + qty, 2)
    await db.ingredients.update_one({"id": iid}, {"$set": {"stock": new_stock, "cost": cost}})
    doc = {"id": new_id(), "ingredient_id": iid, "ingredient_name": ing["name"],
           "unit": ing.get("unit", ""), "qty": qty, "unit_cost": cost,
           "total_cost": round(qty * cost, 2), "note": body.note, "by": admin["name"],
           "created_at": now_utc().isoformat()}
    await db.ingredient_purchases.insert_one(doc)
    doc.pop("_id", None)
    return {**doc, "new_stock": new_stock}

@api.get("/ingredient-purchases")
async def list_ingredient_purchases(date_str: Optional[str] = Query(None, alias="date"),
                                    user: dict = Depends(require_any_module("belanja_bahan", "produk"))):
    q = {}
    if date_str:
        s, e = wib_day_range(date_str)
        q["created_at"] = {"$gte": s, "$lt": e}
    return await db.ingredient_purchases.find(q, {"_id": 0}).sort("created_at", -1).to_list(2000)

class IngOpnameIn(BaseModel):
    counted_stock: float = Field(ge=0)
    note: Optional[str] = ""

@api.post("/ingredients/{iid}/opname")
async def create_ingredient_opname(iid: str, body: IngOpnameIn, admin: dict = Depends(require_any_module("opname_bahan", "produk"))):
    ing = await db.ingredients.find_one({"id": iid}, {"_id": 0})
    if not ing:
        raise HTTPException(404, "Bahan tidak ditemukan")
    system = float(ing.get("stock") or 0)
    counted = round(float(body.counted_stock), 2)
    diff = round(counted - system, 2)
    await db.ingredients.update_one({"id": iid}, {"$set": {"stock": counted}})
    doc = {"id": new_id(), "ingredient_id": iid, "ingredient_name": ing["name"],
           "unit": ing.get("unit", ""), "system_stock": system, "counted_stock": counted,
           "difference": diff, "note": body.note, "by": admin["name"],
           "created_at": now_utc().isoformat()}
    await db.ingredient_opname.insert_one(doc)
    doc.pop("_id", None)
    return doc

@api.get("/ingredient-opname")
async def list_ingredient_opname(date_str: Optional[str] = Query(None, alias="date"),
                                 user: dict = Depends(require_any_module("opname_bahan", "produk"))):
    q = {}
    if date_str:
        s, e = wib_day_range(date_str)
        q["created_at"] = {"$gte": s, "$lt": e}
    return await db.ingredient_opname.find(q, {"_id": 0}).sort("created_at", -1).to_list(2000)

# ---- operasi massal (tab Pembelian / Stok Opname & thin-client APK) ----
class IngBulkPurchaseItemIn(BaseModel):
    ingredient_id: str
    qty: float = Field(gt=0)
    unit_cost: float = Field(ge=0)
    note: Optional[str] = ""

class IngBulkPurchaseIn(BaseModel):
    items: List[IngBulkPurchaseItemIn] = []
    date: Optional[str] = None

@api.post("/ingredients/purchase-bulk")
async def bulk_ingredient_purchase(body: IngBulkPurchaseIn, admin: dict = Depends(require_any_module("belanja_bahan", "produk"))):
    if not body.items:
        raise HTTPException(400, "Tidak ada item")
    out = []
    for it in body.items:
        ing = await db.ingredients.find_one({"id": it.ingredient_id}, {"_id": 0})
        if not ing:
            continue
        qty = round(float(it.qty), 2)
        cost = round(float(it.unit_cost), 2)
        new_stock = round(float(ing.get("stock") or 0) + qty, 2)
        await db.ingredients.update_one({"id": it.ingredient_id}, {"$set": {"stock": new_stock, "cost": cost}})
        doc = {"id": new_id(), "ingredient_id": it.ingredient_id, "ingredient_name": ing["name"],
               "unit": ing.get("unit", ""), "qty": qty, "unit_cost": cost,
               "total_cost": round(qty * cost, 2), "note": it.note or "", "by": admin["name"],
               "created_at": now_utc().isoformat()}
        await db.ingredient_purchases.insert_one(doc)
        out.append({"ingredient_id": it.ingredient_id, "name": ing["name"], "qty": qty, "new_stock": new_stock})
    return {"ok": True, "count": len(out), "rows": out}

class IngOpnameBulkItemIn(BaseModel):
    ingredient_id: str
    counted_stock: float = Field(ge=0)
    note: Optional[str] = ""

class IngOpnameBulkIn(BaseModel):
    items: List[IngOpnameBulkItemIn] = []
    date: Optional[str] = None

@api.post("/ingredients/opname-bulk")
async def bulk_ingredient_opname(body: IngOpnameBulkIn, admin: dict = Depends(require_any_module("opname_bahan", "produk"))):
    if not body.items:
        raise HTTPException(400, "Tidak ada item")
    out = []
    for it in body.items:
        ing = await db.ingredients.find_one({"id": it.ingredient_id}, {"_id": 0})
        if not ing:
            continue
        system = float(ing.get("stock") or 0)
        counted = round(float(it.counted_stock), 2)
        diff = round(counted - system, 2)
        await db.ingredients.update_one({"id": it.ingredient_id}, {"$set": {"stock": counted}})
        doc = {"id": new_id(), "ingredient_id": it.ingredient_id, "ingredient_name": ing["name"],
               "unit": ing.get("unit", ""), "system_stock": system, "counted_stock": counted,
               "difference": diff, "note": it.note or "", "by": admin["name"],
               "created_at": now_utc().isoformat()}
        await db.ingredient_opname.insert_one(doc)
        out.append({"ingredient_id": it.ingredient_id, "name": ing["name"],
                    "system_stock": system, "counted_stock": counted, "difference": diff})
    return {"ok": True, "count": len(out), "rows": out}

class AIInvoiceIn(BaseModel):
    image: str

# ---- vision: foto struk/faktur belanja bahan -> item -> komit pembelian ----
class IngVisionCommitItemIn(BaseModel):
    name: str
    qty: float = Field(gt=0)
    unit: str = ""
    amount: float = Field(ge=0)   # total biaya baris di struk

@api.post("/ai/ingredient-vision")
async def ai_ingredient_vision(body: AIInvoiceIn, admin: dict = Depends(require_any_module("belanja_bahan", "produk"))):
    """Scan foto struk belanja bahan baku -> daftar item {name,qty,unit,amount}."""
    if not await _ai_allowed("vision"):
        raise HTTPException(400, "Fitur AI 'Baca Faktur (Vision)' dimatikan. Nyalakan di Pengaturan → Fitur & Integrasi.")
    cfg = await _ai_cfg("vision")
    if not (cfg["api_key"] and cfg["base_url"] and cfg["model"]):
        raise HTTPException(400, "Konfigurasi AI 'Baca Faktur (Vision)' belum lengkap di Pengaturan AI")
    img = body.image if body.image.startswith("data:") else f"data:image/jpeg;base64,{body.image}"
    system = "Anda asisten yang membaca foto struk/nota belanja bahan baku dapur & kafe."
    prompt = ('Baca foto struk belanja bahan baku berikut. Kembalikan HANYA JSON array. '
              'Tiap elemen: {"name": "nama bahan", "qty": angka jumlah dibeli, "unit": "satuan jika ada (kg/gram/liter/pcs/dus/ikat/dll)", '
              '"amount": total biaya baris tsb dalam Rupiah (angka saja tanpa titik/koma)}. '
              'JANGAN sertakan barang non-bahan (mis. rokok) bila ragu boleh tetap masuk. '
              'Bila struk tidak terbaca/tidak jelas, kembalikan []. Tanpa teks lain.')
    from openai import OpenAI

    def run():
        client = OpenAI(api_key=cfg["api_key"], base_url=cfg["base_url"])
        r = client.chat.completions.create(
            model=cfg["model"],
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": img}},
                ]},
            ],
            max_tokens=1800, temperature=0,
        )
        return r.choices[0].message.content or ""
    try:
        raw = await asyncio.to_thread(run)
    except Exception as e:
        logger.error(f"ingredient-vision AI error: {e}")
        raise HTTPException(400, "Model AI yang dipilih tidak mendukung pembacaan gambar. Ganti model Vision di Pengaturan AI.")
    items = _extract_json_list(raw)
    cleaned = []
    for it in items:
        if not isinstance(it, dict):
            continue
        try:
            qty = float(it.get("qty") or 0)
            amt = float(it.get("amount") or 0)
        except (ValueError, TypeError):
            qty, amt = 0, 0
        name = str(it.get("name") or "").strip()
        if not name or qty <= 0:
            continue
        cleaned.append({"name": name[:80], "qty": round(qty, 2),
                        "unit": str(it.get("unit") or "").strip()[:20],
                        "amount": round(max(amt, 0), 2)})
    return {"items": cleaned, "count": len(cleaned),
            "total": round(sum(i["amount"] for i in cleaned), 2)}

@api.post("/ingredients/vision-commit")
async def commit_ingredient_vision(body: dict, admin: dict = Depends(require_any_module("belanja_bahan", "produk"))):
    """Simpan hasil scan menjadi pembelian bahan. Bahan baru otomatis dibuat bila belum ada."""
    raw = body.get("items") if isinstance(body.get("items"), list) else []
    if not raw:
        raise HTTPException(400, "Tidak ada item")
    created, updated, failed = [], [], []
    for it in raw[:100]:
        if not isinstance(it, dict):
            continue
        name = str(it.get("name") or "").strip()
        try:
            qty = round(float(it.get("qty") or 0), 2)
            amt = round(float(it.get("amount") or 0), 2)
        except (ValueError, TypeError):
            qty, amt = 0, 0
        if not name or qty <= 0:
            failed.append({"name": name or "?", "reason": "nama/jumlah tidak valid"})
            continue
        unit = str(it.get("unit") or "").strip()[:20]
        unit_cost = round(amt / qty, 2) if amt > 0 and qty > 0 else 0
        ing = await db.ingredients.find_one({"name": name}, {"_id": 0})
        is_new = ing is None
        if is_new:
            ing = {"id": new_id(), "name": name, "unit": unit, "stock": 0.0,
                   "min_stock": 0, "cost": unit_cost, "note": "dari scan faktur",
                   "active": True, "created_at": now_utc().isoformat()}
            await db.ingredients.insert_one(ing)
        else:
            await db.ingredients.update_one({"id": ing["id"]}, {"$set": {"cost": unit_cost or ing.get("cost", 0),
                                                                          "unit": unit or ing.get("unit", "")}})
        new_stock = round(float(ing["stock"]) + qty, 2)
        await db.ingredients.update_one({"id": ing["id"]}, {"$set": {"stock": new_stock}})
        doc = {"id": new_id(), "ingredient_id": ing["id"], "ingredient_name": ing["name"],
               "unit": unit or ing.get("unit", ""), "qty": qty, "unit_cost": unit_cost,
               "total_cost": round(qty * unit_cost, 2), "note": "Scan faktur (AI)", "by": admin["name"],
               "created_at": now_utc().isoformat()}
        await db.ingredient_purchases.insert_one(doc)
        (created if is_new else updated).append({"name": ing["name"], "qty": qty, "new_stock": new_stock})
    return {"ok": True, "created": created, "updated": updated, "failed": failed,
            "count": len(created) + len(updated)}

@api.post("/ingredients/import")
async def import_ingredients(file: UploadFile = File(...), admin: dict = Depends(require_any_module("produk", "belanja_bahan"))):
    """Import master bahan dari file Excel (.xlsx). Kolom (baris pertama = judul):
    Nama | Satuan | Stok | Stok Minimum | Harga Beli | Catatan.
    Bahan yang sudah ada (nama sama persis) diperbarui (satuan/min/harga bila diisi)."""
    if not (file.filename or "").lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "File harus .xlsx")
    import openpyxl
    data = await file.read()
    if len(data) > 5_000_000:
        raise HTTPException(400, "File maksimal 5MB")
    try:
        wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    except Exception:
        raise HTTPException(400, "File Excel tidak bisa dibaca")
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if len(rows) < 2:
        raise HTTPException(400, "File kosong — butuh baris judul + minimal 1 baris data")
    def colidx(headers):
        out = {}
        aliases = {
            "nama": ["nama", "nama bahan", "bahan", "nama material"],
            "satuan": ["satuan", "unit"],
            "stok": ["stok", "stok awal", "stock"],
            "min": ["stok minimum", "minimum", "min", "stok min"],
            "harga": ["harga beli", "harga", "cost", "harga/satuan", "harga per satuan"],
            "catatan": ["catatan", "keterangan", "note"],
        }
        for i, h in enumerate(headers):
            hl = str(h or "").strip().lower()
            for key, al in aliases.items():
                if hl in al:
                    out[key] = i
                    break
        return out
    def numcell(v):
        try:
            if v is None or str(v).strip() == "":
                return None
            return round(float(v), 2)
        except (ValueError, TypeError):
            return None
    headers = rows[0]
    ci = colidx(headers)
    if "nama" not in ci:
        raise HTTPException(400, "Tidak menemukan kolom 'Nama' di baris pertama. Format: Nama | Satuan | Stok | Stok Minimum | Harga Beli | Catatan")
    created, updated, errors = [], [], []
    for i, row in enumerate(rows[1:], start=2):
        name = str(row[ci["nama"]] or "").strip() if ci["nama"] < len(row) else ""
        if not name:
            continue
        unit = str(row[ci["satuan"]] or "").strip() if ci.get("satuan") is not None and ci["satuan"] < len(row) else ""
        stock = numcell(row[ci["stok"]]) if ci.get("stok") is not None and ci["stok"] < len(row) else None
        mn = numcell(row[ci["min"]]) if ci.get("min") is not None and ci["min"] < len(row) else None
        cost = numcell(row[ci["harga"]]) if ci.get("harga") is not None and ci["harga"] < len(row) else None
        note = str(row[ci["catatan"]] or "").strip() if ci.get("catatan") is not None and ci["catatan"] < len(row) else ""
        stock = 0 if stock is None else stock
        mn = 0 if mn is None else mn
        cost = 0 if cost is None else cost
        cur = await db.ingredients.find_one({"name": name})
        if cur:
            upd = {"unit": unit or cur.get("unit", ""), "min_stock": mn,
                   "cost": cost if cost > 0 else float(cur.get("cost") or 0),
                   "note": note or cur.get("note", ""), "active": True}
            await db.ingredients.update_one({"id": cur["id"]}, {"$set": upd})
            updated.append({"name": name})
        else:
            doc = {"id": new_id(), "name": name, "unit": unit, "stock": stock, "min_stock": mn,
                   "cost": cost, "note": note, "active": True, "created_at": now_utc().isoformat()}
            await db.ingredients.insert_one(doc)
            created.append({"name": name})
    return {"ok": True, "created": created, "updated": updated,
            "count": len(created) + len(updated), "errors": errors[:50]}

# ================================================================== DAFTAR BELANJA BAHAN
# Lembar belanja harian: otomatis (stok <= stok minimum) + centang manual.
# Bisa dicetak (browser) & dikirim WA ke nomor tujuan khusus.

async def _ing_low_rows():
    """Bahan yang stoknya <= stok minimum (kandidat otomatis daftar belanja)."""
    out = []
    for r in await db.ingredients.find({"active": True}, {"_id": 0}).sort("name", 1).to_list(2000):
        stock = float(r.get("stock") or 0)
        mn = float(r.get("min_stock") or 0)
        if mn > 0 and stock <= mn:
            need = round(mn - stock, 2)
            out.append({"ingredient_id": r["id"], "name": r["name"], "unit": r.get("unit", ""),
                        "stock": stock, "min_stock": mn, "cost": float(r.get("cost") or 0),
                        "auto": True, "qty": need})
    return out

@api.get("/shopping-list/suggest")
async def shopping_suggest(date: Optional[str] = Query(None), user: dict = Depends(require_any_module("belanja_bahan", "produk"))):
    rows = await _ing_low_rows()
    return {"date": date or wib_today(), "items": rows, "source": "auto"}

class ShoppingItemIn(BaseModel):
    ingredient_id: Optional[str] = None   # kosong = bahan baru/manual (nama bebas)
    name: str
    unit: str = ""
    qty: float = Field(ge=0)
    stock: float = 0
    min_stock: float = 0
    cost: float = 0
    note: Optional[str] = ""
    bought: bool = False

class ShoppingListIn(BaseModel):
    date: str
    items: List[ShoppingItemIn]
    note: Optional[str] = ""

@api.put("/shopping-list")
async def save_shopping_list(body: ShoppingListIn, user: dict = Depends(require_any_module("belanja_bahan", "produk"))):
    wib_day_range(body.date)  # validasi
    items = []
    for it in body.items[:200]:
        name = (it.name or "").strip()
        if not name or it.qty <= 0:
            continue
        items.append({"ingredient_id": it.ingredient_id or None, "name": name, "unit": it.unit,
                      "qty": round(float(it.qty), 2), "stock": round(float(it.stock or 0), 2),
                      "min_stock": round(float(it.min_stock or 0), 2),
                      "cost": round(float(it.cost or 0), 2), "note": it.note, "bought": bool(it.bought)})
    await db.shopping_lists.update_one(
        {"date": body.date},
        {"$set": {"items": items, "note": body.note, "updated_at": now_utc().isoformat(),
                  "by": user.get("name", "")}},
        upsert=True)
    return {"ok": True, "date": body.date, "count": len(items)}

@api.get("/shopping-list")
async def get_shopping_list(date: Optional[str] = Query(None), user: dict = Depends(require_any_module("belanja_bahan", "produk", "opname_bahan"))):
    d = date or wib_today()
    doc = await db.shopping_lists.find_one({"date": d}, {"_id": 0})
    if doc:
        return doc
    rows = await _ing_low_rows()
    return {"date": d, "items": rows, "note": "", "generated_auto": True}

@api.delete("/shopping-list")
async def delete_shopping_list(date: str = Query(...), user: dict = Depends(require_any_module("belanja_bahan", "produk"))):
    await db.shopping_lists.delete_one({"date": date})
    return {"ok": True}

def _shopping_lines(items, total_est):
    L = []
    for it in items:
        line = f"- {it.get('name', '?')}: {it.get('qty', 0):g} {it.get('unit', '')}".rstrip()
        if it.get("cost"):
            line += f" (≈Rp{float(it.get('cost', 0)) * float(it.get('qty', 0)):,.0f})"
        if it.get("note"):
            line += f" — {it['note']}"
        L.append(line)
    return L

class ShoppingSendIn(BaseModel):
    date: Optional[str] = None
    items: Optional[List[ShoppingItemIn]] = None
    recipients: Optional[List[str]] = None
    note: Optional[str] = ""

@api.post("/shopping-list/send-wa")
async def send_shopping_wa(body: ShoppingSendIn, admin: dict = Depends(require_any_module("belanja_bahan", "produk"))):
    d = body.date or wib_today()
    if body.items:
        items = []
        for it in body.items[:200]:
            if (it.name or "").strip() and it.qty > 0:
                items.append({"name": it.name.strip(), "unit": it.unit, "qty": round(float(it.qty), 2),
                              "cost": round(float(it.cost or 0), 2), "note": it.note,
                              "ingredient_id": it.ingredient_id or None})
    else:
        sheet = await db.shopping_lists.find_one({"date": d}, {"_id": 0})
        if not sheet:
            rows = await _ing_low_rows()
            items = [{"name": r["name"], "unit": r["unit"], "qty": r["qty"], "cost": r["cost"]} for r in rows]
        else:
            items = sheet.get("items", [])
    if not items:
        raise HTTPException(400, "Daftar belanja kosong — tidak ada yang dikirim")
    total_est = sum(float(it.get("cost") or 0) * float(it.get("qty") or 0) for it in items)
    recips = body.recipients if body.recipients else (await _shopping_recipients())
    if not recips:
        raise HTTPException(400, "Belum ada nomor WhatsApp tujuan belanja. Atur di Pengaturan → WhatsApp & Laporan (nomor belanja bahan).")
    text = _tpl_fill("shopping", {
        "tanggal": d, "items": "\n".join(_shopping_lines(items, total_est)),
        "jumlah_item": len(items), "total_estimasi": f"Rp{total_est:,.0f}", "nama_aplikasi": _tpl_app_name(),
    })
    result = await _send_whatsapp(recips, text)
    if not any(x.get("ok") for x in result):
        raise HTTPException(400, f"Gagal kirim WhatsApp: {result[0].get('error') if result else 'tidak diketahui'}")
    return {"sent": result, "recipients": recips, "count": len(items)}

async def _shopping_recipients():
    doc = await db.settings.find_one({"_id": "shopping"}, {"_id": 0}) or {}
    return doc.get("recipients", []) or []

class ShoppingSettingsIn(BaseModel):
    recipients: List[str] = []
    request_on_close: bool = False

@api.get("/settings/shopping")
async def get_shopping_settings(user: dict = Depends(get_current_user)):
    doc = await db.settings.find_one({"_id": "shopping"}, {"_id": 0}) or {}
    return {"recipients": doc.get("recipients", []), "request_on_close": bool(doc.get("request_on_close")),
            "whatsapp_configured": await _wa_configured()}

@api.put("/settings/shopping")
async def put_shopping_settings(body: ShoppingSettingsIn, admin: dict = Depends(require_admin)):
    await db.settings.update_one({"_id": "shopping"}, {"$set": {
        "recipients": [r.strip() for r in body.recipients if r.strip()],
        "request_on_close": bool(body.request_on_close),
    }}, upsert=True)
    return {"ok": True}


# ================================================================== CASH MOVEMENTS
class CashIn(BaseModel):
    type: Literal["in", "out"]
    amount: float = Field(gt=0)
    category: str = "Lainnya"
    note: Optional[str] = ""
    scope: Literal["fnb", "retail", "general"] = "fnb"   # pengeluaran F&B / retail / umum

class CashBulkIn(BaseModel):
    items: List[CashIn]

class CashCatIn(BaseModel):
    categories: List[str]

@api.post("/cash")
async def create_cash(body: CashIn, user: dict = Depends(admin_or_kasir)):
    shift = await _current_shift(user)
    doc = {"id": new_id(), "type": body.type, "amount": body.amount, "category": body.category,
           "note": body.note, "scope": body.scope, "cashier_id": user["id"], "cashier_name": user["name"],
           "shift_id": shift["id"] if shift else None, "created_at": now_utc().isoformat()}
    await db.cash_movements.insert_one(doc)
    _bump_rs_gen()  # pengeluaran masuk ringkasan laporan hari itu
    doc.pop("_id", None)
    return doc

@api.post("/cash/bulk")
async def create_cash_bulk(body: CashBulkIn, user: dict = Depends(admin_or_kasir)):
    """Simpan banyak catatan kas sekaligus (dipakai hasil scan Vision pengeluaran)."""
    shift = await _current_shift(user)
    created = []
    for it in body.items:
        doc = {"id": new_id(), "type": it.type, "amount": it.amount, "category": it.category,
               "note": it.note, "scope": it.scope, "cashier_id": user["id"], "cashier_name": user["name"],
               "shift_id": shift["id"] if shift else None, "created_at": now_utc().isoformat()}
        await db.cash_movements.insert_one(doc)
        doc.pop("_id", None)
        created.append(doc)
    _bump_rs_gen()
    return {"created": created, "count": len(created)}

@api.get("/cash")
async def list_cash(date_str: Optional[str] = Query(None, alias="date"), user: dict = Depends(admin_or_kasir)):
    d = date_str or wib_today()
    s, e = wib_day_range(d)
    moves = await db.cash_movements.find({"created_at": {"$gte": s, "$lt": e}}, {"_id": 0}).sort("created_at", -1).to_list(2000)
    cin = sum(m["amount"] for m in moves if m["type"] == "in")
    cout = sum(m["amount"] for m in moves if m["type"] == "out")
    # Pisahkan pengeluaran per scope (F&B / Retail / Umum)
    def _scope_sum(typ, scope):
        return sum(m["amount"] for m in moves if m["type"] == typ and m.get("scope") == scope)
    return {"date": d, "movements": moves, "cash_in": round(cin, 2), "cash_out": round(cout, 2),
            "cash_net": round(cin - cout, 2),
            "out_fnb": round(_scope_sum("out", "fnb"), 2),
            "out_retail": round(_scope_sum("out", "retail"), 2),
            "out_general": round(_scope_sum("out", "general"), 2)}

@api.get("/cash/categories")
async def get_cash_categories(user: dict = Depends(admin_or_kasir)):
    doc = await db.settings.find_one({"_id": "cash"}, {"_id": 0}) or {}
    cats = doc.get("categories") or []
    merged = list(dict.fromkeys(["Bahan Baku", "Belanja Operasional", "Bayar Supplier", "Kasbon", "Lainnya"] + cats))
    return {"categories": merged}

@api.put("/cash/categories")
async def put_cash_categories(body: CashCatIn, admin: dict = Depends(require_admin)):
    clean = [c.strip() for c in body.categories if c and c.strip()]
    await db.settings.update_one({"_id": "cash"}, {"$set": {"categories": clean}}, upsert=True)
    return {"ok": True, "count": len(clean)}

# ================================================================== SYNC (local outlet server <-> cloud)
class SyncPushIn(BaseModel):
    orders: List[OrderIn]

@api.get("/sync/master")
async def sync_master(user: dict = Depends(get_current_user)):
    """Pull master data snapshot for a local outlet server / offline client."""
    products = await db.products.find({}, {"_id": 0}).to_list(5000)
    categories = await db.categories.find({}, {"_id": 0}).to_list(500)
    tables = await db.tables.find({"deleted": {"$ne": True}}, {"_id": 0}).to_list(500)
    pms = await db.payment_methods.find({}, {"_id": 0}).to_list(100)
    return {"server_time": now_utc().isoformat(), "products": products, "categories": categories,
            "tables": tables, "payment_methods": pms}

@api.post("/sync/push")
async def sync_push(body: SyncPushIn, user: dict = Depends(get_current_user)):
    """Push a batch of offline orders to cloud. Idempotent via client_ref."""
    results = []
    synced = 0
    for o in body.orders:
        try:
            res = await create_order(o, user)
            synced += 1
            results.append({"client_ref": o.client_ref, "status": "ok", "order_number": res.get("order_number")})
        except HTTPException as e:
            results.append({"client_ref": o.client_ref, "status": "error", "detail": e.detail})
    return {"synced": synced, "total": len(body.orders), "results": results, "server_time": now_utc().isoformat()}

# ================================================================== AI
def _get_chat(session, system, model):
    if not EMERGENT_LLM_KEY:
        raise HTTPException(400, "AI belum dikonfigurasi. Isi API key & endpoint provider Anda di Pengaturan AI.")
    from emergentintegrations.llm.chat import LlmChat
    return LlmChat(api_key=EMERGENT_LLM_KEY, session_id=session, system_message=system).with_model("gemini", model)

AI_FEATURES = {"description": "Deskripsi Produk", "image": "Gambar Produk", "summary": "Analisis Laporan", "vision": "Baca Faktur (Vision)", "assistant": "Asisten Admin"}

async def _ai_cfg(feature="description"):
    """Per-feature AI provider config: DB settings (editable in UI) override .env.
    Fallback order: feature-specific -> legacy flat -> .env defaults."""
    doc = await db.settings.find_one({"_id": "ai"}) or {}
    feat = (doc.get("features", {}) or {}).get(feature, {}) or {}
    return {
        "base_url": feat.get("base_url") or doc.get("openai_base_url") or OPENAI_COMPAT_BASE_URL,
        "api_key": feat.get("api_key") or doc.get("openai_api_key") or OPENAI_COMPAT_API_KEY,
        "model": feat.get("model") or doc.get("openai_model") or OPENAI_COMPAT_MODEL,
    }

async def _ai_provider_cfg(feature="description"):
    """Resolve which provider ('gemini' | 'chenzk') to use for a feature and its creds."""
    doc = await db.settings.find_one({"_id": "ai"}) or {}
    feat = (doc.get("features", {}) or {}).get(feature, {}) or {}
    provider = feat.get("provider")
    if not provider:
        # Infer for backward-compat: OpenAI-compatible creds present -> chenzk, else gemini.
        if feat.get("api_key") and (feat.get("base_url") or OPENAI_COMPAT_BASE_URL):
            provider = "chenzk"
        else:
            provider = "gemini"
    if provider == "gemini":
        # Jangan biarkan base_url/model chenzk lama "bocor" ke jalur Gemini:
        # model Gemini memakai default (GEMINI_TEXT_MODEL) bila field tidak diisi
        # model Gemini; base_url chenzk TIDAK pernah dipakai utk Gemini.
        return {"provider": "gemini",
                "api_key": feat.get("api_key") or GEMINI_API_KEY,
                "model": (feat.get("model") if (feat.get("model") or "").lower().startswith(("gemini", "learnlm", "models/")) else "") or GEMINI_TEXT_MODEL}
    return {"provider": "chenzk",
            "base_url": (feat.get("base_url") or doc.get("openai_base_url") or OPENAI_COMPAT_BASE_URL or CHENZK_BASE_URL),
            "api_key": feat.get("api_key") or doc.get("openai_api_key") or OPENAI_COMPAT_API_KEY,
            "model": feat.get("model") or doc.get("openai_model") or OPENAI_COMPAT_MODEL}

async def _ai_chat(messages, system="", feature="description", temperature=0.5, max_tokens=4000):
    """Unified text chat across providers. `messages`=[{role:'user'|'assistant',content:str}].
    Routes to Gemini REST (X-goog-api-key) or chenzk (OpenAI-compatible), else Emergent fallback."""
    if not await _ai_allowed(feature):
        label = FEATURE_LABELS.get(f"ai.{feature}") or feature
        raise HTTPException(400, f"Fitur '{label}' dimatikan. Nyalakan di Pengaturan → Fitur & Integrasi.")
    cfg = await _ai_provider_cfg(feature)
    if cfg["provider"] == "gemini":
        import httpx
        keys = await _gemini_keys(cfg.get("api_key"))
        if not keys:
            raise HTTPException(400, "Gemini API key belum diatur. Tambahkan di Pengaturan AI.")
        model = cfg["model"] or GEMINI_TEXT_MODEL
        contents = []
        for m in messages:
            role = "model" if m.get("role") == "assistant" else "user"
            contents.append({"role": role, "parts": [{"text": str(m.get("content", ""))}]})
        payload = {"contents": contents,
                   "generationConfig": {"temperature": temperature, "maxOutputTokens": max_tokens}}
        if system:
            payload["systemInstruction"] = {"parts": [{"text": system}]}
        url = f"{GEMINI_REST_URL}/{model}:generateContent"
        # Rotasi: mulai dari kursor, coba tiap key; lanjut ke berikutnya bila kena limit
        start = (_gemini_cursor["i"] % len(keys))
        order = keys[start:] + keys[:start]
        last_err = None
        await _breaker_check("ai-gemini")
        for i, key in enumerate(order):
            try:
                async with httpx.AsyncClient(timeout=60) as c:
                    r = await c.post(url, headers={"Content-Type": "application/json", "X-goog-api-key": key}, json=payload)
            except Exception as e:
                _breaker_fail("ai-gemini")
                last_err = HTTPException(400, f"Gagal menghubungi Gemini: {e}")
                continue
            if r.status_code == 200:
                _breaker_success("ai-gemini")
                _gemini_cursor["i"] = (start + i) % len(keys)  # ingat key yang berhasil
                data = r.json()
                try:
                    parts = data["candidates"][0]["content"]["parts"]
                    return "".join(p.get("text", "") for p in parts).strip()
                except Exception:
                    raise HTTPException(400, "Gemini tidak mengembalikan teks. Coba lagi atau ganti model.")
            txt = r.text[:200]
            if _rotate_quota(r.status_code, txt):
                last_err = HTTPException(400, f"Gemini key #{i + 1} kena limit/gagal (HTTP {r.status_code}): {txt}")
                continue
            _breaker_fail("ai-gemini")
            raise HTTPException(400, f"Gemini menolak permintaan (HTTP {r.status_code}): {txt}")
        raise last_err or HTTPException(400, "Semua Gemini API key gagal")
    if cfg["provider"] == "chenzk" and cfg.get("api_key") and cfg.get("base_url"):
        from openai import OpenAI
        msgs = ([{"role": "system", "content": system}] if system else []) + \
               [{"role": ("assistant" if m.get("role") == "assistant" else "user"), "content": str(m.get("content", ""))} for m in messages]

        def run():
            client = OpenAI(api_key=cfg["api_key"], base_url=cfg["base_url"])
            r = client.chat.completions.create(model=cfg["model"], messages=msgs,
                                               temperature=temperature, max_tokens=max_tokens)
            msg = r.choices[0].message
            content = (msg.content or "").strip()
            if not content:
                content = (getattr(msg, "reasoning_content", "") or "").strip()
            return content
        return await asyncio.to_thread(run)
    # Fallback: Emergent universal key (single-turn only)
    if not EMERGENT_LLM_KEY:
        raise HTTPException(400, "AI belum dikonfigurasi. Pilih provider (Gemini/chenzk) dan isi API key di Pengaturan AI.")
    from emergentintegrations.llm.chat import UserMessage
    chat = _get_chat(new_id(), system, "gemini-2.5-flash")
    last = messages[-1]["content"] if messages else ""
    return (await chat.send_message(UserMessage(text=last))).strip()

async def _gemini_text(system, prompt, feature="description"):
    """Text generation for description/summary — routes via unified provider chat."""
    return await _ai_chat([{"role": "user", "content": prompt}], system=system, feature=feature,
                          temperature=0.5, max_tokens=800 if feature == "description" else 4000)

async def _gemini_image(prompt):
    """Image via OpenAI-compatible image endpoint (only when explicitly configured for 'image'),
    else user's own Gemini key, else Emergent universal key."""
    if not await _ai_allowed("image"):
        raise HTTPException(400, "Fitur AI 'Gambar Produk' dimatikan. Nyalakan di Pengaturan → Fitur & Integrasi.")
    doc = await db.settings.find_one({"_id": "ai"}) or {}
    feat = (doc.get("features", {}) or {}).get("image", {}) or {}
    provider = feat.get("provider")
    # Kalau image dgn OpenAI-compatible (chenzk) HANYA bila provider-nya memang chenzk.
    if provider == "chenzk" and feat.get("api_key") and feat.get("base_url") and feat.get("model"):
        from openai import OpenAI

        def run():
            client = OpenAI(api_key=feat["api_key"], base_url=feat["base_url"])
            r = client.images.generate(model=feat["model"], prompt=prompt, n=1, size="1024x1024")
            d = r.data[0]
            b64 = getattr(d, "b64_json", None)
            if b64:
                return f"data:image/png;base64,{b64}"
            return getattr(d, "url", None)
        return await asyncio.to_thread(run)
    if GEMINI_API_KEY or await _gemini_keys():
        from google import genai
        from google.genai import types
        import base64
        keys = await _gemini_keys()
        last_err = None
        for key in keys:
            def run(k=key):
                client = genai.Client(api_key=k)
                r = client.models.generate_content(
                    model=GEMINI_IMAGE_MODEL, contents=prompt,
                    config=types.GenerateContentConfig(response_modalities=["IMAGE", "TEXT"]),
                )
                for cand in (r.candidates or []):
                    for part in (cand.content.parts or []):
                        inline = getattr(part, "inline_data", None)
                if inline and inline.data:
                    data = inline.data
                    b64 = base64.b64encode(data).decode() if isinstance(data, (bytes, bytearray)) else data
                    return f"data:{inline.mime_type or 'image/png'};base64,{b64}"
                return None
            try:
                return await asyncio.to_thread(run)
            except Exception as e:
                msg = str(e).lower()
                if any(w in msg for w in ("quota", "limit", "429", "resource exhausted", "permission", "api key")):
                    last_err = e
                    continue
                raise
        if last_err:
            raise HTTPException(400, f"Semua Gemini API key gagal untuk gambar: {last_err}")
        return None
    if not EMERGENT_LLM_KEY:
        raise HTTPException(400, "Generator gambar AI belum dikonfigurasi. Isi provider gambar Anda di Pengaturan AI, atau unggah gambar manual.")
    from emergentintegrations.llm.chat import UserMessage
    chat = _get_chat(new_id(), "You are a professional food & product photographer.",
                     "gemini-3.1-flash-image-preview").with_params(modalities=["image", "text"])
    _, images = await chat.send_message_multimodal_response(UserMessage(text=prompt))
    if images:
        img = images[0]
        return f"data:{img['mime_type']};base64,{img['data']}"
    return None

async def _save_image_local(src: str) -> str:
    """Persist an AI image (base64 data URL or remote URL) to local disk; return stable /api/uploads path so it never expires."""
    if not src:
        return src

    def run():
        import base64 as _b64, urllib.request
        if src.startswith("data:"):
            header, _, b64data = src.partition(",")
            mime = header[5:].split(";")[0] or "image/png"
            raw = _b64.b64decode(b64data)
        elif src.startswith("http"):
            req = urllib.request.Request(src, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read()
                mime = resp.headers.get_content_type() or "image/png"
        else:
            return src
        ext = {"image/png": "png", "image/jpeg": "jpg", "image/jpg": "jpg", "image/webp": "webp"}.get(mime, "png")
        fname = f"{new_id()}.{ext}"
        (UPLOAD_DIR / fname).write_bytes(raw)
        return f"/api/uploads/{fname}"
    return await asyncio.to_thread(run)

@api.get("/health")
async def health():
    return {"app": "gak-pos", "ok": True}

@api.get("/ota/version")
async def ota_version():
    """Versi OTA yang disajikan server — lewat API (CORS FastAPI *), jadi APK
    tidak perlu fetch /ota/version.json (nginx) yang rawan masalah CORS.
    Membaca file versi dari mount /host-project (ro)."""
    import json as _json
    version = ""
    for base in ("/host-project", os.environ.get("HOST_PROJECT_DIR", "")):
        if not base:
            continue
        p = os.path.join(base, "frontend", "build", "ota", "version.json")
        try:
            with open(p) as f:
                d = _json.load(f)
                version = str(d.get("version", "") or "").strip()
            if version:
                break
        except Exception:
            continue
    return {"version": version, "url": "/ota/bundle.zip"}

@api.get("/uploads/{fname}")
async def get_upload(fname: str):
    fp = UPLOAD_DIR / os.path.basename(fname)
    if not fp.exists():
        raise HTTPException(404, "File tidak ditemukan")
    return FileResponse(str(fp))

@api.get("/installers/project-zip")
async def download_project_zip(admin: dict = Depends(require_admin)):
    if not (PROJECT_ROOT / "docker-compose.yml").exists():
        raise HTTPException(404, "Folder proyek tidak tersedia di lingkungan ini.")
    EXCLUDE_DIRS = {"node_modules", ".git", "build", "__pycache__", ".venv", "venv",
                    "uploads", "backups", ".wwebjs_auth", ".wwebjs_cache", ".emergent",
                    "dist", ".pytest_cache", "test_reports", "memory", ".gradle",
                    ".idea", ".vscode", "coverage"}
    EXCLUDE_FILES = {".env", ".env.docker", ".env.local", ".DS_Store"}

    def build():
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=1) as zf:
            for root, dirs, files in os.walk(PROJECT_ROOT):
                dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
                for f in files:
                    if f in EXCLUDE_FILES or f.endswith(".env.local"):
                        continue
                    fp = os.path.join(root, f)
                    if os.path.islink(fp) or not os.path.isfile(fp):
                        continue
                    rel = os.path.relpath(fp, PROJECT_ROOT)
                    zf.write(fp, os.path.join("grand-aceh-pos", rel))
        buf.seek(0)
        return buf.read()

    data = await asyncio.to_thread(build)
    return Response(content=data, media_type="application/zip",
                    headers={"Content-Disposition": "attachment; filename=grand-aceh-pos.zip"})

@api.get("/backup/export")
async def backup_export(admin: dict = Depends(require_admin)):
    names = await db.list_collection_names()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in names:
            if name.startswith("system."):
                continue
            docs = await db[name].find({}).to_list(200000)
            zf.writestr(f"{name}.json", json_util.dumps(docs))
    buf.seek(0)
    ts = now_utc().strftime("%Y%m%d-%H%M%S")
    return Response(content=buf.getvalue(), media_type="application/zip",
                    headers={"Content-Disposition": f"attachment; filename=gak-backup-{ts}.zip"})

@api.post("/backup/import")
async def backup_import(file: UploadFile = File(...), admin: dict = Depends(require_admin)):
    raw = await file.read()
    try:
        zf = zipfile.ZipFile(io.BytesIO(raw))
    except Exception:
        raise HTTPException(400, "File backup tidak valid (.zip)")
    restored = 0
    for nm in zf.namelist():
        if not nm.endswith(".json"):
            continue
        coll = nm[:-5]
        docs = json_util.loads(zf.read(nm).decode("utf-8"))
        await db[coll].delete_many({})
        if docs:
            await db[coll].insert_many(docs)
        restored += 1
    return {"restored_collections": restored}

DOCKER_SOCK = "/var/run/docker.sock"

def _update_enabled():
    return os.path.exists(DOCKER_SOCK) and bool(os.environ.get("HOST_PROJECT_DIR"))

@api.get("/admin/update/status")
async def update_status(admin: dict = Depends(require_admin)):
    running = False
    log = ""
    if _update_enabled():
        try:
            import docker
            cli = docker.from_env()
            try:
                c = cli.containers.get("gak-updater")
                c.reload()
                running = c.status == "running"
                log = c.logs(tail=20).decode("utf-8", "ignore")[-1800:]
            except Exception:
                running = False
        except Exception:
            pass
    return {"enabled": _update_enabled(), "running": running, "log": log,
            "host_project_dir": os.environ.get("HOST_PROJECT_DIR")}

VIBE_UPDATE_BASE_URL = os.environ.get("VIBE_UPDATE_BASE_URL", "https://taqim258.vibecoder.co.id/pos-grand-update")
VIBE_REPORT_URL = os.environ.get("VIBE_REPORT_URL", "https://taqim258.vibecoder.co.id/pos-grand-update/rpt.php")
VIBE_REPORT_TOKEN = os.environ.get("VIBE_REPORT_TOKEN", "gak_rpt_7f3c9e1b")
VIBE_BACKUP_URL = os.environ.get("VIBE_BACKUP_URL", "https://taqim258.vibecoder.co.id/pos-grand-update/bkp.php")
VIBE_BACKUP_TOKEN = os.environ.get("VIBE_BACKUP_TOKEN", "gak_bkp_2a8d51c4")
VIBE_FEATURE_URL = os.environ.get("VIBE_FEATURE_URL", "https://taqim258.vibecoder.co.id/pos-grand-update/feat.php")
VIBE_FEATURE_TOKEN = os.environ.get("VIBE_FEATURE_TOKEN", "gak_feat_5b2d9e77")

class FeatureRequestIn(BaseModel):
    message: str
    context: Optional[str] = None

@api.post("/feature-request/send")
async def feature_request_send(body: FeatureRequestIn, admin: dict = Depends(admin_or_kasir)):
    """Kirim permintaan fitur dari tombol 'Usulkan Fitur' (Asisten AI) ke pusat vibecoder.co.id."""
    import urllib.request, json as _json
    msg = (body.message or "").strip()
    if not msg:
        raise HTTPException(400, "Permintaan fitur kosong")
    if len(msg) > 200_000:
        raise HTTPException(400, "Permintaan fitur terlalu panjang")
    ctx = (body.context or "").strip()
    payload = _json.dumps({"ts": datetime.now(timezone.utc).isoformat(), "message": msg, "context": ctx}).encode("utf-8")
    req = urllib.request.Request(
        VIBE_FEATURE_URL, data=payload,
        headers={"Content-Type": "application/json", "X-Gak-Token": VIBE_FEATURE_TOKEN},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            resp = r.read().decode("utf-8", "ignore")
        return {"ok": True, "response": resp[:500]}
    except Exception as e:
        raise HTTPException(502, f"Gagal mengirim ke vibecoder.co.id: {e}")

class DiagSendIn(BaseModel):
    report: str

@api.post("/diag/send")
async def diag_send(body: DiagSendIn, admin: dict = Depends(require_admin)):
    """Kirim laporan diagnostik dari tombol 'Kirim ke VibeCoder' ke pusat vibecoder.co.id."""
    import urllib.request, json as _json
    if not body.report or len(body.report) > 200_000:
        raise HTTPException(400, "Laporan kosong atau terlalu besar")
    payload = _json.dumps({"ts": datetime.now(timezone.utc).isoformat(), "report": body.report}).encode("utf-8")
    req = urllib.request.Request(
        VIBE_REPORT_URL, data=payload,
        headers={"Content-Type": "application/json", "X-Gak-Token": VIBE_REPORT_TOKEN},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            resp = r.read().decode("utf-8", "ignore")
        return {"ok": True, "response": resp[:500]}
    except Exception as e:
        raise HTTPException(502, f"Gagal mengirim ke vibecoder.co.id: {e}")

@api.get("/update/check")
async def update_check(admin: dict = Depends(require_admin)):
    """Cek versi terbaru di vibecoder.co.id (dipakai banner 'Versi baru tersedia' & laporan Diagnostik)."""
    import urllib.request, json
    current = ""
    # Folder proyek di-mount ke /host-project (ro) sejak docker-compose diperbarui;
    # fallback ke HOST_PROJECT_DIR untuk kompatibilitas.
    for base in ("/host-project", os.environ.get("HOST_PROJECT_DIR")):
        if not base:
            continue
        try:
            with open(os.path.join(base, ".vibecoder-version"), "r") as f:
                current = f.read().strip()
            if current:
                break
        except Exception:
            continue
    latest = ""
    reachable = False
    # Breaker update-center: bila terbuka (update center tak terjangkau), jangan jadikan
    # 503 — endpoint ini sengaja tidak boleh error; cukup lapor unreachable & latest kosong.
    try:
        await _breaker_check("update-center")
    except HTTPException:
        return {
            "enabled": bool(current),
            "current": current,
            "latest": "",
            "updateAvailable": False,
            "updateCenterReachable": False,
            "baseUrl": VIBE_UPDATE_BASE_URL,
        }
    try:
        with urllib.request.urlopen(f"{VIBE_UPDATE_BASE_URL}/version.json", timeout=8) as r:
            data = json.loads(r.read().decode("utf-8", "ignore"))
            latest = str(data.get("version", "") or "").strip()
            reachable = True
        _breaker_success("update-center")
    except Exception:
        _breaker_fail("update-center")
    return {
        "enabled": bool(current),
        "current": current,
        "latest": latest,
        "updateAvailable": bool(current and latest and latest != current),
        "updateCenterReachable": reachable,
        "baseUrl": VIBE_UPDATE_BASE_URL,
    }

@api.post("/backup/send-to-vibecoder")
async def backup_send_to_vibecoder(admin: dict = Depends(require_admin)):
    """Buat backup database lalu kirim salinannya ke pusat vibecoder.co.id (mirror tambahan).

    Menjalankan container docker:cli yang memanggil ./backup-to-vibecoder.sh di folder host.
    Backup lokal tetap dibuat di backups/; salinan di vibecoder bersifat cadangan tambahan.
    """
    if not os.path.exists(DOCKER_SOCK):
        raise HTTPException(400, "Fitur belum aktif. Jalankan update manual sekali (cd ~/grand-aceh-pos && ./update-pi.sh) untuk mengaktifkannya.")
    host_dir = os.environ.get("HOST_PROJECT_DIR")
    if not host_dir:
        raise HTTPException(400, "HOST_PROJECT_DIR belum diset. Jalankan update manual sekali untuk mengaktifkan fitur ini.")
    try:
        import docker
        cli = docker.from_env()
    except Exception as e:
        raise HTTPException(500, f"Docker tidak tersedia dari aplikasi: {e}")
    try:
        for c in cli.containers.list(all=True, filters={"name": "gak-backup-sender"}):
            try:
                c.remove(force=True)
            except Exception:
                pass
        image = os.environ.get("UPDATER_IMAGE", "docker:cli")
        cmd = "apk add --no-cache curl openssl >/dev/null 2>&1; cd /project && ./backup-to-vibecoder.sh"
        cli.containers.run(
            image,
            command=["sh", "-c", cmd],
            detach=True, remove=True, name="gak-backup-sender",
            volumes={
                DOCKER_SOCK: {"bind": DOCKER_SOCK, "mode": "rw"},
                host_dir: {"bind": "/project", "mode": "rw"},
            },
            working_dir="/project",
            environment={
                "VIBE_BACKUP_TOKEN": VIBE_BACKUP_TOKEN,
                "VIBE_BACKUP_PASS": os.environ.get("VIBE_BACKUP_PASS", ""),
                "VIBE_BACKUP_URL": VIBE_BACKUP_URL,
            },
        )
    except Exception as e:
        raise HTTPException(500, f"Gagal memulai backup: {e}")
    return {"started": True, "message": "Backup dibuat & dikirim ke vibecoder.co.id. Cek folder backups/ di server."}

@api.post("/admin/update")
async def admin_update(admin: dict = Depends(require_admin)):
    if not os.path.exists(DOCKER_SOCK):
        raise HTTPException(400, "Fitur update 1-klik belum aktif. Jalankan update manual sekali (cd ~/grand-aceh-pos && ./update-pi.sh) untuk mengaktifkannya.")
    host_dir = os.environ.get("HOST_PROJECT_DIR")
    if not host_dir:
        raise HTTPException(400, "HOST_PROJECT_DIR belum diset. Jalankan update manual sekali untuk mengaktifkan fitur ini.")
    try:
        import docker
        cli = docker.from_env()
    except Exception as e:
        raise HTTPException(500, f"Docker tidak tersedia dari aplikasi: {e}")
    try:
        for c in cli.containers.list(all=True, filters={"name": "gak-updater"}):
            try:
                c.remove(force=True)
            except Exception:
                pass
        image = os.environ.get("UPDATER_IMAGE", "docker:cli")
        cmd = (
            "apk add --no-cache git curl >/dev/null 2>&1; "
            "if [ -f /project/.vibecoder-version ]; then "
            "VER=\"$(cat /project/.vibecoder-version 2>/dev/null || true)\"; "
            "REMOTE=\"$(curl -fsSL -m 20 https://taqim258.vibecoder.co.id/pos-grand-update/version.json | sed -n 's/.*\"version\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p' | head -1 || true)\"; "
            "if [ -n \"$REMOTE\" ] && [ \"$REMOTE\" != \"$VER\" ]; then "
            "curl -fsSL -m 300 -o /tmp/gak-pos-update.tar.gz https://taqim258.vibecoder.co.id/pos-grand-update/pos-grand.tar.gz && "
            "tar xzf /tmp/gak-pos-update.tar.gz -C /project && rm -f /tmp/gak-pos-update.tar.gz && "
            "echo \"$REMOTE\" > /project/.vibecoder-version && echo \"Update ke versi $REMOTE\"; "
            "else "
            "echo 'Sudah versi terbaru, lewati unduhan.'; "
            "fi; "
            "else "
            "git config --global --add safe.directory /project; git -C /project pull --ff-only; "
            "fi; "
            "cd /project && docker compose up -d --build"
        )
        cli.containers.run(
            image,
            command=["sh", "-c", cmd],
            detach=True, remove=True, name="gak-updater",
            volumes={
                DOCKER_SOCK: {"bind": DOCKER_SOCK, "mode": "rw"},
                host_dir: {"bind": "/project", "mode": "rw"},
            },
            working_dir="/project",
        )
    except Exception as e:
        raise HTTPException(500, f"Gagal memulai update: {e}")
    return {"started": True, "message": "Update dimulai. Tunggu 2-10 menit, lalu muat ulang halaman."}


class AISettingsIn(BaseModel):
    feature: Literal["description", "image", "summary", "vision", "assistant"]
    provider: Optional[Literal["gemini", "chenzk"]] = None
    base_url: Optional[str] = None
    api_key: Optional[str] = None
    model: Optional[str] = None

class GeminiKeysIn(BaseModel):
    keys: List[str] = []

def _mask_key(k):
    if not k:
        return ""
    return "••••" + k[-4:] if len(k) >= 4 else "••••"

@api.get("/settings/ai")
async def get_ai_settings(admin: dict = Depends(admin_or_kasir)):
    doc = await db.settings.find_one({"_id": "ai"}) or {}
    feats = doc.get("features", {}) or {}
    out = {}
    for key, label in AI_FEATURES.items():
        f = feats.get(key, {}) or {}
        provider = f.get("provider")
        if not provider:
            provider = "chenzk" if (f.get("api_key") and (f.get("base_url") or OPENAI_COMPAT_BASE_URL)) else "gemini"
        if provider == "gemini":
            akey = f.get("api_key") or GEMINI_API_KEY
            base = ""
            m = f.get("model") or ""
            # model chenzk yang masih tersimpan tidak boleh tampil sbg model Gemini
            model = m if m.lower().startswith(("gemini", "learnlm", "models/")) else (GEMINI_IMAGE_MODEL if key == "image" else GEMINI_TEXT_MODEL)
        else:  # chenzk / OpenAI-compatible
            if key == "image":
                akey = f.get("api_key")
                base = f.get("base_url") or CHENZK_BASE_URL
                model = f.get("model") or ""
            else:
                akey = f.get("api_key") or doc.get("openai_api_key") or OPENAI_COMPAT_API_KEY
                base = f.get("base_url") or doc.get("openai_base_url") or OPENAI_COMPAT_BASE_URL or CHENZK_BASE_URL
                model = f.get("model") or doc.get("openai_model") or (OPENAI_COMPAT_MODEL if akey else "") or ""
        out[key] = {"label": label, "provider": provider, "base_url": base, "model": model,
                    "api_key_set": bool(akey), "api_key_last4": _mask_key(akey)}
    return {"features": out}

@api.put("/settings/ai")
async def put_ai_settings(body: AISettingsIn, admin: dict = Depends(require_admin)):
    upd = {}
    if body.provider is not None:
        upd[f"features.{body.feature}.provider"] = body.provider
    if body.base_url is not None:
        upd[f"features.{body.feature}.base_url"] = body.base_url.strip()
    if body.model is not None:
        upd[f"features.{body.feature}.model"] = body.model.strip()
    if body.api_key:  # only overwrite key when a new one is provided
        upd[f"features.{body.feature}.api_key"] = body.api_key.strip()
    if upd:
        await db.settings.update_one({"_id": "ai"}, {"$set": upd}, upsert=True)
    return {"ok": True}

@api.get("/settings/ai/gemini-keys")
async def get_gemini_keys(admin: dict = Depends(require_admin)):
    keys = await _gemini_keys()
    masked = [_mask_key(k) for k in keys]
    return {"keys": masked, "count": len(keys), "hasEnv": bool(GEMINI_API_KEY)}

@api.put("/settings/ai/gemini-keys")
async def put_gemini_keys(body: GeminiKeysIn, admin: dict = Depends(require_admin)):
    clean = [k.strip() for k in body.keys if k and k.strip()]
    await db.settings.update_one({"_id": "ai"}, {"$set": {"gemini_keys": clean}}, upsert=True)
    _gemini_cursor["i"] = 0
    return {"ok": True, "count": len(clean)}

def _model_price_rank(mid):
    m = (mid or "").lower()
    cheap = any(k in m for k in ["flash", "mini", "nano", "lite", "micro", "haiku", "small", "8b", "free"])
    return (0 if cheap else 1, m)

@api.get("/settings/ai/models")
async def ai_models(feature: str = "description", admin: dict = Depends(require_admin)):
    import httpx
    cfg = await _ai_cfg(feature)
    if not (cfg["api_key"] and cfg["base_url"]):
        raise HTTPException(400, "Isi & SIMPAN Base URL + API Key dulu, lalu muat model.")
    base = cfg["base_url"].rstrip("/")
    try:
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.get(f"{base}/models", headers={"Authorization": f"Bearer {cfg['api_key']}"})
    except Exception as e:
        raise HTTPException(400, f"Gagal menghubungi provider: {e}")
    if r.status_code != 200:
        raise HTTPException(400, f"Provider menolak permintaan (HTTP {r.status_code}).")
    data = r.json()
    items = data.get("data", data) if isinstance(data, dict) else data
    ids = [m.get("id") for m in items if isinstance(m, dict) and m.get("id")]
    ids = sorted(set(ids), key=_model_price_rank)
    return {"models": ids}

@api.get("/settings/ai/credit")
async def ai_credit(feature: str = "description", admin: dict = Depends(require_admin)):
    """Best-effort remaining credit lookup via OpenAI-compatible billing endpoints."""
    import httpx, datetime as _dt
    cfg = await _ai_cfg(feature)
    if not (cfg["api_key"] and cfg["base_url"]):
        return {"available": False, "message": "Konfigurasi belum lengkap untuk fitur ini."}
    base = cfg["base_url"].rstrip("/")
    headers = {"Authorization": f"Bearer {cfg['api_key']}"}
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            sub = await client.get(f"{base}/dashboard/billing/subscription", headers=headers)
            if sub.status_code != 200:
                return {"available": False, "message": f"Provider tidak menyediakan info kredit (HTTP {sub.status_code})."}
            s = sub.json()
            total = s.get("hard_limit_usd") or s.get("system_hard_limit_usd") or 0
            used = 0.0
            try:
                end = _dt.date.today() + _dt.timedelta(days=1)
                start = end - _dt.timedelta(days=100)
                u = await client.get(f"{base}/dashboard/billing/usage", headers=headers,
                                     params={"start_date": str(start), "end_date": str(end)})
                if u.status_code == 200:
                    used = (u.json().get("total_usage") or 0) / 100.0
            except Exception:
                pass
            return {"available": True, "total": round(float(total), 2), "used": round(used, 2),
                    "remaining": round(float(total) - used, 2), "currency": "USD"}
    except Exception as e:
        return {"available": False, "message": f"Gagal cek kredit: {e}"}

# ---------------------------------------------------------------- AI ADMIN ASSISTANT
class AIAssistantChatIn(BaseModel):
    session_id: Optional[str] = None
    message: str

class AIAssistantApplyIn(BaseModel):
    action: dict

ASSISTANT_SYSTEM = (
    "Anda adalah 'Asisten AI' untuk aplikasi kasir/POS 'Grand Aceh Kuliner'. "
    "Bahasa jawaban: Indonesia, ringkas, ramah, dan praktis. "
    "Anda bisa menjawab SEMUA pertanyaan: (a) laporan penjualan/belanja (gunakan data laporan_penjualan, "
    "tampilkan Rupiah, jujur bila data tidak tersedia), (b) cara pakai fitur aplikasi (gunakan panduan_aplikasi), "
    "(c) pengetahuan umum usaha. "
    "Anda membantu admin mengelola: produk, kategori, vendor, harga, diskon, dan metode pembayaran. "
    "PENTING: yang dapat MENERAPKAN perubahan data hanyalah admin; jika pengguna berperan kasir, "
    "tetap jawab dengan baik tapi JANGAN sertakan blok aksi — cukup jelaskan bahwa perubahan data perlu admin. "
    "Jika admin hanya bertanya/minta saran, jawab biasa TANPA blok aksi. "
    "Jika admin meminta PERUBAHAN DATA, jelaskan singkat lalu sertakan TEPAT SATU blok aksi berformat: "
    "<ACTION>{\"type\":\"...\", ...}</ACTION> berisi JSON valid (tanpa komentar). "
    "Jenis aksi yang didukung beserta field-nya:\n"
    "1) create_category: {\"type\":\"create_category\",\"name\":str,\"kind\":\"makanan|minuman|retail|vendor\"}\n"
    "2) create_vendor: {\"type\":\"create_vendor\",\"name\":str,\"contact\":str?,\"note\":str?}\n"
    "3) create_payment_method: {\"type\":\"create_payment_method\",\"name\":str,\"pm_type\":\"cash|qris|card\"}\n"
    "4) create_product: {\"type\":\"create_product\",\"name\":str,\"price\":number,\"kind\":\"makanan|minuman|retail|vendor\",\"category_name\":str,\"cost\":number?,\"stock\":number?,\"sku\":str?,\"description\":str?,\"vendor_name\":str?}\n"
    "5) create_products_bulk (BANYAK produk sekaligus dari daftar tempel): {\"type\":\"create_products_bulk\",\"items\":[{ ...field sama seperti create_product... }]}\n"
    "6) update_product: {\"type\":\"update_product\",\"name\":str,\"price\":number?,\"cost\":number?,\"stock\":number?,\"sold_out\":bool?,\"active\":bool?,\"description\":str?}\n"
    "7) deactivate_product (nonaktifkan produk): {\"type\":\"deactivate_product\",\"name\":str}\n"
    "8) delete_product (hapus produk): {\"type\":\"delete_product\",\"name\":str}\n"
    "9) deactivate_category (nonaktifkan kategori): {\"type\":\"deactivate_category\",\"name\":str,\"kind\":\"makanan|minuman|retail|vendor\"?}\n"
    "10) delete_category (hapus kategori): {\"type\":\"delete_category\",\"name\":str,\"kind\":\"makanan|minuman|retail|vendor\"?}\n"
    "ATURAN PENTING:\n"
    "- Jika admin MENEMPEL/menyebut BANYAK produk sekaligus (beberapa baris atau dipisah koma), WAJIB pakai SATU create_products_bulk berisi array items (JANGAN banyak blok aksi). "
    "Tebak 'kind' & 'category_name' yang masuk akal per item; default kind='retail' bila tak jelas. Jika harga tak tertera, set price 0 dan ingatkan admin melengkapi.\n"
    "- 'nonaktifkan/matikan' -> deactivate_*, 'hapus/buang' -> delete_*. Catatan: menghapus data yang sudah dipakai transaksi akan otomatis dinonaktifkan (soft delete) demi keamanan.\n"
    "- DISKON bersifat per-transaksi (diterapkan kasir saat bayar), bukan data master; untuk diskon berikan SARAN saja, jangan buat blok aksi.\n"
    "- Gunakan KONTEKS DATA untuk mencocokkan nama kategori/vendor yang sudah ada dan hindari duplikat. Jangan mengarang id. "
    "Selalu ingatkan bahwa admin akan menekan tombol 'Terapkan' untuk mengeksekusi."
)

# Panduan singkat aplikasi — dipakai Asisten AI untuk menjawab pertanyaan cara pakai fitur.
APP_GUIDE = (
    "POS Grand Aceh Kuliner (web + APK Android). Modul: POS Kasir (dine-in meja, take-away, retail, diskon, "
    "bayar cash/QRIS/debit), Shift (buka/tutup shift), Kas (setoran/pengambilan), Produk & Stok (kategori, "
    "stok, import/export Excel, opname), Vendor (bagi hasil), Laporan (harian/mingguan/bulanan, ekspor Excel/PDF, "
    "kirim WhatsApp), AI (tanya-jawab data dan usulan aksi), Pengaturan (pengguna/role, meja, perangkat printer, "
    "AI provider, installer/update dari vibecoder.co.id, diagnosa/lapor bug, versi, backup/restore, reset data). "
    "Update server: ./update-vibecoder-pi.sh atau tombol Update Sekarang (vibecoder.co.id). "
    "APK: isi alamat server http://IP-server di Pengaturan Server saat login. Fitur lapor bug: Pengaturan > Diagnostik."
)

async def _report_context(date_str):
    today = date_str or datetime.now(WIB).strftime("%Y-%m-%d")
    try:
        d = datetime.strptime(today, "%Y-%m-%d")
    except Exception:
        today = datetime.now(WIB).strftime("%Y-%m-%d")
        d = datetime.strptime(today, "%Y-%m-%d")
    yday = (d - timedelta(days=1)).strftime("%Y-%m-%d")
    s_today = await report_summary(date_str=today, admin={"role": "admin", "id": "chat"})
    s_yday = await report_summary(date_str=yday, admin={"role": "admin", "id": "chat"})
    p_items, p_total = await _purchase_summary(today)
    return {
        "tanggal": today,
        "penjualan_hari_ini": s_today,
        "penjualan_kemarin": s_yday,
        "belanja_hari_ini": {"total": p_total, "jumlah_item": len(p_items)},
    }

async def _assistant_context():
    cats = await db.categories.find({}, {"_id": 0, "name": 1, "type": 1, "active": 1}).to_list(500)
    vendors = await db.vendors.find({}, {"_id": 0, "name": 1}).sort("name", 1).to_list(500)
    pms = await db.payment_methods.find({}, {"_id": 0, "name": 1, "type": 1}).to_list(100)
    pcount = await db.products.count_documents({})
    # Data laporan (hari ini & kemarin) agar AI bisa menjawab pertanyaan penjualan juga.
    try:
        rep = await _report_context(None)
    except Exception:
        rep = {}
    return {
        "kategori": [{"nama": c.get("name"), "tipe": c.get("type")} for c in cats],
        "vendor": [v.get("name") for v in vendors],
        "metode_pembayaran": [{"nama": p.get("name"), "tipe": p.get("type")} for p in pms],
        "jumlah_produk": pcount,
        "laporan_penjualan": rep,
        "panduan_aplikasi": APP_GUIDE,
    }

def _parse_action(text):
    import json, re
    m = re.search(r"<ACTION>\s*(\{.*?\})\s*</ACTION>", text or "", re.S)
    if not m:
        return None, (text or "").strip()
    try:
        action = json.loads(m.group(1))
    except Exception:
        return None, (text or "").strip()
    clean = ((text[:m.start()] + text[m.end():]) or "").strip()
    return action, clean

def _to_num(v, default=0.0):
    if isinstance(v, (int, float)):
        return float(v)
    import re as _r
    s = _r.sub(r"[^0-9.\-]", "", str(v or ""))
    try:
        return float(s) if s not in ("", "-", ".") else float(default)
    except Exception:
        return float(default)

def _slug_sku(name):
    import re as _r
    base = _r.sub(r"[^A-Za-z0-9]+", "-", (name or "").upper()).strip("-")[:12] or "SKU"
    return f"{base}-{new_id()[:4].upper()}"

@api.post("/ai/assistant/chat")
async def assistant_chat(body: AIAssistantChatIn, admin: dict = Depends(admin_or_kasir)):
    import json
    if not await _ai_allowed("assistant"):
        raise HTTPException(400, "Fitur AI 'Asisten' dimatikan. Nyalakan di Pengaturan → Fitur & Integrasi.")
    if not (body.message or "").strip():
        raise HTTPException(400, "Pesan kosong")
    sid = body.session_id or new_id()
    sess = await db.ai_assistant_sessions.find_one({"id": sid}) or {"id": sid, "messages": []}
    history = sess.get("messages", [])
    ctx = await _assistant_context()
    role_line = "Pengguna berperan: admin (boleh menerapkan aksi)." if admin.get("role") == "admin" else "Pengguna berperan: kasir (HANYA bertanya — jangan sertakan blok aksi, perubahan data hanya admin)."
    system = role_line + "\n" + ASSISTANT_SYSTEM + "\n\nKONTEKS DATA SAAT INI:\n" + json.dumps(ctx, ensure_ascii=False)
    msgs = history + [{"role": "user", "content": body.message}]
    reply = await _ai_chat(msgs, system=system, feature="assistant", temperature=0.3, max_tokens=1500)
    action, clean = _parse_action(reply)
    history = (history + [{"role": "user", "content": body.message},
                          {"role": "assistant", "content": reply}])[-20:]
    title = (body.message or "").strip()[:60] or "Percakapan"
    await db.ai_assistant_sessions.update_one({"id": sid},
        {"$set": {"id": sid, "messages": history, "updated_at": now_utc().isoformat()},
         "$setOnInsert": {"title": title, "created_at": now_utc().isoformat()}}, upsert=True)
    return {"session_id": sid, "reply": clean or "(tidak ada balasan)", "action": action}

@api.get("/ai/assistant/sessions")
async def assistant_sessions(admin: dict = Depends(admin_or_kasir)):
    docs = await db.ai_assistant_sessions.find({}, {"_id": 0}).sort("updated_at", -1).to_list(50)
    out = []
    for d in docs:
        msgs = d.get("messages", [])
        title = d.get("title") or next((m.get("content", "") for m in msgs if m.get("role") == "user"), "Percakapan")
        out.append({"id": d["id"], "title": (title or "Percakapan")[:60],
                    "updated_at": d.get("updated_at"), "count": len(msgs)})
    return {"sessions": out}

@api.get("/ai/assistant/sessions/{sid}")
async def assistant_session_detail(sid: str, admin: dict = Depends(admin_or_kasir)):
    d = await db.ai_assistant_sessions.find_one({"id": sid}, {"_id": 0})
    if not d:
        raise HTTPException(404, "Sesi tidak ditemukan")
    msgs = []
    for m in d.get("messages", []):
        if m.get("role") == "assistant":
            _, clean = _parse_action(m.get("content", ""))
            msgs.append({"role": "assistant", "text": clean or m.get("content", "")})
        else:
            msgs.append({"role": "user", "text": m.get("content", "")})
    return {"id": sid, "messages": msgs}

@api.delete("/ai/assistant/sessions/{sid}")
async def assistant_session_delete(sid: str, admin: dict = Depends(admin_or_kasir)):
    await db.ai_assistant_sessions.delete_one({"id": sid})
    return {"deleted": True}

async def _resolve_or_create_category(name, kind):
    kind = kind if kind in ("makanan", "minuman", "retail", "vendor") else "retail"
    name = (name or "").strip() or "Umum"
    cat = await db.categories.find_one({"name": {"$regex": f"^{re.escape(name)}$", "$options": "i"}, "type": kind})
    if cat:
        return cat["id"], False
    doc = {"id": new_id(), "name": name, "type": kind, "sort_order": 0, "active": True,
           "created_at": now_utc().isoformat()}
    await db.categories.insert_one(doc)
    _cache_del("categories:")
    return doc["id"], True

async def _create_one_product(a):
    """Create a single product from an action dict. Returns a human message. Raises on validation error."""
    name = (a.get("name") or "").strip()
    if not name:
        raise HTTPException(400, "Nama produk wajib diisi")
    price = _to_num(a.get("price"), 0)
    cost = _to_num(a.get("cost"), 0)
    if price < 0 or cost < 0:
        raise HTTPException(400, f"Harga/HPP '{name}' tidak boleh negatif")
    kind = a.get("kind") if a.get("kind") in ("makanan", "minuman", "retail", "vendor") else "retail"
    cat_id, cat_created = await _resolve_or_create_category(a.get("category_name") or "Umum", kind)
    sku = (a.get("sku") or "").strip() or _slug_sku(name)
    if await db.products.find_one({"sku": sku}):
        sku = _slug_sku(name)
    vendor_id = None
    if a.get("vendor_name"):
        v = await db.vendors.find_one({"name": {"$regex": f"^{re.escape(str(a.get('vendor_name')).strip())}$", "$options": "i"}})
        vendor_id = v["id"] if v else None
    doc = {"id": new_id(), "name": name, "sku": sku, "category_id": cat_id, "type": kind,
           "price": price, "cost": cost, "vendor_id": vendor_id, "vendor_share_percent": None,
           "description": str(a.get("description") or ""), "image": "", "active": True,
           "sold_out": False, "stock": int(_to_num(a.get("stock"), 0)), "min_stock": 10,
           "track_stock": kind == "retail", "created_at": now_utc().isoformat()}
    await db.products.insert_one(doc)
    _cache_del("products:")
    extra = " (kategori baru)" if cat_created else ""
    return f"'{name}' (SKU {sku}, Rp {int(price):,}){extra}".replace(",", ".")

async def _find_product(name):
    name = (name or "").strip()
    if not name:
        raise HTTPException(400, "Sebutkan nama/SKU produk")
    p = await db.products.find_one({"$or": [
        {"name": {"$regex": f"^{re.escape(name)}$", "$options": "i"}},
        {"sku": {"$regex": f"^{re.escape(name)}$", "$options": "i"}}]})
    if not p:
        raise HTTPException(404, f"Produk '{name}' tidak ditemukan")
    return p

async def _find_category(name, kind=None):
    name = (name or "").strip()
    if not name:
        raise HTTPException(400, "Sebutkan nama kategori")
    q = {"name": {"$regex": f"^{re.escape(name)}$", "$options": "i"}}
    if kind in ("makanan", "minuman", "retail", "vendor"):
        q["type"] = kind
    c = await db.categories.find_one(q)
    if not c:
        raise HTTPException(404, f"Kategori '{name}' tidak ditemukan")
    return c

@api.post("/ai/assistant/apply")
async def assistant_apply(body: AIAssistantApplyIn, admin: dict = Depends(require_admin)):
    a = body.action or {}
    t = a.get("type")
    if t == "create_category":
        name = (a.get("name") or "").strip()
        kind = a.get("kind") if a.get("kind") in ("makanan", "minuman", "retail", "vendor") else "retail"
        if not name:
            raise HTTPException(400, "Nama kategori wajib diisi")
        if await db.categories.find_one({"name": {"$regex": f"^{re.escape(name)}$", "$options": "i"}, "type": kind}):
            raise HTTPException(400, f"Kategori '{name}' ({kind}) sudah ada")
        doc = {"id": new_id(), "name": name, "type": kind, "sort_order": 0, "active": True,
               "created_at": now_utc().isoformat()}
        await db.categories.insert_one(doc)
        return {"ok": True, "message": f"Kategori '{name}' ({kind}) dibuat.", "entity": "category"}

    if t == "create_vendor":
        name = (a.get("name") or "").strip()
        if not name:
            raise HTTPException(400, "Nama vendor wajib diisi")
        if await db.vendors.find_one({"name": {"$regex": f"^{re.escape(name)}$", "$options": "i"}}):
            raise HTTPException(400, f"Vendor '{name}' sudah ada")
        doc = {"id": new_id(), "name": name, "contact": str(a.get("contact") or ""),
               "note": str(a.get("note") or ""), "active": True, "created_at": now_utc().isoformat()}
        await db.vendors.insert_one(doc)
        return {"ok": True, "message": f"Vendor '{name}' dibuat.", "entity": "vendor"}

    if t == "create_payment_method":
        name = (a.get("name") or "").strip()
        pm_type = a.get("pm_type") if a.get("pm_type") in ("cash", "qris", "card") else "cash"
        if not name:
            raise HTTPException(400, "Nama metode pembayaran wajib diisi")
        if await db.payment_methods.find_one({"name": {"$regex": f"^{re.escape(name)}$", "$options": "i"}}):
            raise HTTPException(400, f"Metode pembayaran '{name}' sudah ada")
        doc = {"id": new_id(), "name": name, "type": pm_type, "active": True}
        await db.payment_methods.insert_one(doc)
        return {"ok": True, "message": f"Metode pembayaran '{name}' ({pm_type}) dibuat.", "entity": "payment_method"}

    if t == "create_product":
        msg = await _create_one_product(a)
        return {"ok": True, "message": f"Produk {msg} dibuat.", "entity": "product"}

    if t == "create_products_bulk":
        items = a.get("items") or []
        if not isinstance(items, list) or not items:
            raise HTTPException(400, "Daftar produk kosong")
        if len(items) > 100:
            raise HTTPException(400, "Maksimal 100 produk per sekali proses")
        ok_msgs, errors = [], []
        for it in items:
            try:
                ok_msgs.append(await _create_one_product(it if isinstance(it, dict) else {}))
            except HTTPException as e:
                errors.append(f"{(it or {}).get('name', '?')}: {e.detail}")
            except Exception as e:
                errors.append(f"{(it or {}).get('name', '?')}: {e}")
        summary = f"{len(ok_msgs)} produk dibuat"
        if errors:
            summary += f", {len(errors)} gagal"
        return {"ok": True, "message": summary + ".", "entity": "product",
                "results": {"created": ok_msgs, "errors": errors}}

    if t == "update_product":
        name = (a.get("name") or a.get("sku") or "").strip()
        if not name:
            raise HTTPException(400, "Sebutkan nama/SKU produk yang akan diubah")
        p = await _find_product(name)
        upd = {}
        if a.get("price") is not None:
            upd["price"] = _to_num(a.get("price"))
        if a.get("cost") is not None:
            upd["cost"] = _to_num(a.get("cost"))
        if a.get("stock") is not None:
            upd["stock"] = int(_to_num(a.get("stock")))
        if a.get("sold_out") is not None:
            upd["sold_out"] = bool(a.get("sold_out"))
        if a.get("active") is not None:
            upd["active"] = bool(a.get("active"))
        if a.get("description") is not None:
            upd["description"] = str(a.get("description"))
        if upd.get("price", 0) < 0 or upd.get("cost", 0) < 0:
            raise HTTPException(400, "Harga/HPP tidak boleh negatif")
        if not upd:
            raise HTTPException(400, "Tidak ada perubahan untuk diterapkan")
        await db.products.update_one({"id": p["id"]}, {"$set": upd})
        changed = ", ".join(f"{k}={v}" for k, v in upd.items())
        return {"ok": True, "message": f"Produk '{p['name']}' diperbarui ({changed}).", "entity": "product"}

    if t == "deactivate_product":
        p = await _find_product(a.get("name") or a.get("sku"))
        await db.products.update_one({"id": p["id"]}, {"$set": {"active": False}})
        return {"ok": True, "message": f"Produk '{p['name']}' dinonaktifkan.", "entity": "product"}

    if t == "delete_product":
        p = await _find_product(a.get("name") or a.get("sku"))
        used = await db.orders.count_documents({"items.product_id": p["id"]})
        if used:
            await db.products.update_one({"id": p["id"]}, {"$set": {"active": False}})
            return {"ok": True, "message": f"Produk '{p['name']}' pernah dipakai transaksi, jadi DINONAKTIFKAN (bukan dihapus).", "entity": "product"}
        await db.products.delete_one({"id": p["id"]})
        return {"ok": True, "message": f"Produk '{p['name']}' dihapus.", "entity": "product"}

    if t == "deactivate_category":
        c = await _find_category(a.get("name"), a.get("kind"))
        await db.categories.update_one({"id": c["id"]}, {"$set": {"active": False}})
        return {"ok": True, "message": f"Kategori '{c['name']}' dinonaktifkan.", "entity": "category"}

    if t == "delete_category":
        c = await _find_category(a.get("name"), a.get("kind"))
        used = await db.products.count_documents({"category_id": c["id"]})
        if used:
            await db.categories.update_one({"id": c["id"]}, {"$set": {"active": False}})
            return {"ok": True, "message": f"Kategori '{c['name']}' dipakai {used} produk, jadi DINONAKTIFKAN (bukan dihapus).", "entity": "category"}
        await db.categories.delete_one({"id": c["id"]})
        return {"ok": True, "message": f"Kategori '{c['name']}' dihapus.", "entity": "category"}

    raise HTTPException(400, f"Jenis aksi tidak didukung: {t}")

import json as _json, re as _re

def _num(v):
    if isinstance(v, (int, float)):
        return float(v)
    s = _re.sub(r"[^0-9]", "", str(v))
    return float(s) if s else 0.0

def _extract_json_list(text):
    t = (text or "").strip()
    m = _re.search(r"\[.*\]", t, _re.S)
    if m:
        t = m.group(0)
    try:
        data = _json.loads(t)
    except Exception:
        return []
    out = []
    for d in (data if isinstance(data, list) else []):
        if not isinstance(d, dict):
            continue
        name = str(d.get("name", "")).strip()
        if name:
            out.append({"name": name, "qty": _num(d.get("qty", 1)) or 1, "unit_cost": _num(d.get("unit_cost", 0))})
    return out

@api.post("/ai/parse-invoice")
async def ai_parse_invoice(body: AIInvoiceIn, admin: dict = Depends(admin_or_input)):
    if not await _ai_allowed("vision"):
        raise HTTPException(400, "Fitur AI 'Baca Faktur (Vision)' dimatikan. Nyalakan di Pengaturan → Fitur & Integrasi.")
    cfg = await _ai_cfg("vision")
    if not (cfg["api_key"] and cfg["base_url"] and cfg["model"]):
        raise HTTPException(400, "Konfigurasi AI 'Baca Faktur (Vision)' belum lengkap di Pengaturan AI")
    img = body.image if body.image.startswith("data:") else f"data:image/jpeg;base64,{body.image}"
    system = "Anda asisten yang membaca foto faktur/nota pembelian toko."
    prompt = ('Baca foto faktur berikut dan ekstrak daftar barang. Kembalikan HANYA JSON array. '
              'Tiap elemen: {"name": "nama barang", "sku": "kode/barcode jika terlihat (else kosong)", "qty": angka, "unit_cost": angka}. '
              'unit_cost = harga beli per unit (Rupiah, angka saja tanpa titik/koma). Tanpa teks lain.')
    from openai import OpenAI

    def run():
        client = OpenAI(api_key=cfg["api_key"], base_url=cfg["base_url"])
        r = client.chat.completions.create(
            model=cfg["model"],
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": img}},
                ]},
            ],
            max_tokens=1500, temperature=0,
        )
        return r.choices[0].message.content or ""
    try:
        raw = await asyncio.to_thread(run)
    except Exception as e:
        logger.error(f"parse-invoice AI error: {e}")
        raise HTTPException(400, "Model AI yang dipilih tidak mendukung pembacaan gambar. Ganti model Vision di Pengaturan AI.")
    return {"items": _extract_json_list(raw)}

@api.post("/ai/expense-vision")
async def ai_expense_vision(body: AIInvoiceIn, admin: dict = Depends(require_any_module("pengeluaran", "produk", "belanja_bahan"))):
    """Scan foto struk/nota pembelian -> daftar PENGELUARAN (F&B) yang siap dicatat ke kas."""
    if not await _ai_allowed("vision"):
        raise HTTPException(400, "Fitur AI 'Baca Faktur (Vision)' dimatikan. Nyalakan di Pengaturan → Fitur & Integrasi.")
    cfg = await _ai_cfg("vision")
    if not (cfg["api_key"] and cfg["base_url"] and cfg["model"]):
        raise HTTPException(400, "Konfigurasi AI 'Baca Faktur (Vision)' belum lengkap di Pengaturan AI")
    img = body.image if body.image.startswith("data:") else f"data:image/jpeg;base64,{body.image}"
    system = "Anda asisten yang membaca foto struk/nota pembelian toko (pengeluaran operasional)."
    prompt = ('Baca foto nota/struk pembelian berikut. Kembalikan HANYA JSON array. '
              'Tiap elemen: {"name": "nama barang/belanja", "amount": angka total biaya item (Rupiah, angka saja tanpa titik/koma), '
              '"category": salah satu dari ["Bahan Baku", "Belanja Operasional", "Bayar Supplier", "Kasbon", "Lainnya"]}. '
              'Bila struk tidak terbaca/tidak jelas, kembalikan []. Tanpa teks lain.')
    from openai import OpenAI

    def run():
        client = OpenAI(api_key=cfg["api_key"], base_url=cfg["base_url"])
        r = client.chat.completions.create(
            model=cfg["model"],
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": img}},
                ]},
            ],
            max_tokens=1500, temperature=0,
        )
        return r.choices[0].message.content or ""
    try:
        raw = await asyncio.to_thread(run)
    except Exception as e:
        logger.error(f"expense-vision AI error: {e}")
        raise HTTPException(400, "Model AI yang dipilih tidak mendukung pembacaan gambar. Ganti model Vision di Pengaturan AI.")
    items = _extract_json_list(raw)
    # normalisasi & filter
    cleaned = []
    for it in items:
        if not isinstance(it, dict):
            continue
        try:
            amt = float(it.get("amount") or 0)
        except (ValueError, TypeError):
            amt = 0
        if amt <= 0:
            continue
        cleaned.append({
            "name": str(it.get("name") or "Belanja"),
            "amount": round(amt, 2),
            "category": str(it.get("category") or "Lainnya"),
        })
    return {"items": cleaned, "count": len(cleaned), "total": round(sum(i["amount"] for i in cleaned), 2)}

@api.post("/ai/product-description")
async def ai_description(body: AIDescIn, admin: dict = Depends(admin_or_input)):
    try:
        system = "Anda copywriter menu F&B & retail Indonesia. Tulis deskripsi produk singkat, menggugah selera, maksimal 2 kalimat, bahasa Indonesia. Jangan pakai emoji."
        prompt = f"Produk: {body.name}\nTipe: {body.type}\nKategori: {body.category}\nKata kunci: {body.keywords}\nTulis deskripsi produk."
        text = await _gemini_text(system, prompt, "description")
        return {"description": text}
    except Exception as e:
        logger.error(f"AI desc error: {e}")
        raise HTTPException(500, f"AI gagal: {e}")

@api.post("/ai/product-image")
async def ai_image(body: AIImageIn, admin: dict = Depends(admin_or_input)):
    try:
        prompt = f"Professional appetizing product photo of '{body.name}'. {body.description}. Clean studio background, top menu photography, high detail, no text overlay."
        image = await _gemini_image(prompt)
        if not image:
            raise HTTPException(500, "Tidak ada gambar dihasilkan")
        stored = await _save_image_local(image)
        return {"image": stored or image}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"AI image error: {e}")
        msg = str(e)
        if "RESOURCE_EXHAUSTED" in msg or "429" in msg:
            raise HTTPException(429, "Gambar AI belum aktif di akun Gemini Anda (kuota gambar free tier = 0). Aktifkan billing di Google Cloud/AI Studio untuk memakainya, atau unggah gambar produk secara manual.")
        raise HTTPException(500, f"AI gambar gagal: {e}")

@api.post("/reports/ai-summary")
async def ai_summary(body: AISummaryIn, admin: dict = Depends(admin_or_kasir)):
    d = body.date or now_utc().strftime("%Y-%m-%d")
    summary = await report_summary(date_str=d, admin=admin)
    try:
        system = ("Anda analis bisnis F&B & retail. Tulis LAPORAN penjualan harian dalam bahasa Indonesia yang tegas dan actionable. "
                  "Struktur: (1) Ringkasan singkat, (2) Sorotan per kategori (Makanan/Minuman/Retail), (3) 2-3 insight, (4) 1-2 rekomendasi. Tanpa emoji.")
        cr = summary.get("category_report", {})
        mk, mn, rt = cr.get("makanan", {}), cr.get("minuman", {}), cr.get("retail", {})

        def _cats(g):
            return ", ".join(f"{c['name']} Rp{c['total']:,.0f}" for c in g.get("categories", [])[:6]) or "-"
        prompt = (f"Data penjualan {d}:\n"
                  f"Total: Rp{summary['total_sales']:,.0f} dari {summary['order_count']} order. Laba kotor: Rp{summary['gross_profit']:,.0f}.\n"
                  f"Dine-in: Rp{summary['by_type']['dine_in']['total']:,.0f}; Take away: Rp{summary['by_type']['take_away']['total']:,.0f}; Retail: Rp{summary['by_type']['retail']['total']:,.0f}.\n"
                  f"Makanan Rp{mk.get('total', 0):,.0f} (rincian: {_cats(mk)}).\n"
                  f"Minuman Rp{mn.get('total', 0):,.0f} (rincian: {_cats(mn)}).\n"
                  f"Retail gabungan Rp{rt.get('total', 0):,.0f}.\n"
                  f"Total diskon: Rp{summary['total_discount']:,.0f}. Kas masuk: Rp{summary['cash_in']:,.0f}, kas keluar: Rp{summary['cash_out']:,.0f}.\n"
                  f"Produk terlaris: {', '.join(p['name'] for p in summary['top_products'][:5])}.\n"
                  f"Stok retail menipis: {len(summary.get('low_stock', []))} produk.\n"
                  f"Buat laporan analitik.")
        text = await _gemini_text(system, prompt, "summary")
        return {"date": d, "summary": text, "data": summary}
    except Exception as e:
        logger.error(f"AI summary error: {e}")
        raise HTTPException(500, f"AI ringkasan gagal: {e}")

# ================================================================== REPORT EXPORT & WHATSAPP (wacloud.id gateway)
WEBHOOK_CRON_SECRET = os.environ.get('WEBHOOK_CRON_SECRET')
WACLOUD_DEFAULT_BASE = "https://app.wacloud.id/api/v1"

async def _wa_config():
    return await db.settings.find_one({"_id": "wa"}, {"_id": 0}) or {}

async def _wa_configured():
    c = await _wa_config()
    return bool(c.get("api_key") and c.get("device_id"))

def _wa_normalize(num):
    n = "".join(ch for ch in str(num) if ch.isdigit())
    if n.startswith("0"):
        n = "62" + n[1:]
    return n

async def _wacloud_request(method, path, **kw):
    import httpx
    await _breaker_check("WA")
    cfg = await _wa_config()
    api_key = cfg.get("api_key")
    base = (cfg.get("base_url") or WACLOUD_DEFAULT_BASE).rstrip("/")
    if not api_key:
        raise HTTPException(400, "API Key WhatsApp (wacloud.id) belum diisi di Pengaturan")
    headers = {"X-Api-Key": api_key, "Content-Type": "application/json"}
    try:
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.request(method, f"{base}{path}", headers=headers, **kw)
    except Exception:
        _breaker_fail("WA")
        raise
    if r.status_code >= 500:
        _breaker_fail("WA")
    else:
        _breaker_success("WA")
    return r

async def _wa_send_text(to, text):
    cfg = await _wa_config()
    device_id = cfg.get("device_id")
    if not device_id:
        raise HTTPException(400, "Device WhatsApp belum dipilih di Pengaturan")
    return await _wacloud_request("POST", "/messages", json={
        "device_id": device_id, "to": _wa_normalize(to),
        "message_type": "text", "text": text,
    })

# ================================================================== TEMPLATE WHATSAPP (bisa diedit admin)
# Semua pesan WA (laporan harian, laporan shift, bagi hasil vendor, belanja harian,
# pembelian retail) dirender dari template teks yang bisa diubah di Pengaturan →
# WhatsApp & Laporan → Template WhatsApp. Variabel ditulis {nama}; blok dinamis
# (rincian vendor / produk terlaris dll) disediakan sbg variabel {rincian_*}.
def _tpl_app_name():
    return "Grand Aceh Kuliner"

TPL_DEFAULTS = {
    "daily": "*Laporan {nama_aplikasi}*\nTanggal: {tanggal}\n\n"
             "Total Penjualan: {total_penjualan}\n"
             "Jumlah Order: {order_count}\n"
             "Laba Kotor: {laba_kotor}\n"
             "Total Diskon: {total_diskon}\n\n"
             "Per Kategori:\n- Makanan: {kategori_makanan}\n- Minuman: {kategori_minuman}\n- Retail: {kategori_retail}"
             "{rincian_metode}{rincian_terlaris}{rincian_ai}",
    "shift": "*LAPORAN SHIFT {kasir} ({tanggal_shift}) — {nama_aplikasi}*\n\n"
             "Total Penjualan: {total_penjualan} ({order_count} order)\n"
             "*F&B*: {fnb_total}\n  Dine-in: {dine_in}\n  Take Away: {take_away}\n"
             "*Retail*: {retail_total}\n\n"
             "Pengeluaran F&B: {out_fnb}\nPengeluaran Retail: {out_retail}\n"
             "Perkiraan kas: {expected_cash}\n\n"
             "*UANG BERSIH*\nF&B: {net_cash_fnb}\nRetail: {net_cash_retail}\nTotal: {net_cash}"
             "{rincian_vendor}",
    "vendor": "*Laporan Bagi Hasil Vendor — {nama_aplikasi}*\nPeriode: {periode}\n\n"
              "Total Omzet Vendor: {total_omzet}\n"
              "Total Bagi Hasil Vendor: {total_bagi_hasil}\n"
              "Bagian Outlet: {bagian_outlet}"
              "{rincian_vendor}",
    "shopping": "*DAFTAR BELANJA BAHAN — {tanggal}*\n\n{items}\n\n"
                "Jumlah item: {jumlah_item}\nEstimasi biaya: {total_estimasi}",
    "purchase": "*Laporan Belanja {nama_aplikasi}*\nTanggal: {tanggal}\n\n"
                "Total Belanja: {total_belanja}\nJumlah Item: {jumlah_item}\n\n{items}",
}

async def _tpl_doc():
    doc = await db.settings.find_one({"_id": "wa_templates"}, {"_id": 0}) or {}
    return doc.get("templates") or {}

async def _tpl_get(key):
    doc = await _tpl_doc()
    text = doc.get(key)
    return (text if text is not None else None) or TPL_DEFAULTS.get(key, "")

async def _tpl_fill(key, env):
    """Render template WA: ganti {variabel} dengan nilai env. Variabel tak dikenal → ''."""
    import re as _re
    tpl = await _tpl_get(key)
    def _sub(m):
        name = m.group(1)
        val = env.get(name, "")
        return "" if val is None else str(val)
    return _re.sub(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", _sub, tpl)

@api.get("/settings/wa-templates")
async def get_wa_templates(admin: dict = Depends(require_admin)):
    doc = await _tpl_doc()
    out = {}
    for k, dflt in TPL_DEFAULTS.items():
        out[k] = doc.get(k, dflt)
    return {"templates": out, "defaults": dict(TPL_DEFAULTS)}

class WATemplatesIn(BaseModel):
    templates: dict = {}

@api.put("/settings/wa-templates")
async def put_wa_templates(body: WATemplatesIn, admin: dict = Depends(require_admin)):
    clean = {}
    tpls = body.templates if isinstance(body.templates, dict) else {}
    for k in TPL_DEFAULTS:
        v = tpls.get(k)
        if isinstance(v, str) and v.strip():
            clean[k] = v.strip()
    await db.settings.update_one({"_id": "wa_templates"}, {"$set": {"templates": clean}}, upsert=True)
    return {"ok": True, "count": len(clean)}

# ---- pembangun lingkungan (env) utk tiap jenis pesan WA ----
def _rp(x):
    return f"Rp{float(x or 0):,.0f}"

def _daily_wa_env(d, s, ai_text=None):
    cr = s.get("category_report", {})
    env = {
        "nama_aplikasi": _tpl_app_name(), "tanggal": d,
        "total_penjualan": _rp(s["total_sales"]), "order_count": str(s["order_count"]),
        "laba_kotor": _rp(s["gross_profit"]), "total_diskon": _rp(s["total_discount"]),
        "kategori_makanan": _rp(cr.get("makanan", {}).get("total", 0)),
        "kategori_minuman": _rp(cr.get("minuman", {}).get("total", 0)),
        "kategori_retail": _rp(cr.get("retail", {}).get("total", 0)),
    }
    blk_metode = ""
    blk_terlaris = ""
    blk_ai = ""
    if s.get("by_payment"):
        blk_metode = "\nMetode Bayar:\n" + "\n".join(f"- {k}: {_rp(v)}" for k, v in s["by_payment"].items())
    if s.get("top_products"):
        blk_terlaris = "\nProduk Terlaris:\n" + "\n".join(f"- {p['name']} (x{p['qty']})" for p in s["top_products"][:5])
    if ai_text:
        blk_ai = "\nAnalisis AI:\n" + ai_text
    env["rincian_metode"] = blk_metode
    env["rincian_terlaris"] = blk_terlaris
    env["rincian_ai"] = blk_ai
    return env

def _shift_wa_env(r, cashier="", date_shift=""):
    env = {
        "nama_aplikasi": _tpl_app_name(), "kasir": cashier or r.get("cashier_name", ""),
        "tanggal_shift": date_shift or (r.get("opened_at") or "")[:10],
        "total_penjualan": _rp(r.get("total_sales", 0)), "order_count": str(r.get("order_count", 0)),
        "fnb_total": _rp(r.get("fnb_total", 0)), "dine_in": _rp(r.get("by_type", {}).get("dine_in", 0)),
        "take_away": _rp(r.get("by_type", {}).get("take_away", 0)), "retail_total": _rp(r.get("retail_total", 0)),
        "out_fnb": _rp(r.get("cash_out_fnb", 0)), "out_retail": _rp(r.get("cash_out_retail", 0)),
        "expected_cash": _rp(r.get("expected_cash", 0)),
        "net_cash_fnb": _rp(r.get("net_cash_fnb", 0)), "net_cash_retail": _rp(r.get("net_cash_retail", 0)),
        "net_cash": _rp(r.get("net_cash", 0)),
    }
    L = []
    for v in (r.get("vendor_share") or []):
        L.append(f"Vendor {v.get('vendor_name', '?')}: bagi hasil {v.get('share', 0):,.0f} | diberikan {v.get('paid', 0):,.0f} | selisih {v.get('difference', 0):,.0f}")
        for im in (v.get("items") or []):
            L.append(f"   - {im.get('name', '?')} (x{im.get('qty', 0)}): Rp{im.get('gross', 0):,.0f} (Vendor Rp{im.get('vendor_share', 0):,.0f})")
    if r.get("vendor_total_share"):
        L.append(f"Total vendor: share {r.get('vendor_total_share', 0):,.0f} | diberikan {r.get('vendor_total_paid', 0):,.0f}")
    env["rincian_vendor"] = ("\n" + "\n".join(L)) if L else ""
    return env

def _vendor_wa_env(rep):
    env = {
        "nama_aplikasi": _tpl_app_name(), "periode": rep["label"],
        "total_omzet": _rp(rep["total_gross"]), "total_bagi_hasil": _rp(rep["total_vendor_share"]),
        "bagian_outlet": _rp(rep["total_outlet_share"]),
    }
    L = []
    if rep["rows"]:
        L.append("Rincian per Vendor:")
        for r in rep["rows"]:
            L.append(f"- {r['vendor_name']} (x{r['qty']}): Omzet Rp{r['gross']:,.0f} -> Vendor Rp{r['vendor_share']:,.0f}")
            for im in (r.get("items") or []):
                L.append(f"    - {im['name']} (x{im['qty']}): Omzet Rp{im['gross']:,.0f} (Vendor Rp{im['vendor_share']:,.0f})")
    else:
        L.append("Belum ada penjualan produk vendor pada periode ini.")
    env["rincian_vendor"] = "\n" + "\n".join(L)
    return env

def _purchase_wa_env(d, items, total):
    env = {"nama_aplikasi": _tpl_app_name(), "tanggal": d,
           "total_belanja": _rp(total), "jumlah_item": str(len(items))}
    if items:
        L = ["Rincian:"] + [f"- {x.get('product_name', '?')} x{x.get('qty', 0)} = {_rp(x.get('total_cost', 0))}" for x in items[:40]]
    else:
        L = ["Tidak ada pembelian pada tanggal ini."]
    env["items"] = "\n".join(L)
    return env


def _report_lines(d, s, ai_text=None):
    cr = s.get("category_report", {})
    L = ["*Laporan Grand Aceh Kuliner*", f"Tanggal: {d}", "",
         f"Total Penjualan: Rp{s['total_sales']:,.0f}",
         f"Jumlah Order: {s['order_count']}",
         f"Laba Kotor: Rp{s['gross_profit']:,.0f}",
         f"Total Diskon: Rp{s['total_discount']:,.0f}", "",
         "Per Kategori:",
         f"- Makanan: Rp{cr.get('makanan', {}).get('total', 0):,.0f}",
         f"- Minuman: Rp{cr.get('minuman', {}).get('total', 0):,.0f}",
         f"- Retail: Rp{cr.get('retail', {}).get('total', 0):,.0f}"]
    if s.get("by_payment"):
        L += ["", "Metode Bayar:"] + [f"- {k}: Rp{v:,.0f}" for k, v in s["by_payment"].items()]
    if s.get("top_products"):
        L += ["", "Produk Terlaris:"] + [f"- {p['name']} (x{p['qty']})" for p in s["top_products"][:5]]
    if ai_text:
        L += ["", "Analisis AI:", ai_text]
    return L

async def _purchase_summary(d):
    start, end = wib_day_range(d)
    items = await db.purchases.find({"created_at": {"$gte": start, "$lt": end}}, {"_id": 0}).sort("created_at", 1).to_list(2000)
    total = sum(float(x.get("total_cost", 0)) for x in items)
    return items, total

def _purchase_report_lines(d, items, total):
    L = ["*Laporan Belanja Grand Aceh Kuliner*", f"Tanggal: {d}", "",
         f"Total Belanja: Rp{total:,.0f}",
         f"Jumlah Item: {len(items)}", ""]
    if items:
        L.append("Rincian:")
        for x in items[:40]:
            L.append(f"- {x.get('product_name', '?')} x{x.get('qty', 0)} = Rp{float(x.get('total_cost', 0)):,.0f}")
    else:
        L.append("Tidak ada pembelian pada tanggal ini.")
    return L

def _report_excel(d, s):
    import openpyxl
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Laporan"
    for ln in _report_lines(d, s):
        ws.append([ln.replace("*", "")])
    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return buf

def _report_pdf(d, s, ai_text=None):
    from fpdf import FPDF
    pdf = FPDF(); pdf.add_page(); pdf.set_font("Helvetica", size=12)
    for ln in _report_lines(d, s, ai_text):
        txt = ln.replace("*", "").encode("latin-1", "replace").decode("latin-1")
        pdf.multi_cell(pdf.epw, 7, txt or " ")
    return io.BytesIO(bytes(pdf.output()))

@api.get("/reports/export/excel")
async def export_report_excel(date_str: Optional[str] = Query(None, alias="date"), user: dict = Depends(get_current_user)):
    d = date_str or wib_today()
    s = await report_summary(date_str=d, admin=user)
    return StreamingResponse(_report_excel(d, s), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f"attachment; filename=laporan-{d}.xlsx"})

@api.get("/reports/export/pdf")
async def export_report_pdf(date_str: Optional[str] = Query(None, alias="date"), user: dict = Depends(get_current_user)):
    d = date_str or wib_today()
    s = await report_summary(date_str=d, admin=user)
    return StreamingResponse(_report_pdf(d, s), media_type="application/pdf",
                             headers={"Content-Disposition": f"attachment; filename=laporan-{d}.pdf"})

# -------------------------------------------------------- VENDOR SETTLEMENT
async def _vendor_report(date_str=None, start=None, end=None):
    if start and end:
        s_utc, _ = wib_day_range(start)
        _, e_utc = wib_day_range(end)
        label = f"{start} s/d {end}"
    else:
        d = date_str or wib_today()
        s_utc, e_utc = wib_day_range(d)
        label = d
    q = {"status": "paid", "created_at": {"$gte": s_utc, "$lt": e_utc}}
    orders = await db.orders.find(q, {"_id": 0}).to_list(20000)
    vendors = await db.vendors.find({}, {"_id": 0}).to_list(500)
    vmap = {v["id"]: v for v in vendors}
    agg = {}
    for o in orders:
        for it in o.get("items", []):
            if it.get("type") == "vendor" and it.get("vendor_id"):
                vid = it["vendor_id"]
                a = agg.setdefault(vid, {"vendor_id": vid,
                                         "vendor_name": vmap.get(vid, {}).get("name", "(vendor dihapus)"),
                                         "qty": 0, "gross": 0, "vendor_share": 0, "_items": {}})
                line = it["price"] * it["qty"]
                share = it.get("vendor_total", round(line * float(it.get("vendor_share_percent") or 0) / 100, 2))
                a["qty"] += it["qty"]
                a["gross"] += line
                a["vendor_share"] += share
                im = a["_items"].setdefault(it.get("product_id") or it["name"], {
                    "product_id": it.get("product_id"), "name": it["name"],
                    "qty": 0, "gross": 0.0, "vendor_share": 0.0})
                im["qty"] += it["qty"]
                im["gross"] += line
                im["vendor_share"] += share
    # Deteksi tipe vendor (F&B = produk makanan/minuman/vendor dgn kategori fnb; else retail)
    prod_vendor_type = {}
    for p in await db.products.find({"type": "vendor"}, {"_id": 0, "id": 1, "category_id": 1}).to_list(2000):
        cid = p.get("category_id")
        prod_vendor_type[p["id"]] = "fnb"  # default; diperhalus via kategori
    cats = {c["id"]: c for c in await db.categories.find({}, {"_id": 0}).to_list(1000)}
    for p in await db.products.find({"type": "vendor"}, {"_id": 0, "id": 1, "category_id": 1}).to_list(2000):
        c = cats.get(p.get("category_id")) or {}
        if c.get("type") == "retail":
            prod_vendor_type[p["id"]] = "retail"
    # Tambah scope ke tiap baris vendor: dari tipe produk item (item punya 'type' vendor; pakai kategori produk)
    # Per vendor, kita ambil scope mayoritas dari item yang bersangkutan.
    vendor_scope = {}
    for o in orders:
        for it in o.get("items", []):
            if it.get("type") == "vendor" and it.get("vendor_id"):
                sc = prod_vendor_type.get(it.get("product_id"), "fnb")
                vendor_scope[it["vendor_id"]] = sc
    rows = sorted(agg.values(), key=lambda x: x["gross"], reverse=True)
    for r in rows:
        r["gross"] = round(r["gross"], 2)
        r["vendor_share"] = round(r["vendor_share"], 2)
        r["outlet_share"] = round(r["gross"] - r["vendor_share"], 2)
        r["scope"] = vendor_scope.get(r["vendor_id"], "fnb")
        items = sorted(r.pop("_items", {}).values(), key=lambda y: y["gross"], reverse=True)
        for im in items:
            im["gross"] = round(im["gross"], 2)
            im["vendor_share"] = round(im["vendor_share"], 2)
        r["items"] = items
    total_gross = round(sum(r["gross"] for r in rows), 2)
    total_vendor = round(sum(r["vendor_share"] for r in rows), 2)
    fnb = [r for r in rows if r["scope"] == "fnb"]
    retail = [r for r in rows if r["scope"] == "retail"]
    return {"label": label, "rows": rows, "total_gross": total_gross,
            "total_vendor_share": total_vendor, "total_outlet_share": round(total_gross - total_vendor, 2),
            "fnb_gross": round(sum(r["gross"] for r in fnb), 2),
            "fnb_vendor_share": round(sum(r["vendor_share"] for r in fnb), 2),
            "retail_gross": round(sum(r["gross"] for r in retail), 2),
            "retail_vendor_share": round(sum(r["vendor_share"] for r in retail), 2)}

def _vendor_report_lines(rep):
    L = ["*Laporan Bagi Hasil Vendor - Grand Aceh Kuliner*", f"Periode: {rep['label']}", "",
         f"Total Omzet Vendor: Rp{rep['total_gross']:,.0f}",
         f"Total Bagi Hasil Vendor: Rp{rep['total_vendor_share']:,.0f}",
         f"Bagian Outlet: Rp{rep['total_outlet_share']:,.0f}", ""]
    if rep["rows"]:
        L.append("Rincian per Vendor:")
        for r in rep["rows"]:
            L.append(f"- {r['vendor_name']} (x{r['qty']}): Omzet Rp{r['gross']:,.0f} -> Vendor Rp{r['vendor_share']:,.0f}")
            for im in (r.get("items") or []):
                L.append(f"    - {im['name']} (x{im['qty']}): Omzet Rp{im['gross']:,.0f} (Vendor Rp{im['vendor_share']:,.0f})")
    else:
        L.append("Belum ada penjualan produk vendor pada periode ini.")
    return L

@api.get("/reports/vendors")
async def report_vendors(date_str: Optional[str] = Query(None, alias="date"),
                         start: Optional[str] = None, end: Optional[str] = None,
                         admin: dict = Depends(admin_or_kasir)):
    return await _vendor_report(date_str, start, end)

@api.get("/reports/vendors/export/excel")
async def export_vendor_excel(date_str: Optional[str] = Query(None, alias="date"),
                              start: Optional[str] = None, end: Optional[str] = None,
                              admin: dict = Depends(admin_or_kasir)):
    import openpyxl
    rep = await _vendor_report(date_str, start, end)
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Bagi Hasil Vendor"
    ws.append(["Vendor", "Qty", "Omzet", "Bagi Hasil Vendor", "Bagian Outlet"])
    for r in rep["rows"]:
        ws.append([r["vendor_name"], r["qty"], r["gross"], r["vendor_share"], r["outlet_share"]])
        for im in (r.get("items") or []):
            ws.append(["   - " + im["name"], im["qty"], im["gross"], im["vendor_share"], ""])
    ws.append([])
    ws.append(["TOTAL", "", rep["total_gross"], rep["total_vendor_share"], rep["total_outlet_share"]])
    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f"attachment; filename=bagi-hasil-vendor-{rep['label']}.xlsx"})

@api.get("/reports/vendors/export/pdf")
async def export_vendor_pdf(date_str: Optional[str] = Query(None, alias="date"),
                            start: Optional[str] = None, end: Optional[str] = None,
                            admin: dict = Depends(admin_or_kasir)):
    from fpdf import FPDF
    rep = await _vendor_report(date_str, start, end)
    pdf = FPDF(); pdf.add_page(); pdf.set_font("Helvetica", size=12)
    for ln in _vendor_report_lines(rep):
        txt = ln.replace("*", "").encode("latin-1", "replace").decode("latin-1")
        pdf.multi_cell(pdf.epw, 7, txt or " ")
    out = io.BytesIO(bytes(pdf.output()))
    return StreamingResponse(out, media_type="application/pdf",
                             headers={"Content-Disposition": f"attachment; filename=bagi-hasil-vendor-{rep['label']}.pdf"})

class VendorWASendIn(BaseModel):
    date: Optional[str] = None
    start: Optional[str] = None
    end: Optional[str] = None
    recipients: Optional[List[str]] = None

@api.post("/reports/vendors/send-whatsapp")
async def send_vendor_whatsapp(body: VendorWASendIn, admin: dict = Depends(require_admin)):
    rep = await _vendor_report(body.date, body.start, body.end)
    doc = await db.settings.find_one({"_id": "report"}) or {}
    recips = body.recipients or doc.get("recipients", [])
    if not recips:
        raise HTTPException(400, "Belum ada nomor WhatsApp tujuan. Atur di 'WhatsApp & Laporan'.")
    text = await _tpl_fill("vendor", _vendor_wa_env(rep))
    result = await _send_whatsapp(recips, text)
    if not any(r.get("ok") for r in result):
        raise HTTPException(400, f"Gagal kirim WhatsApp: {result[0].get('error') if result else 'tidak diketahui'}")
    return {"sent": result}

class ReportSettingsIn(BaseModel):
    whatsapp_enabled: bool = False
    whatsapp_time: str = "22:00"
    recipients: List[str] = []
    include_ai: bool = True
    send_sales: bool = True
    send_purchases: bool = False

@api.get("/settings/report")
async def get_report_settings(admin: dict = Depends(require_admin)):
    doc = await db.settings.find_one({"_id": "report"}, {"_id": 0}) or {}
    return {
        "whatsapp_enabled": doc.get("whatsapp_enabled", False),
        "whatsapp_time": doc.get("whatsapp_time", "22:00"),
        "recipients": doc.get("recipients", []),
        "include_ai": doc.get("include_ai", True),
        "send_sales": doc.get("send_sales", True),
        "send_purchases": doc.get("send_purchases", False),
        "whatsapp_configured": await _wa_configured(),
        "last_sent_date": doc.get("last_sent_date"),
    }

@api.put("/settings/report")
async def put_report_settings(body: ReportSettingsIn, admin: dict = Depends(require_admin)):
    await db.settings.update_one({"_id": "report"}, {"$set": {
        "whatsapp_enabled": body.whatsapp_enabled, "whatsapp_time": body.whatsapp_time,
        "recipients": [r.strip() for r in body.recipients if r.strip()], "include_ai": body.include_ai,
        "send_sales": body.send_sales, "send_purchases": body.send_purchases,
    }}, upsert=True)
    return {"ok": True}

async def _send_whatsapp(recipients, text):
    if not await _feat("wa.enabled"):
        raise HTTPException(400, "Fitur WhatsApp dimatikan. Nyalakan di Pengaturan → Fitur & Integrasi.")
    out = []
    for to in recipients:
        try:
            r = await _wa_send_text(to, text)
            body = {}
            try:
                body = r.json()
            except Exception:
                pass
            if r.status_code in (200, 201) and body.get("success", True):
                out.append({"to": to, "ok": True, "id": (body.get("data") or {}).get("message_id")})
            else:
                out.append({"to": to, "ok": False, "error": body.get("error") or body.get("message") or r.text})
        except HTTPException as he:
            out.append({"to": to, "ok": False, "error": he.detail})
        except Exception as e:
            out.append({"to": to, "ok": False, "error": str(e)})
    return out

class WhatsAppSendIn(BaseModel):
    date: Optional[str] = None
    recipients: Optional[List[str]] = None

@api.post("/reports/send-whatsapp")
async def send_report_whatsapp(body: WhatsAppSendIn, admin: dict = Depends(require_admin)):
    d = body.date or wib_today()
    s = await report_summary(date_str=d, admin=admin)
    doc = await db.settings.find_one({"_id": "report"}) or {}
    recips = body.recipients or doc.get("recipients", [])
    if not recips:
        raise HTTPException(400, "Belum ada nomor WhatsApp tujuan. Atur di Pengaturan.")
    ai_text = None
    if doc.get("include_ai", True):
        try:
            r = await ai_summary(AISummaryIn(date=d), admin=admin)
            ai_text = r.get("summary")
        except Exception:
            ai_text = None
    text = await _tpl_fill("daily", _daily_wa_env(d, s, ai_text))
    result = await _send_whatsapp(recips, text)
    if not any(r.get("ok") for r in result):
        raise HTTPException(400, f"Gagal kirim WhatsApp: {result[0].get('error') if result else 'tidak diketahui'}")
    return {"sent": result}

async def _run_daily_report_job():
    if not await _feat("wa.enabled"):
        return
    doc = await db.settings.find_one({"_id": "report"}) or {}
    if not doc.get("whatsapp_enabled") or not doc.get("recipients"):
        return
    if not await _wa_configured():
        return
    noww = datetime.now(WIB)
    try:
        target_hour = int(str(doc.get("whatsapp_time", "22:00")).split(":")[0])
    except Exception:
        target_hour = 22
    if noww.hour != target_hour:
        return
    today = noww.strftime("%Y-%m-%d")
    if doc.get("last_sent_date") == today:
        return
    messages = []
    if doc.get("send_sales", True):
        s = await report_summary(date_str=today, admin={"role": "admin", "id": "cron"})
        ai_text = None
        if doc.get("include_ai", True):
            try:
                r = await ai_summary(AISummaryIn(date=today), admin={"role": "admin", "id": "cron"})
                ai_text = r.get("summary")
            except Exception:
                pass
        messages.append(await _tpl_fill("daily", _daily_wa_env(today, s, ai_text)))
    if doc.get("send_purchases", False):
        items, total = await _purchase_summary(today)
        messages.append(await _tpl_fill("purchase", _purchase_wa_env(today, items, total)))
    if not messages:
        return
    try:
        for msg in messages:
            await _send_whatsapp(doc["recipients"], msg)
        await db.settings.update_one({"_id": "report"}, {"$set": {"last_sent_date": today}}, upsert=True)
        logger.info(f"Daily WA report sent for {today}")
    except Exception as e:
        logger.error(f"Daily WA report failed: {e}")

@api.post("/cron/daily-report")
async def cron_daily_report(request: Request, background: BackgroundTasks):
    # Cron endpoints must ack 2xx immediately; enqueue/background the actual work.
    import hmac as _hmac
    auth = request.headers.get("Authorization", "")
    token = auth[7:] if auth.startswith("Bearer ") else ""
    if not (WEBHOOK_CRON_SECRET and _hmac.compare_digest(token, WEBHOOK_CRON_SECRET)):
        raise HTTPException(401, "unauthorized")
    background.add_task(_run_daily_report_job)
    return {"ok": True}

class CronNotifyIn(BaseModel):
    to: str
    message: str

@api.post("/cron/notify")
async def cron_notify(request: Request, body: CronNotifyIn):
    import hmac as _hmac
    auth = request.headers.get("Authorization", "")
    token = auth[7:] if auth.startswith("Bearer ") else ""
    if not (WEBHOOK_CRON_SECRET and _hmac.compare_digest(token, WEBHOOK_CRON_SECRET)):
        raise HTTPException(401, "unauthorized")
    if not body.to.strip():
        raise HTTPException(400, "nomor tujuan kosong")
    res = await _send_whatsapp([body.to.strip()], body.message)
    return {"sent": res}

# ---- WhatsApp Gateway (wacloud.id) config, devices & test ----
class WAConfigIn(BaseModel):
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    device_id: Optional[str] = None
    device_name: Optional[str] = None

@api.get("/whatsapp/config")
async def whatsapp_get_config(admin: dict = Depends(require_admin)):
    c = await _wa_config()
    key = c.get("api_key") or ""
    return {
        "configured": bool(c.get("api_key") and c.get("device_id")),
        "api_key_set": bool(key),
        "api_key_masked": (key[:6] + "…" + key[-4:]) if len(key) > 12 else ("•" * len(key)),
        "base_url": c.get("base_url") or WACLOUD_DEFAULT_BASE,
        "device_id": c.get("device_id", ""),
        "device_name": c.get("device_name", ""),
    }

@api.put("/whatsapp/config")
async def whatsapp_put_config(body: WAConfigIn, admin: dict = Depends(require_admin)):
    upd = {}
    if body.api_key is not None and body.api_key.strip():
        upd["api_key"] = body.api_key.strip()
    if body.base_url is not None:
        upd["base_url"] = body.base_url.strip() or WACLOUD_DEFAULT_BASE
    if body.device_id is not None:
        upd["device_id"] = body.device_id.strip()
    if body.device_name is not None:
        upd["device_name"] = body.device_name.strip()
    if upd:
        await db.settings.update_one({"_id": "wa"}, {"$set": upd}, upsert=True)
    return {"ok": True}

@api.get("/whatsapp/devices")
async def whatsapp_devices(admin: dict = Depends(require_admin)):
    try:
        r = await _wacloud_request("GET", "/devices")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, f"Gagal menghubungi wacloud.id: {e}")
    if r.status_code != 200:
        try:
            j = r.json()
            detail = j.get("message") or j.get("error") or r.text
        except Exception:
            detail = r.text
        raise HTTPException(r.status_code if r.status_code >= 400 else 400, f"wacloud.id: {detail}")
    data = r.json()
    devices = data.get("data", data) if isinstance(data, dict) else data
    return {"devices": devices or []}

class WATestIn(BaseModel):
    to: str
    message: Optional[str] = "Tes notifikasi Grand Aceh Kuliner POS ✅"

@api.post("/whatsapp/test")
async def whatsapp_test(body: WATestIn, admin: dict = Depends(require_admin)):
    if not body.to.strip():
        raise HTTPException(400, "Nomor tujuan wajib diisi")
    res = await _send_whatsapp([body.to.strip()], body.message or "Tes")
    if not any(x.get("ok") for x in res):
        raise HTTPException(400, f"Gagal kirim: {res[0].get('error') if res else 'tidak diketahui'}")
    return {"sent": res}

# ================================================================== MEMBERS (poin loyalitas)
class MemberIn(BaseModel):
    name: str
    phone: str = ""
    points: float = 0

@api.get("/members")
async def list_members(q: Optional[str] = None, user: dict = Depends(admin_or_kasir)):
    query = {}
    if q:
        import re as _re
        rx = _re.compile(re.escape(q), _re.I)
        query["$or"] = [{"name": rx}, {"phone": rx}]
    return await db.members.find(query, {"_id": 0}).sort("name", 1).to_list(500)

@api.post("/members")
async def create_member(body: MemberIn, admin: dict = Depends(require_admin)):
    m = {"id": new_id(), "name": body.name.strip(), "phone": body.phone.strip(),
         "points": float(body.points or 0), "total_spend": 0.0, "created_at": now_utc().isoformat()}
    if not m["name"]:
        raise HTTPException(400, "Nama wajib diisi")
    await db.members.insert_one(m)
    m.pop("_id", None)
    return m

@api.put("/members/{mid}")
async def update_member(mid: str, body: MemberIn, admin: dict = Depends(require_admin)):
    upd = {"name": body.name.strip(), "phone": body.phone.strip(), "points": float(body.points or 0)}
    r = await db.members.update_one({"id": mid}, {"$set": upd})
    if not r.matched_count:
        raise HTTPException(404, "Member tidak ditemukan")
    return {"ok": True}

@api.delete("/members/{mid}")
async def delete_member(mid: str, admin: dict = Depends(require_admin)):
    await db.members.delete_one({"id": mid})
    return {"ok": True}

@api.get("/members/search")
async def search_member(phone: str, user: dict = Depends(admin_or_kasir)):
    if not phone.strip():
        return {"member": None}
    m = await db.members.find_one({"phone": phone.strip()}, {"_id": 0})
    return {"member": m}

# ================================================================== PROMOS
class PromoIn(BaseModel):
    name: str
    type: Literal["percent", "happy_hour", "min_spend", "package", "bogo"]
    value: float = 0
    bonus: float = 0
    start_time: str = ""
    end_time: str = ""
    days: List[int] = []
    package_items: List[dict] = []
    active: bool = True

@api.get("/promos")
async def list_promos(user: dict = Depends(get_current_user)):
    return await db.promos.find({}, {"_id": 0}).sort("created_at", -1).to_list(200)

@api.post("/promos")
async def create_promo(body: PromoIn, admin: dict = Depends(require_admin)):
    p = {"id": new_id(), "name": body.name.strip(), "type": body.type, "value": body.value,
         "bonus": body.bonus, "start_time": body.start_time, "end_time": body.end_time,
         "days": body.days, "package_items": body.package_items, "active": body.active,
         "created_at": now_utc().isoformat()}
    if not p["name"]:
        raise HTTPException(400, "Nama promo wajib diisi")
    await db.promos.insert_one(p)
    p.pop("_id", None)
    return p

@api.put("/promos/{pid}")
async def update_promo(pid: str, body: PromoIn, admin: dict = Depends(require_admin)):
    upd = {"name": body.name.strip(), "type": body.type, "value": body.value, "bonus": body.bonus,
           "start_time": body.start_time, "end_time": body.end_time, "days": body.days,
           "package_items": body.package_items, "active": body.active}
    r = await db.promos.update_one({"id": pid}, {"$set": upd})
    if not r.matched_count:
        raise HTTPException(404, "Promo tidak ditemukan")
    return {"ok": True}

@api.delete("/promos/{pid}")
async def delete_promo(pid: str, admin: dict = Depends(require_admin)):
    await db.promos.delete_one({"id": pid})
    return {"ok": True}

# ================================================================== KUPON DISKON
@api.get("/coupons")
async def list_coupons(user: dict = Depends(get_current_user)):
    return await db.coupons.find({}, {"_id": 0}).sort("created_at", -1).to_list(500)

@api.post("/coupons")
async def create_coupon(body: CouponIn, admin: dict = Depends(require_admin)):
    code = body.code.strip().upper()
    if not code:
        raise HTTPException(400, "Kode kupon wajib")
    if await db.coupons.find_one({"code": code}):
        raise HTTPException(400, f"Kode kupon '{code}' sudah ada")
    doc = body.model_dump()
    doc["code"] = code
    doc["used_count"] = 0
    doc.update({"id": new_id(), "created_at": now_utc().isoformat()})
    await db.coupons.insert_one(doc)
    doc.pop("_id", None)
    return doc

@api.put("/coupons/{cid}")
async def update_coupon(cid: str, body: CouponIn, admin: dict = Depends(require_admin)):
    code = body.code.strip().upper()
    dup = await db.coupons.find_one({"code": code, "id": {"$ne": cid}})
    if dup:
        raise HTTPException(400, f"Kode kupon '{code}' sudah dipakai")
    upd = body.model_dump()
    upd["code"] = code
    r = await db.coupons.update_one({"id": cid}, {"$set": upd})
    if not r.matched_count:
        raise HTTPException(404, "Kupon tidak ditemukan")
    return {"ok": True}

@api.delete("/coupons/{cid}")
async def delete_coupon(cid: str, admin: dict = Depends(require_admin)):
    await db.coupons.delete_one({"id": cid})
    return {"ok": True}

# ================================================================== SPLIT / PINDAH / GABUNG MEJA
class SplitIn(BaseModel):
    items: List[OrderItem]

@api.post("/orders/{oid}/split")
async def split_order(oid: str, body: SplitIn, admin: dict = Depends(require_admin)):
    if not body.items:
        raise HTTPException(400, "Pilih item yang akan dipindah")
    o = await db.orders.find_one({"id": oid})
    if not o or o["status"] != "open":
        raise HTTPException(400, "Order tidak ditemukan / bukan open bill")
    moved_ids = {it.product_id: it.qty for it in body.items}
    keep, moved = [], []
    for it in o["items"]:
        need = moved_ids.get(it["product_id"], 0)
        if need >= it["qty"]:
            moved.append({**it})
            moved_ids[it["product_id"]] = need - it["qty"]
        elif need > 0:
            moved.append({**it, "qty": need})
            keep.append({**it, "qty": it["qty"] - need})
            moved_ids[it["product_id"]] = 0
        else:
            keep.append({**it})
    if not moved:
        raise HTTPException(400, "Tidak ada item yang valid untuk dipindah")
    st_k, d_k, _ = compute_totals(keep, o["discount_type"], o["discount_value"])
    pr_k, pn_k = await _apply_promos(keep, st_k)
    t_k = max(0.0, round(st_k - d_k - pr_k, 2))
    new_doc = {
        "id": new_id(), "order_number": await gen_order_number(),
        "order_type": o["order_type"], "table_id": o.get("table_id"), "items": moved,
        "subtotal": sum(i["price"] * i["qty"] for i in moved),
        "discount_type": "none", "discount_value": 0, "discount": 0,
        "promo_discount": 0, "promos_applied": [], "redeem_discount": 0,
        "total": sum(i["price"] * i["qty"] for i in moved),
        "note": f"Split dari {o['order_number']}", "status": "open",
        "cashier_id": admin["id"], "cashier_name": admin["name"],
        "created_at": now_utc().isoformat(), "parent_order": o["id"],
    }
    await db.orders.insert_one(new_doc)
    await db.orders.update_one({"id": oid}, {"$set": {"items": keep, "subtotal": st_k,
                                                      "discount": d_k, "promo_discount": pr_k,
                                                      "promos_applied": pn_k, "total": t_k}})
    new_doc.pop("_id", None)
    return {"original": await db.orders.find_one({"id": oid}, {"_id": 0}), "new_order": new_doc}

class TableMoveIn(BaseModel):
    table_id: str

@api.patch("/orders/{oid}/table")
async def move_order_table(oid: str, body: TableMoveIn, user: dict = Depends(get_current_user)):
    o = await db.orders.find_one({"id": oid})
    if not o or o["status"] != "open":
        raise HTTPException(400, "Order tidak ditemukan / bukan open bill")
    await db.orders.update_one({"id": oid}, {"$set": {"table_id": body.table_id}})
    return {"ok": True}

class MergeIn(BaseModel):
    target_id: str

@api.post("/orders/{oid}/merge")
async def merge_orders(oid: str, body: MergeIn, admin: dict = Depends(require_admin)):
    o = await db.orders.find_one({"id": oid})
    t = await db.orders.find_one({"id": body.target_id})
    if not o or not t or o["status"] != "open" or t["status"] != "open":
        raise HTTPException(400, "Kedua order harus open bill")
    if o["id"] == t["id"]:
        raise HTTPException(400, "Target tidak boleh sama")
    merged_items = t["items"] + o["items"]
    st, d, _ = compute_totals(merged_items, t["discount_type"], t["discount_value"])
    pr, pn = await _apply_promos(merged_items, st)
    tot = max(0.0, round(st - d - pr, 2))
    await db.orders.update_one({"id": t["id"]}, {"$set": {"items": merged_items, "subtotal": st,
                                                          "discount": d, "promo_discount": pr,
                                                          "promos_applied": pn, "total": tot}})
    await db.orders.update_one({"id": oid}, {"$set": {"status": "merged", "merged_into": t["id"],
                                                      "void_reason": f"Digabung ke {t['order_number']}"}})
    return {"ok": True, "target": await db.orders.find_one({"id": t["id"]}, {"_id": 0})}

# ================================================================== LABA KOTOR PER PRODUK
@api.get("/reports/profit")
async def report_profit(start: str, end: str, admin: dict = Depends(admin_or_kasir)):
    s, e = wib_day_range(start[:10]), wib_day_range(end[:10])
    q = {"status": "paid", "created_at": {"$gte": s[0], "$lte": e[1]}}
    orders = await db.orders.find(q, {"_id": 0}).to_list(5000)
    rows = {}
    for o in orders:
        for it in o.get("items", []):
            pid = it["product_id"]
            r = rows.setdefault(pid, {"name": it["name"], "qty": 0, "revenue": 0.0, "cost": 0.0})
            r["qty"] += it["qty"]
            r["revenue"] += it["price"] * it["qty"]
            r["cost"] += (it.get("cost") or 0) * it["qty"]
    out = []
    for pid, r in rows.items():
        out.append({"product_id": pid, "name": r["name"], "qty": r["qty"],
                    "revenue": round(r["revenue"], 2), "cost": round(r["cost"], 2),
                    "profit": round(r["revenue"] - r["cost"], 2),
                    "margin": round((r["revenue"] - r["cost"]) / r["revenue"] * 100, 1) if r["revenue"] else 0})
    out.sort(key=lambda x: x["profit"], reverse=True)
    return {"rows": out, "total_revenue": round(sum(r["revenue"] for r in rows.values()), 2),
            "total_cost": round(sum(r["cost"] for r in rows.values()), 2),
            "total_profit": round(sum(r["revenue"] - r["cost"] for r in rows.values()), 2)}

# ================================================================== REKOMENDASI PEMBELIAN STOK (AI)
@api.post("/ai/purchase-recommendation")
async def purchase_recommendation(admin: dict = Depends(admin_or_kasir)):
    import json
    end = datetime.now(WIB)
    start = end - timedelta(days=30)
    days = 30
    sold = {}
    for o in await db.orders.find({"status": "paid", "created_at": {"$gte": start.isoformat()}}, {"_id": 0, "items": 1}).to_list(5000):
        for it in o.get("items", []):
            if it.get("type") == "retail":
                sold[it["product_id"]] = sold.get(it["product_id"], 0) + it["qty"]
    recs = []
    for p in await db.products.find({"type": "retail", "track_stock": True}, {"_id": 0}).to_list(2000):
        qty30 = sold.get(p["id"], 0)
        avg = qty30 / days
        stock = float(p.get("stock") or 0)
        min_stock = float(p.get("min_stock") or 10)
        suggest = max(0.0, (avg * 14) - stock)
        recs.append({"product_id": p["id"], "name": p["name"], "stock": stock,
                     "min_stock": min_stock, "sold_30d": qty30, "daily_avg": round(avg, 2),
                     "suggest": math.ceil(suggest)})
    recs.sort(key=lambda x: x["sold_30d"], reverse=True)
    ai_text = ""
    try:
        top = recs[:12]
        prompt = ("Buat ringkasan rekomendasi pembelian stok dalam 3-5 baris Bahasa Indonesia. "
                  f"Data (produk, stok, terjual 30 hari, saran beli):\n{json.dumps(top, ensure_ascii=False, default=str)}")
        ai_text = await _gemini_text("Anda analis stok restoran.", prompt, feature="summary")
    except Exception:
        ai_text = ""
    return {"rows": recs, "ai_summary": ai_text}

# ================================================================== SETTINGS OUTLET (nama/alamat/logo)
class OutletIn(BaseModel):
    name: str = ""
    address: str = ""
    phone: str = ""

@api.get("/settings/outlet")
async def get_outlet(admin: dict = Depends(require_admin)):
    doc = await db.settings.find_one({"_id": "outlet"}, {"_id": 0}) or {}
    return {"name": doc.get("name", ""), "address": doc.get("address", ""),
            "phone": doc.get("phone", ""), "logo_url": doc.get("logo_url", "")}

@api.put("/settings/outlet")
async def put_outlet(body: OutletIn, admin: dict = Depends(require_admin)):
    await db.settings.update_one({"_id": "outlet"}, {"$set": {
        "name": body.name.strip(), "address": body.address.strip(), "phone": body.phone.strip()}}, upsert=True)
    return {"ok": True}

@api.post("/settings/outlet/logo")
async def upload_logo(file: UploadFile = File(...), admin: dict = Depends(require_admin)):
    import mimetypes
    ok_types = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "image/gif": ".gif"}
    ext = ok_types.get(file.content_type or "")
    if not ext:
        raise HTTPException(400, "Format logo harus PNG/JPG/WEBP/GIF")
    data = await file.read()
    if len(data) > 2_000_000:
        raise HTTPException(400, "Logo maksimal 2MB")
    fname = f"logo-{new_id()}{ext}"
    (UPLOAD_DIR / fname).write_bytes(data)
    url = f"/uploads/{fname}"
    await db.settings.update_one({"_id": "outlet"}, {"$set": {"logo_url": url}}, upsert=True)
    return {"ok": True, "url": url}

# ================================================================== PENGATURAN APLIKASI (bisa diubah admin tanpa kode)
@api.get("/settings/business")
async def get_business(user: dict = Depends(get_current_user)):
    return await _business()

BIZ_ALLOWED = set(BIZ_DEFAULTS.keys())

@api.put("/settings/business")
async def put_business(body: dict, admin: dict = Depends(require_admin)):
    clean = {}
    for k, v in (body or {}).items():
        if k not in BIZ_ALLOWED:
            continue
        if k == "labels" and isinstance(v, dict):
            clean["labels"] = {str(kk).strip(): str(vv).strip() for kk, vv in v.items() if str(vv).strip()}
        elif k == "order_prefix":
            clean["order_prefix"] = str(v).strip()[:10] or "GAK-"
        elif isinstance(v, (int, float)) and not isinstance(v, bool):
            clean[k] = max(0, float(v)) if k != "discount_reason_percent" else min(100, max(0, float(v)))
        elif isinstance(v, str) and str(v).strip() and k not in ("labels", "order_prefix"):
            clean[k] = str(v).strip()
    if not clean:
        raise HTTPException(400, "Tidak ada pengaturan valid")
    await db.settings.update_one({"_id": "business"}, {"$set": clean}, upsert=True)
    _cache_del("biz")
    return await _business()

# ================================================================== DASHBOARD WIDGET (default per role)
ROLE_WIDGET_DEFAULTS = {
    "admin": ["kpi", "jenis", "finansial", "trend", "kategori", "terlaris", "metode", "ai", "lowstock"],
    "kasir": ["kpi", "jenis", "finansial", "trend", "terlaris", "metode"],
    "input": ["lowstock"],
}

@api.get("/settings/dashboard")
async def get_dashboard_layouts(user: dict = Depends(get_current_user)):
    doc = await db.settings.find_one({"_id": "dashboard"}, {"_id": 0}) or {}
    out = {}
    for role, dflt in ROLE_WIDGET_DEFAULTS.items():
        val = doc.get(role)
        out[role] = val if isinstance(val, list) and val else dflt
    return out

@api.put("/settings/dashboard")
async def put_dashboard_layout(body: dict, admin: dict = Depends(require_admin)):
    role = str(body.get("role") or "")
    widgets = body.get("widgets")
    if role not in ROLE_WIDGET_DEFAULTS:
        raise HTTPException(400, "Role tidak valid")
    if not isinstance(widgets, list):
        raise HTTPException(400, "widgets harus berupa daftar")
    known = {"kpi", "jenis", "finansial", "trend", "kategori", "terlaris", "metode", "ai", "lowstock"}
    # izinkan juga widget kustom (id "custom:<widget_id>") yang masih ada
    cw_ids = {d["id"] for d in await db.custom_widgets.find({}, {"_id": 0, "id": 1}).to_list(500)}
    clean = []
    for w in widgets:
        w = str(w)
        if w in known or (w.startswith("custom:") and w[len("custom:"):] in cw_ids):
            clean.append(w)
    await db.settings.update_one({"_id": "dashboard"}, {"$set": {role: clean}}, upsert=True)
    return {"ok": True, role: clean}

# ================================================================== KUSTOMISASI UI (tanpa ubah kode)
# settings._id="ui": {menu:{order:[], hidden:[], labels:{}}} + pos:{labels:{}} +
# dashboard:{order:{role:[widget_ids]}} (default urutan widget dashboard per role).
UI_DEFAULT = {"menu": {"order": [], "hidden": [], "labels": {}}, "pos": {"labels": {}}, "dashboard": {"order": {}}}

async def _ui_config():
    doc = await db.settings.find_one({"_id": "ui"}, {"_id": 0}) or {}
    out = json.loads(json.dumps(UI_DEFAULT))
    menu = doc.get("menu") or {}
    if isinstance(menu.get("order"), list):
        out["menu"]["order"] = [str(x) for x in menu["order"] if str(x).startswith("/")]
    if isinstance(menu.get("hidden"), list):
        out["menu"]["hidden"] = [str(x) for x in menu["hidden"] if str(x).startswith("/")]
    if isinstance(menu.get("labels"), dict):
        out["menu"]["labels"] = {str(k): str(v)[:40] for k, v in menu["labels"].items() if str(k).startswith("/") and str(v).strip()}
    pos = doc.get("pos") or {}
    if isinstance(pos.get("labels"), dict):
        out["pos"]["labels"] = {str(k): str(v)[:40] for k, v in pos["labels"].items() if str(v).strip()}
    dash = doc.get("dashboard") or {}
    if isinstance(dash.get("order"), dict):
        out["dashboard"]["order"] = {str(r): [str(x) for x in v] for r, v in dash["order"].items() if isinstance(v, list)}
    return out

@api.get("/settings/ui")
async def get_ui_config(user: dict = Depends(get_current_user)):
    """Dipakai Layout/POS/Dashboard — boleh dibaca semua user terautentikasi."""
    return await _ui_config()

@api.put("/settings/ui")
async def put_ui_config(body: dict, admin: dict = Depends(require_admin)):
    cur = await _ui_config()
    menu = body.get("menu") if isinstance(body.get("menu"), dict) else {}
    pos = body.get("pos") if isinstance(body.get("pos"), dict) else {}
    dash = body.get("dashboard") if isinstance(body.get("dashboard"), dict) else {}
    if isinstance(menu.get("order"), list):
        cur["menu"]["order"] = [str(x) for x in menu["order"] if str(x).startswith("/")]
    if isinstance(menu.get("hidden"), list):
        cur["menu"]["hidden"] = [str(x) for x in menu["hidden"] if str(x).startswith("/")]
    if isinstance(menu.get("labels"), dict):
        cur["menu"]["labels"] = {str(k): str(v)[:40] for k, v in menu["labels"].items() if str(k).startswith("/") and str(v).strip()}
    if isinstance(pos.get("labels"), dict):
        cur["pos"]["labels"] = {str(k): str(v)[:40] for k, v in pos["labels"].items() if str(v).strip()}
    if isinstance(dash.get("order"), dict):
        cur["dashboard"]["order"] = {str(r): [str(x) for x in v] for r, v in dash["order"].items() if isinstance(v, list)}
    await db.settings.update_one({"_id": "ui"}, {"$set": cur}, upsert=True)
    return {"ok": True, "ui": cur}

# ================================================================== PENGATURAN PLATFORM (nama aplikasi, logo, warna tema)
# Bisa diubah admin tanpa deploy ulang; dipakai login, sidebar, & judul aplikasi.
PLATFORM_DEFAULTS = {
    "app_name": "Grand Aceh Kuliner",
    "tagline": "KULINER POS",
    "primary": "#E63946",
    "accent": "#F97316",
    "logo_url": "",
}

async def _platform():
    doc = await db.settings.find_one({"_id": "platform"}, {"_id": 0}) or {}
    out = dict(PLATFORM_DEFAULTS)
    for k in out:
        v = doc.get(k)
        if k == "logo_url":
            if isinstance(v, str) and v:
                out[k] = v
        elif isinstance(v, str) and v.strip():
            out[k] = v.strip()[:60]
    return out

@api.get("/app-info")
async def app_info():
    """Info publik (tanpa login) utk layar login & branding aplikasi."""
    p = await _platform()
    p["has_custom"] = bool(p["logo_url"]) or p["primary"] != PLATFORM_DEFAULTS["primary"] or p["accent"] != PLATFORM_DEFAULTS["accent"]
    return p

@api.get("/settings/platform")
async def get_platform(admin: dict = Depends(require_admin)):
    return await _platform()

@api.put("/settings/platform")
async def put_platform(body: dict, admin: dict = Depends(require_admin)):
    p = await _platform()
    upd = {}
    for k in ("app_name", "tagline", "logo_url"):
        if isinstance(body.get(k), str):
            v = body[k].strip()[:60]
            if k == "logo_url":
                if not v or re.fullmatch(r"(?:/uploads/[\w.\-]+|https?://[\w.\-:/]+)", v):
                    upd[k] = v
            elif v:
                upd[k] = v
    for k in ("primary", "accent"):
        v = str(body.get(k) or "").strip().lower()
        if re.fullmatch(r"#[0-9a-f]{6}", v):
            upd[k] = v
    if not upd:
        raise HTTPException(400, "Tidak ada pengaturan valid")
    await db.settings.update_one({"_id": "platform"}, {"$set": upd}, upsert=True)
    out = dict(p)
    out.update(upd)
    return out

@api.post("/settings/platform/logo")
async def upload_platform_logo(file: UploadFile = File(...), admin: dict = Depends(require_admin)):
    ok_types = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "image/gif": ".gif"}
    ext = ok_types.get(file.content_type or "")
    if not ext:
        raise HTTPException(400, "Format logo harus PNG/JPG/WEBP/GIF")
    data = await file.read()
    if len(data) > 2_000_000:
        raise HTTPException(400, "Logo maksimal 2MB")
    fname = f"logo-{new_id()}{ext}"
    (UPLOAD_DIR / fname).write_bytes(data)
    url = f"/uploads/{fname}"
    await db.settings.update_one({"_id": "platform"}, {"$set": {"logo_url": url}}, upsert=True)
    return {"ok": True, "url": url}

# ================================================================== WIDGET KUSTOM DASHBOARD
# Widget buatan admin: kombinasi isian SENDIRI (nilai tetap / isian harian per tanggal)
# dengan data otomatis aplikasi (laporan hari ini) lewat RUMUS sederhana.
# Rumus aman: hanya angka + variabel + operator + - * / % ( ) — tidak ada eval() bebas.
CW_FORMATS = ("rupiah", "jumlah", "persen", "angka")
CW_AUTO_VARS = {
    "penjualan_total":   "Total penjualan (F&B + Retail)",
    "penjualan_fnb":     "Penjualan F&B (dine-in + take-away)",
    "penjualan_retail":  "Penjualan Retail",
    "penjualan_dinein":  "Penjualan dine-in",
    "penjualan_takeaway": "Penjualan take-away",
    "laba_fnb":          "Laba kotor F&B (setelah HPP & bagian vendor)",
    "laba_retail":       "Laba kotor Retail",
    "laba_total":        "Laba kotor total (F&B + Retail)",
    "kas_bersih_fnb":    "Kas bersih laci F&B (tunai − pengeluaran)",
    "kas_bersih_retail": "Kas bersih laci Retail",
    "kas_bersih_total":  "Kas bersih laci total",
    "kas_tunai_fnb":     "Pembayaran tunai F&B",
    "kas_tunai_retail":  "Pembayaran tunai Retail",
    "kas_keluar_fnb":    "Pengeluaran F&B hari ini",
    "kas_keluar_retail": "Pengeluaran Retail hari ini",
    "order_total":       "Jumlah order lunas (semua)",
    "order_dinein":      "Jumlah order dine-in",
    "order_takeaway":    "Jumlah order take-away",
    "order_retail":      "Jumlah order retail",
    "diskon_total":      "Total diskon yang diberikan",
}
CW_AUTO_KEYS = set(CW_AUTO_VARS.keys())
_CW_RE_ID = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

def _cw_tokenize(expr):
    """Token rumus: angka desimal, variabel, operator + - * / % ( )."""
    bad = re.sub(r"[\sA-Za-z0-9_()+\-*/%.]", "", expr)
    if bad:
        raise ValueError(f"Rumus mengandung karakter tidak dikenal: '{bad[:10]}'")
    toks = re.findall(r"\d+\.?\d*|[A-Za-z_][A-Za-z0-9_]*|[()+\-*/%]", expr)
    if not toks:
        raise ValueError("Rumus kosong")
    return toks

def _cw_to_rpn(tokens, allowed):
    """Shunting-yard → notasi postfix. allowed = set kode variabel yang dikenal."""
    out, ops = [], []
    for t in tokens:
        if re.fullmatch(r"\d+\.?\d*", t):
            out.append(("n", float(t)))
        elif _CW_RE_ID.fullmatch(t):
            if t not in allowed:
                raise ValueError(f"Variabel '{t}' tidak dikenal (gunakan kode isian atau data otomatis)")
            out.append(("v", t))
        elif t in ("+", "-", "*", "/", "%"):
            prec = {"+": 1, "-": 1, "*": 2, "/": 2, "%": 2}
            while ops and ops[-1] != "(" and prec[ops[-1]] >= prec[t]:
                out.append(("o", ops.pop()))
            ops.append(t)
        elif t == "(":
            ops.append(t)
        elif t == ")":
            while ops and ops[-1] != "(":
                out.append(("o", ops.pop()))
            if not ops or ops[-1] != "(":
                raise ValueError("Kurung tidak seimbang")
            ops.pop()
    while ops:
        if ops[-1] == "(":
            raise ValueError("Kurung tidak seimbang")
        out.append(("o", ops.pop()))
    return out

def _cw_eval_rpn(rpn, env):
    st = []
    for kind, v in rpn:
        if kind == "n":
            st.append(v)
        elif kind == "v":
            st.append(float(env.get(v, 0) or 0))
        else:
            if len(st) < 2:
                raise ValueError("Rumus tidak valid")
            b, a = st.pop(), st.pop()
            if v == "+":
                st.append(a + b)
            elif v == "-":
                st.append(a - b)
            elif v == "*":
                st.append(a * b)
            elif v == "/":
                if b == 0:
                    raise ValueError("Pembagian dengan nol")
                st.append(a / b)
            elif v == "%":
                if b == 0:
                    raise ValueError("Pembagian dengan nol (operator %)")
                st.append(a % b)
    return st[-1] if st else 0.0

def _cw_parse_formula(formula, field_codes):
    """Validasi rumus → (rpn, refs). refs = kode yang dipakai (auto + isian)."""
    toks = _cw_tokenize(formula)
    allowed = set(field_codes) | CW_AUTO_KEYS
    rpn = _cw_to_rpn(toks, allowed)
    return rpn, sorted({v for k, v in rpn if k == "v"})

def _clean_cw_body(body, allow_empty_formula=False):
    """Bersihkan payload definisi widget kustom; raise HTTPException bila tidak valid."""
    b = body if isinstance(body, dict) else {}
    name = str(b.get("name") or "").strip()
    if not name:
        raise HTTPException(400, "Nama widget wajib diisi")
    if len(name) > 60:
        name = name[:60]
    fmt = str(b.get("format") or "angka")
    if fmt not in CW_FORMATS:
        raise HTTPException(400, "Format hasil tidak valid")
    color = str(b.get("color") or "#E63946")
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
        color = "#E63946"
    enabled = bool(b.get("enabled", True))
    desc = str(b.get("desc") or "").strip()[:240]

    fields, seen = [], set()
    raw_fields = b.get("fields") if isinstance(b.get("fields"), list) else []
    if len(raw_fields) > 30:
        raise HTTPException(400, "Maksimal 30 isian per widget")
    for i, f in enumerate(raw_fields[:30]):
        if not isinstance(f, dict):
            continue
        label = str(f.get("label") or "").strip()
        kind = f.get("kind") if f.get("kind") in ("daily", "fixed") else "daily"
        code = str(f.get("code") or "").strip()
        if not label:
            raise HTTPException(400, f"Isian ke-{i + 1}: label wajib diisi")
        if len(label) > 40:
            label = label[:40]
        if not _CW_RE_ID.fullmatch(code):
            raise HTTPException(400, f"Isian '{label}': kode harus tanpa spasi (huruf/angka/garis bawah)")
        if code in CW_AUTO_KEYS:
            raise HTTPException(400, f"Isian '{label}': kode '{code}' sama dengan variabel otomatis — ganti kode lain")
        if code in seen:
            raise HTTPException(400, f"Kode isian '{code}' dipakai dua kali")
        seen.add(code)
        value = 0.0
        if kind == "fixed":
            try:
                value = round(float(f.get("value") or 0), 2)
            except (TypeError, ValueError):
                raise HTTPException(400, f"Isian tetap '{label}': nilai harus angka")
            if not math.isfinite(value):
                raise HTTPException(400, f"Isian tetap '{label}': nilai tidak valid")
        fields.append({"label": label, "kind": kind, "code": code, "value": value})

    formula = str(b.get("formula") or "").strip()
    if not formula and not allow_empty_formula:
        raise HTTPException(400, "Rumus wajib diisi (contoh: penjualan_fnb + t1 - i1)")
    try:
        rpn, refs = _cw_parse_formula(formula, seen) if formula else ([], [])
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"name": name, "format": fmt, "color": color, "enabled": enabled, "desc": desc,
            "fields": fields, "formula": formula, "refs": refs, "rpn": rpn}

@api.get("/custom-widgets")
async def list_custom_widgets(user: dict = Depends(admin_or_kasir)):
    out = []
    for d in await db.custom_widgets.find({}, {"_id": 0, "rpn": 0}).sort("created_at", 1).to_list(500):
        out.append(d)
    return out

@api.post("/custom-widgets")
async def create_custom_widget(body: dict, admin: dict = Depends(require_admin)):
    clean = _clean_cw_body(body)
    clean.update({"id": new_id(), "created_at": now_utc().isoformat(), "updated_at": now_utc().isoformat()})
    await db.custom_widgets.insert_one(clean)
    clean.pop("rpn", None)
    return clean

@api.put("/custom-widgets/{wid}")
async def update_custom_widget(wid: str, body: dict, admin: dict = Depends(require_admin)):
    cur = await db.custom_widgets.find_one({"id": wid})
    if not cur:
        raise HTTPException(404, "Widget tidak ditemukan")
    clean = _clean_cw_body(body)
    # kode isian yang dihapus → bersihkan nilai harian lama agar tidak tersisa
    old_codes = {f["code"] for f in cur.get("fields", []) if f["kind"] == "daily"}
    new_codes = {f["code"] for f in clean["fields"] if f["kind"] == "daily"}
    gone = old_codes - new_codes
    if gone:
        unset = {f"daily.{c}": "" for c in gone}
        try:
            await db.custom_widget_entries.update_many({"widget_id": wid}, {"$unset": unset})
        except Exception:
            pass
    clean.update({"id": wid, "created_at": cur.get("created_at") or now_utc().isoformat(),
                  "updated_at": now_utc().isoformat()})
    await db.custom_widgets.replace_one({"id": wid}, clean)
    clean.pop("rpn", None)
    return clean

@api.delete("/custom-widgets/{wid}")
async def delete_custom_widget(wid: str, admin: dict = Depends(require_admin)):
    await db.custom_widgets.delete_one({"id": wid})
    await db.custom_widget_entries.delete_many({"widget_id": wid})
    return {"ok": True}

@api.get("/custom-widgets/entries")
async def list_custom_widget_entries(date: str = Query(..., description="YYYY-MM-DD"),
                                     user: dict = Depends(admin_or_kasir)):
    wib_day_range(date)  # validasi format tanggal
    out = {}
    for d in await db.custom_widget_entries.find({"date": date}, {"_id": 0}).to_list(1000):
        out[d["widget_id"]] = {"date": date, "daily": d.get("daily", {})}
    return out

@api.get("/custom-widgets/{wid}/entries")
async def list_widget_entries_history(wid: str, limit: int = Query(30, ge=1, le=200),
                                      user: dict = Depends(admin_or_kasir)):
    """Riwayat isian harian satu widget (tanggal terbaru dulu)."""
    if not await db.custom_widgets.find_one({"id": wid}, {"_id": 0, "id": 1}):
        raise HTTPException(404, "Widget tidak ditemukan")
    docs = []
    async for d in db.custom_widget_entries.find({"widget_id": wid}, {"_id": 0}).sort("date", -1).limit(limit):
        docs.append(d)
    return docs

@api.put("/custom-widgets/entry")
async def put_custom_widget_entry(body: dict, user: dict = Depends(admin_or_kasir)):
    wid = str(body.get("widget_id") or "")
    date = str(body.get("date") or "")
    wib_day_range(date)
    widget = await db.custom_widgets.find_one({"id": wid})
    if not widget:
        raise HTTPException(404, "Widget tidak ditemukan")
    daily_codes = {f["code"] for f in widget.get("fields", []) if f["kind"] == "daily"}
    raw = body.get("daily") if isinstance(body.get("daily"), dict) else {}
    clean = {}
    for k, v in raw.items():
        if k not in daily_codes:
            continue
        try:
            nv = round(float(v), 2)
        except (TypeError, ValueError):
            continue
        if math.isfinite(nv):
            clean[k] = nv
    await db.custom_widget_entries.update_one(
        {"widget_id": wid, "date": date},
        {"$set": {"daily": clean, "updated_at": now_utc().isoformat()}},
        upsert=True)
    return {"widget_id": wid, "date": date, "daily": clean}

# ================================================================== EXCEL
IMPORT_COLUMNS = ["nama_produk", "sku", "kategori", "tipe_produk", "harga", "harga_beli", "status_aktif", "sold_out", "deskripsi", "stok_awal"]

@api.get("/products/template")
async def download_template(user: dict = Depends(get_current_user)):
    import openpyxl
    from openpyxl.styles import Font, PatternFill
    cats = await db.categories.find({}, {"_id": 0, "name": 1, "type": 1}).to_list(500)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Produk"
    ws.append(IMPORT_COLUMNS)
    # Contoh memakai KATEGORI NYATA dari database supaya langsung valid
    ex = []
    by_type = {}
    for c in cats:
        by_type.setdefault(c["type"], []).append(c["name"])
    if by_type.get("makanan"):
        ex.append(["Nasi Goreng Aceh", "FD-001", by_type["makanan"][0], "makanan", 25000, 12000, "aktif", "tidak", "Nasi goreng khas Aceh", 0])
    if by_type.get("minuman"):
        ex.append(["Kopi Sanger", "DR-001", by_type["minuman"][0], "minuman", 15000, 6000, "aktif", "tidak", "Kopi susu khas Aceh", 0])
    if by_type.get("retail"):
        ex.append(["Keripik Pisang", "RT-001", by_type["retail"][0], "retail", 12000, 8000, "aktif", "tidak", "Keripik pisang kemasan", 50])
    if not ex:
        ex = [["Nasi Goreng Aceh", "FD-001", "", "makanan", 25000, 12000, "aktif", "tidak", "Nasi goreng khas Aceh", 0]]
    for row in ex:
        ws.append(row)
    # Styling header
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="E63946")
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 10
    ws.column_dimensions["C"].width = 18
    ws.column_dimensions["D"].width = 12
    ws.column_dimensions["E"].width = 10
    ws.column_dimensions["F"].width = 12
    ws.column_dimensions["G"].width = 13
    ws.column_dimensions["H"].width = 10
    ws.column_dimensions["I"].width = 30
    ws.column_dimensions["J"].width = 10

    # Lembar Petunjuk
    guide = wb.create_sheet("Petunjuk")
    guide.column_dimensions["A"].width = 26
    guide.column_dimensions["B"].width = 60
    guide.append(["Kolom", "Keterangan & Nilai yang Diterima"])
    guide.append(["nama_produk", "Nama produk (wajib)"])
    guide.append(["sku", "Kode SKU unik (wajib)"])
    guide.append(["kategori", "Nama kategori — harus SAMA dengan kategori yang ada di aplikasi. Kategori valid:"])
    for c in cats:
        guide.append(["", f"- {c['name']}  (tipe: {c['type']})"])
    if not cats:
        guide.append(["", "(belum ada kategori — buat dulu di menu Produk & Stok > Kategori)"])
    guide.append(["tipe_produk", "makanan | minuman | retail (harus sesuai tipe kategori)"])
    guide.append(["harga", "Angka (rupiah), contoh: 25000"])
    guide.append(["harga_beli", "Angka HPP/modal (0 untuk produk tanpa HPP)"])
    guide.append(["status_aktif", "aktif | nonaktif (juga diterima: ya/tidak/true/false/1/0)"])
    guide.append(["sold_out", "tidak | ya (tandai produk habis)"])
    guide.append(["deskripsi", "Teks deskripsi (opsional)"])
    guide.append(["stok_awal", "Angka stok (hanya dipakai untuk produk retail)"])
    guide.append([])
    guide.append(["CATATAN", "Hapus baris contoh sebelum mengisi data Anda. Baris yang error tidak akan diimpor; perbaiki lalu ulangi."])
    for cell in guide[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="4F46E5")

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": "attachment; filename=template_produk_gak.xlsx"})

@api.get("/products/export")
async def export_products(admin: dict = Depends(require_admin)):
    import openpyxl
    cats = {c["id"]: c["name"] for c in await db.categories.find({}, {"_id": 0}).to_list(500)}
    products = await db.products.find({}, {"_id": 0}).sort("name", 1).to_list(5000)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Produk"
    ws.append(IMPORT_COLUMNS)
    for p in products:
        ws.append([p["name"], p["sku"], cats.get(p["category_id"], ""), p["type"], p["price"], p.get("cost", 0),
                   "aktif" if p.get("active") else "nonaktif", "ya" if p.get("sold_out") else "tidak",
                   p.get("description", ""), p.get("stock", 0)])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": "attachment; filename=produk_gak.xlsx"})

async def _parse_import(file_bytes):
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(file_bytes), read_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return [], ["File kosong"]
    header = [str(h).strip().lower() if h else "" for h in rows[0]]
    dict_rows = [{header[i]: raw[i] if i < len(raw) else None for i in range(len(header))} for raw in rows[1:]]
    return await _validate_import_rows(dict_rows)

async def _validate_import_rows(dict_rows):
    """Validasi baris import (dari file Excel atau JSON hasil perbaikan) -> parsed."""
    cats = {c["name"].strip().lower(): c for c in await db.categories.find({}, {"_id": 0}).to_list(500)}
    existing_skus = {p["sku"] for p in await db.products.find({}, {"_id": 0, "sku": 1}).to_list(5000)}
    parsed = []
    seen_skus = set()
    for idx, row in enumerate(dict_rows, start=2):
        errors = []
        name = str(row.get("nama_produk") or "").strip()
        sku = str(row.get("sku") or "").strip()
        cat_name = str(row.get("kategori") or "").strip()
        ptype = str(row.get("tipe_produk") or "").strip().lower()
        if not name:
            errors.append("nama produk kosong")
        if not sku:
            errors.append("SKU kosong")
        elif sku in seen_skus:
            errors.append(f"SKU '{sku}' duplikat di file")
        seen_skus.add(sku)
        cat = cats.get(cat_name.lower())
        if not cat:
            errors.append(f"kategori '{cat_name}' tidak valid")
        if ptype not in PRODUCT_TYPES:
            errors.append(f"tipe '{ptype}' tidak valid (makanan/minuman/retail)")
        elif cat and cat["type"] != ptype:
            errors.append(f"tipe produk '{ptype}' tidak sesuai tipe kategori '{cat['type']}'")
        try:
            price = float(row.get("harga") or 0)
            if price < 0:
                errors.append("harga negatif")
        except (ValueError, TypeError):
            price = 0
            errors.append("harga bukan angka")
        try:
            cost = float(row.get("harga_beli") or 0)
            if cost < 0:
                cost = 0
        except (ValueError, TypeError):
            cost = 0
        try:
            stock = int(float(row.get("stok_awal") or 0))
        except (ValueError, TypeError):
            stock = 0
        active = str(row.get("status_aktif") or "aktif").strip().lower() in ("aktif", "aktif ", "ya", "true", "1", "active")
        sold_out = str(row.get("sold_out") or "tidak").strip().lower() in ("ya", "true", "1", "sold out", "soldout")
        parsed.append({
            "row": idx, "name": name, "sku": sku, "category_id": cat["id"] if cat else None,
            "category_name": cat_name, "type": ptype, "price": price, "cost": cost, "stock": stock,
            "description": str(row.get("deskripsi") or ""), "active": active, "sold_out": sold_out,
            "exists": sku in existing_skus, "errors": errors, "valid": len(errors) == 0,
        })
    return parsed, []

@api.post("/products/import/preview")
async def import_preview(file: UploadFile = File(...), admin: dict = Depends(admin_or_input)):
    content = await file.read()
    parsed, file_errors = await _parse_import(content)
    if file_errors:
        raise HTTPException(400, file_errors[0])
    valid = [p for p in parsed if p["valid"]]
    return {"rows": parsed, "total": len(parsed), "valid_count": len(valid),
            "error_count": len(parsed) - len(valid),
            "new_count": len([p for p in valid if not p["exists"]]),
            "update_count": len([p for p in valid if p["exists"]])}

@api.post("/products/import/commit")
async def import_commit(file: UploadFile = File(...), admin: dict = Depends(admin_or_input)):
    content = await file.read()
    parsed, file_errors = await _parse_import(content)
    if file_errors:
        raise HTTPException(400, file_errors[0])
    created = updated = 0
    for p in parsed:
        if not p["valid"]:
            continue
        doc = {"name": p["name"], "sku": p["sku"], "category_id": p["category_id"], "type": p["type"],
               "price": p["price"], "cost": p["cost"], "description": p["description"], "active": p["active"],
               "sold_out": p["sold_out"], "stock": p["stock"], "track_stock": p["type"] == "retail",
               "image": ""}
        if p["exists"]:
            await db.products.update_one({"sku": p["sku"]}, {"$set": doc})
            updated += 1
        else:
            doc.update({"id": new_id(), "created_at": now_utc().isoformat()})
            await db.products.insert_one(doc)
            created += 1
    log = {"id": new_id(), "filename": file.filename, "at": now_utc().isoformat(), "by": admin["name"],
           "created": created, "updated": updated, "errors": len([p for p in parsed if not p["valid"]])}
    await db.import_logs.insert_one(log)
    log.pop("_id", None)
    return log

class ImportRowsFixIn(BaseModel):
    rows: List[dict]

@api.post("/products/import/commit-fix")
async def import_commit_fix(body: ImportRowsFixIn, admin: dict = Depends(admin_or_input)):
    """Commit hasil PERBAIKAN import (JSON) — baris yang diedit user di UI.
    Validasi ulang server-side lalu simpan yang valid."""
    if not body.rows:
        raise HTTPException(400, "Tidak ada baris untuk diimpor")
    parsed, file_errors = await _validate_import_rows(body.rows)
    created = updated = 0
    for p in parsed:
        if not p["valid"]:
            continue
        doc = {"name": p["name"], "sku": p["sku"], "category_id": p["category_id"], "type": p["type"],
               "price": p["price"], "cost": p["cost"], "description": p["description"], "active": p["active"],
               "sold_out": p["sold_out"], "stock": p["stock"], "track_stock": p["type"] == "retail",
               "image": ""}
        if p["exists"]:
            await db.products.update_one({"sku": p["sku"]}, {"$set": doc})
            updated += 1
        else:
            doc.update({"id": new_id(), "created_at": now_utc().isoformat()})
            await db.products.insert_one(doc)
            created += 1
    log = {"id": new_id(), "filename": "perbaikan-import", "at": now_utc().isoformat(), "by": admin["name"],
           "created": created, "updated": updated, "errors": len([p for p in parsed if not p["valid"]])}
    await db.import_logs.insert_one(log)
    _cache_del("products:")
    log.pop("_id", None)
    return log

@api.get("/import-logs")
async def import_logs(admin: dict = Depends(require_admin)):
    return await db.import_logs.find({}, {"_id": 0}).sort("at", -1).to_list(100)

@api.post("/ai/assistant/import-excel")
async def assistant_import_excel(file: UploadFile = File(...), admin: dict = Depends(admin_or_input)):
    """Parse file Excel yang diupload di chat Asisten AI — return baris siap
    commit (commit-fix). Tidak menyimpan apa pun sampai admin klik Terapkan."""
    content = await file.read()
    if len(content) > 5_000_000:
        raise HTTPException(400, "File terlalu besar (maks 5MB)")
    parsed, file_errors = await _parse_import(content)
    if file_errors:
        raise HTTPException(400, file_errors[0])
    rows = [{
        "nama_produk": p["name"], "sku": p["sku"], "kategori": p.get("category_name") or "",
        "tipe_produk": p["type"], "harga": p["price"], "harga_beli": p["cost"],
        "exists": p["exists"], "errors": p["errors"], "valid": p["valid"],
    } for p in parsed]
    return {
        "rows": rows, "total": len(rows),
        "valid_count": sum(1 for r in rows if r["valid"]),
        "error_count": sum(1 for r in rows if not r["valid"]),
        "new_count": sum(1 for r in rows if r["valid"] and not r["exists"]),
        "update_count": sum(1 for r in rows if r["valid"] and r["exists"]),
    }

# ================================================================== FITUR & INTEGRASI (admin, tanpa deploy)
# Dokumentasi: docs/ANALISIS-FITUR-PRIORITAS.md bagian 2.
@api.get("/settings/features")
async def get_features(user: dict = Depends(get_current_user)):
    """Daftar feature flag (dibaca frontend utk menyembunyikan menu/tombol)."""
    return await _features()

@api.put("/settings/features")
async def put_features(body: dict, admin: dict = Depends(require_admin)):
    """Simpan feature flag. Hanya terima struktur & tipe yang cocok dgn default."""
    def clean(base, over):
        out = {}
        for k, dval in (base or {}).items():
            if k not in (over or {}):
                continue
            v = over[k]
            if isinstance(dval, bool) and isinstance(v, bool):
                out[k] = v
            elif isinstance(dval, dict) and isinstance(v, dict):
                sub = clean(dval, v)
                if sub:
                    out[k] = sub
            elif isinstance(dval, (int, float)) and isinstance(v, (int, float)) and not isinstance(v, bool):
                out[k] = v
        return out
    cleaned = clean(FEATURE_DEFAULTS, body or {})
    if not cleaned:
        raise HTTPException(400, "Tidak ada pengaturan valid")
    await db.settings.update_one({"_id": "features"}, {"$set": cleaned}, upsert=True)
    await _invalidate_features()
    return await _features()

class WebhookIn(BaseModel):
    enabled: bool = False
    url: str = ""
    secret: str = ""          # kosong => biarkan secret lama tetap
    events: List[str] = []    # order.paid | shift.closed | test

@api.get("/settings/webhook")
async def get_webhook(admin: dict = Depends(require_admin)):
    cfg = await _webhook_cfg()
    return {"enabled": cfg["enabled"], "url": cfg["url"],
            "secret_set": bool(cfg.get("secret")), "events": cfg.get("events") or [],
            "last": cfg.get("last")}

@api.put("/settings/webhook")
async def put_webhook(body: WebhookIn, admin: dict = Depends(require_admin)):
    url = (body.url or "").strip()
    if body.enabled and not (url.startswith("https://") or url.startswith("http://")):
        raise HTTPException(400, "URL webhook tidak valid (harus http/https)")
    upd = {"enabled": body.enabled, "url": url,
           "events": [e for e in body.events if e in ("order.paid", "shift.closed", "test")]}
    if (body.secret or "").strip():
        upd["secret"] = body.secret.strip()
    await db.settings.update_one({"_id": "webhook"}, {"$set": upd}, upsert=True)
    return {"ok": True}

@api.post("/settings/webhook/test")
async def test_webhook(admin: dict = Depends(require_admin)):
    cfg = await _webhook_cfg()
    if not (cfg.get("url") or "").strip():
        raise HTTPException(400, "Isi URL webhook terlebih dahulu")
    await _fire_webhook("test", {"message": "Uji webhook dari Grand Aceh Kuliner POS"}, force=True)
    return {"ok": True}

@api.get("/admin/orphan-check")
async def orphan_status(admin: dict = Depends(require_admin)):
    doc = await db.settings.find_one({"_id": "orphan"}, {"_id": 0}) or {}
    hour = int(await _feat("maint.orphan_hour", 4))
    day = int(await _feat("maint.orphan_day", 6))
    nama_hari = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
    return {"last": doc.get("last"), "auto": await _feat("maint.orphan_auto"),
            "schedule": f"{nama_hari[day % 7]} {hour:02d}:00 WIB"}

@api.post("/admin/orphan-check")
async def orphan_run(admin: dict = Depends(require_admin)):
    """Jalankan pemeriksaan data yatim sekarang (read-only)."""
    return await _run_orphan_check()

@api.get("/admin/metrics")
async def admin_metrics(admin: dict = Depends(require_admin)):
    """Statistik performa endpoint (dikumpulkan middleware bila dbg.metrics ON)."""
    m = _METRICS
    total = m["total"] or 1
    return {
        "total": m["total"], "errors": m["errors"],
        "error_rate": round(m["errors"] / total * 100, 2) if m["total"] else 0,
        "avg_ms": round(m["total_ms"] / total, 1) if m["total"] else 0,
        "by_path": [{"path": k, "count": v["count"], "avg_ms": round(v["ms"] / v["count"], 1),
                     "errors": v["errors"]} for k, v in sorted(m["by_path"].items(), key=lambda x: -x[1]["count"])],
        "slow": list(m["slow"]),
        "breakers": _breaker_status(),
        "cache_entries": len(_CACHE) + len(_RCACHE),
        "uptime_s": round(__import__("time").time() - _PROC_START, 1),
    }

# ------------------------------------------------------------------ indexes
async def _ensure_indexes():
    """Indeks MongoDB untuk kolom yang sering dipakai pencarian/query.

    create_index() idempotent: dipanggil tiap startup, tanpa efek bila indeks
    sudah ada. Indeks UNIK dibungkus try/except — bila data lama mengandung
    duplikat (mis. order_number, kode kupon), cukup diberi warning dan startup
    tetap lanjut; bersihkan duplikatnya lalu restart agar indeks terpasang.
    Catatan rancangan lengkap: docs/INDEKS-DATABASE.md di root repo."""
    async def _mk(coll, keys, unique=False, sparse=False):
        try:
            await db[coll].create_index(keys, unique=unique, sparse=sparse)
        except Exception as e:
            logger.warning(f"index {coll} {keys} not applied (resolve duplicates?): {e}")

    # ---- orders (koleksi terbesar & terpanas) --------------------------------
    # Setiap muat dashboard/laporan menscan order lunas per rentang tanggal
    # (report_summary, /reports/range, /reports/period, _vendor_report,
    # /reports/profit, rekomendasi stok) → (status, created_at) wajib ada.
    await _mk("orders", "order_number", unique=True)              # 1 order = 1 nomor
    await _mk("orders", "client_ref", unique=True, sparse=True)   # idempotensi sync offline
    await _mk("orders", "payment_ref", unique=True, sparse=True)  # idempotensi pembayaran (retry)
    await _mk("orders", "id", unique=True)                        # get/pay/void/split/merge per id
    await _mk("orders", [("status", 1), ("created_at", -1)])      # laporan: status paid + rentang tanggal
    await _mk("orders", [("order_type", 1), ("status", 1)])       # open bill dine-in (peta meja)
    await _mk("orders", [("table_id", 1), ("status", 1)])         # cek open bill / validasi meja
    await _mk("orders", [("shift_id", 1), ("status", 1)])         # laporan & preview shift
    await _mk("orders", [("created_at", -1)])                     # urutan default daftar order

    # ---- products ------------------------------------------------------------
    # find_one({"id"}) dipanggil per BARIS item saat buat/ubah order & faktur.
    await _mk("products", "sku", unique=True)
    await _mk("products", "id", unique=True)
    await _mk("products", [("type", 1), ("active", 1)])           # daftar per tipe / aktif saja
    await _mk("products", "category_id")                          # cek pemakaian kategori

    # ---- master kecil yang dibaca per-id hampir di tiap transaksi -------------
    for c in ("users", "categories", "vendors", "tables", "payment_methods",
              "members", "promos", "coupons", "shifts", "reservations"):
        await _mk(c, "id", unique=True)
    await _mk("users", "username", unique=True)                   # login (akun tanpa email)
    await _mk("users", "email", unique=True, sparse=True)         # login legacy (APK lama)
    await _mk("members", "phone")                                 # lookup member saat bayar
    await _mk("coupons", "code", unique=True)                     # lookup kupon tiap pembayaran
    await _mk("recipes", "product_id", unique=True)               # 1 resep per produk (natural key)
    await _mk("custom_widgets", "id", unique=True)                # definisi widget kustom dashboard
    await _mk("custom_widget_entries", [("widget_id", 1), ("date", 1)])  # isian harian widget kustom
    # ---- bahan baku & daftar belanja ----------------------------------------
    await _mk("ingredients", "name", unique=True)                 # master bahan (1 nama = 1 bahan)
    await _mk("ingredients", "id", unique=True)
    await _mk("ingredient_purchases", [("ingredient_id", 1), ("created_at", -1)])
    await _mk("ingredient_opname", [("ingredient_id", 1), ("created_at", -1)])
    await _mk("shopping_lists", "date", unique=True)              # 1 lembar belanja per tanggal

    # ---- shift: cari shift terbuka kasir dipanggil di hampir tiap aksi POS ----
    await _mk("shifts", [("cashier_id", 1), ("status", 1)])

    # ---- reservasi meja --------------------------------------------------------
    await _mk("reservations", [("date", 1), ("table_id", 1)])     # daftar harian + cek per meja

    # ---- log & inventori: daftar harian selalu filter rentang created_at -------
    await _mk("cash_movements", "created_at")                     # /cash & laporan harian
    await _mk("cash_movements", "shift_id")                       # laporan shift (pengeluaran)
    await _mk("purchases", "created_at")                          # daftar & ringkasan belanja
    await _mk("stock_opname", "created_at")                       # daftar opname per tanggal

# ------------------------------------------------------------------ startup
@app.on_event("startup")
async def startup():
    await _ensure_indexes()
    # ---- MIGRASI akun: email -> username (tanpa email) ----
    # Username diambil dari bagian depan email (mis. admin@grandaceh.com -> admin),
    # dijamin unik. Email tetap disimpan agar APK/bundle versi lama masih bisa login.
    try:
        taken = set()
        migrated = 0
        async for u in db.users.find({}, {"_id": 0, "id": 1, "username": 1, "email": 1}):
            if u.get("username"):
                taken.add(str(u["username"]).lower())
        async for u in db.users.find({}, {"_id": 0, "id": 1, "username": 1, "email": 1}):
            if u.get("username"):
                continue
            src = (u.get("email") or "").split("@")[0] or "user"
            uname = _slug_username(src, taken)
            taken.add(uname)
            await db.users.update_one({"id": u["id"]}, {"$set": {"username": uname}})
            migrated += 1
        if migrated:
            logger.info(f"migrasi username: {migrated} akun")
    except Exception as e:
        logger.warning(f"migrasi username gagal: {e}")

    # ---- MIGRASI: akun role Stok Opname wajib ganti password saat login pertama ----
    # (permintaan pemilik) — hanya akun yang belum punya penanda, jadi perubahan manual
    # di UI/PATCH tidak tertimpa tiap startup.
    try:
        r = await db.users.update_many({"role": "stok_opname", "must_change_password": {"$exists": False}},
                                       {"$set": {"must_change_password": True}})
        if r.modified_count:
            logger.info(f"wajib ganti password (login pertama): {r.modified_count} akun stok_opname")
    except Exception as e:
        logger.warning(f"migrasi wajib-ganti-password gagal: {e}")

    admin_email = os.environ["ADMIN_EMAIL"].lower()
    admin_username = _slug_username(admin_email.split("@")[0])
    admin_pw = os.environ["ADMIN_PASSWORD"]
    existing = await db.users.find_one({"$or": [{"email": admin_email}, {"username": admin_username}]})
    if not existing:
        await db.users.insert_one({"id": new_id(), "name": os.environ.get("ADMIN_NAME", "Admin"),
                                   "username": admin_username, "email": admin_email,
                                   "password_hash": hash_password(admin_pw),
                                   "role": "superadmin", "active": True, "created_at": now_utc().isoformat()})
    else:
        # Akun owner (ADMIN_EMAIL) SELALU dipastikan superadmin — pemilik tidak boleh
        # terkunci dari Pengaturan → Roles & Izin (mis. bila kolom role berubah/terhapus).
        if existing.get("role") != "superadmin":
            await db.users.update_one({"id": existing["id"]},
                                      {"$set": {"role": "superadmin",
                                                "username": existing.get("username") or admin_username}})
            logger.info(f"akun owner {admin_email} dipastikan superadmin (role sebelumnya: {existing.get('role')})")
        elif not existing.get("username"):
            await db.users.update_one({"id": existing["id"]}, {"$set": {"username": admin_username}})
        elif os.environ.get("ADMIN_FORCE_PASSWORD", "0") == "1" and not verify_password(admin_pw, existing["password_hash"]):
            # Ganti password admin TIDAK otomatis di-reset dari env tiap startup (agar ganti password
            # lewat UI bertahan). Set ADMIN_FORCE_PASSWORD=1 bila memang ingin memaksa sinkron dari env.
            await db.users.update_one({"id": existing["id"]}, {"$set": {"password_hash": hash_password(admin_pw)}})
    # seed a cashier
    if not await db.users.find_one({"email": "kasir@grandaceh.com"}):
        await db.users.insert_one({"id": new_id(), "name": "Kasir Satu", "email": "kasir@grandaceh.com",
                                   "password_hash": hash_password("kasir123"), "role": "kasir",
                                   "active": True, "created_at": now_utc().isoformat()})
    # seed payment methods
    if await db.payment_methods.count_documents({}) == 0:
        for n, t in [("Cash", "cash"), ("QRIS", "qris"), ("Kartu Debit/Kredit", "card")]:
            await db.payment_methods.insert_one({"id": new_id(), "name": n, "type": t, "active": True})
    logger.info("Startup seeding complete")

    # Scheduler internal untuk laporan WhatsApp harian (self-hosted; tanpa cron eksternal).
    import asyncio as _asyncio

    async def _report_scheduler():
        while True:
            try:
                await _run_daily_report_job()
            except Exception as e:
                logger.error(f"report scheduler tick failed: {e}")
            try:
                await _maybe_orphan_auto()
            except Exception as e:
                logger.error(f"orphan scheduler tick failed: {e}")
            await _asyncio.sleep(600)  # cek tiap 10 menit
    _asyncio.create_task(_report_scheduler())

@app.on_event("shutdown")
async def shutdown():
    client.close()

app.include_router(api)
app.add_middleware(
    CORSMiddleware,
    allow_credentials=False,
    allow_origins=[o.strip() for o in os.environ.get('CORS_ORIGINS', '*').split(',') if o.strip()],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Private Network Access (PNA): Chrome/WebView memblokir panggilan cross-origin ke
# IP privat (LAN 192.168.x / tailnet 100.x) bila respons tidak menyertakan
# Access-Control-Allow-Private-Network: true. Middleware ini dipasang PALING LUAR
# (setelah CORSMiddleware) sehingga menambah header ke SEMUA respons, termasuk
# preflight OPTIONS yang ditangani CORSMiddleware.
from starlette.middleware.base import BaseHTTPMiddleware

class PrivateNetworkAccessMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        try:
            response.headers["Access-Control-Allow-Private-Network"] = "true"
        except Exception:
            pass
        return response

app.add_middleware(PrivateNetworkAccessMiddleware)

# Kompres gzip utk respons JSON besar (katalog, laporan) — menghemat bandwidth APK/Internet.
from starlette.middleware.gzip import GZipMiddleware
app.add_middleware(GZipMiddleware, minimum_size=1024)

# Metrik performa endpoint & slow query log (lihat /api/admin/metrics).
# Dikumpulkan bila dbg.metrics ON; overhead ~0,1-0,5% per request.
class MetricsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        import time as _t
        # OPTIONS = preflight CORS dari browser, bukan panggilan API — tidak dihitung
        # supaya statistik (jumlah/rata-rata/lambat) mencerminkan request bisnis.
        if (request.method or "").upper() == "OPTIONS":
            return await call_next(request)
        t0 = _t.time()
        try:
            response = await call_next(request)
        except Exception:
            try:
                if await _feat("dbg.metrics"):
                    _metric_record(request.method, request.url.path, (_t.time() - t0) * 1000, 500)
            except Exception:
                pass
            raise
        ms = (_t.time() - t0) * 1000
        try:
            if await _feat("dbg.metrics"):
                _metric_record(request.method, request.url.path, ms, response.status_code)
            await _record_slow_if_needed(request.method, request.url.path, ms)
        except Exception:
            pass
        return response

app.add_middleware(MetricsMiddleware)
