import { Navigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Loader2 } from "lucide-react";
import { can } from "@/lib/rbac";
import ForceChangePassword from "@/components/ForceChangePassword";

export const homeFor = (role) =>
  role === "admin" ? "/dashboard" : role === "input" ? "/products" : "/pos";

export default function ProtectedRoute({ children, roles, mod }) {
  const { user, loading } = useAuth();
  if (loading)
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader2 className="animate-spin text-[#E63946]" size={40} />
      </div>
    );
  if (!user) return <Navigate to="/login" replace />;
  // Wajib ganti password (akun baru / role Stok Opname, atau setelah direset admin):
  // semua halaman ditahan sampai password diganti.
  if (user.must_change_password) return <ForceChangePassword />;
  const roleOk = !roles || roles.includes(user.role) || (mod && (Array.isArray(mod) ? mod.some((m) => can(user, m)) : can(user, mod)));
  if (!roleOk) return <Navigate to={homeFor(user.role)} replace />;
  return children;
}
