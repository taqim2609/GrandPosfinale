import { useEffect, useState } from "react";
import { toast } from "sonner";
import { SlidersHorizontal, Save, Loader2, Store, Receipt, Users, BadgePercent, AlertTriangle, Percent, Tag } from "lucide-react";
import api, { apiError } from "@/lib/api";
import { BIZ_DEFAULTS, loadBusiness } from "@/lib/business";

// Pengaturan Aplikasi — nilai usaha yang bisa diubah admin TANPA mengubah kode.
// Disimpan di server (settings _id:"business"); dibaca backend & perangkat.

export default function SettingsBusiness() {
  const [f, setF] = useState(null);
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));

  useEffect(() => {
    loadBusiness().then((b) => setF({ ...BIZ_DEFAULTS, ...b, labels: { ...BIZ_DEFAULTS.labels, ...((b && b.labels) || {}) } }));
  }, []);

  const save = async () => {
    if (!f) return;
    setSaving(true);
    try {
      const { data } = await api.put("/settings/business", {
        labels: { fnb: (f.labels?.fnb || "").trim() || "F&B", retail: (f.labels?.retail || "").trim() || "Retail" },
        order_prefix: (f.order_prefix || "").trim() || "GAK-",
        discount_reason_percent: Number(f.discount_reason_percent || 0),
        discount_reason_amount: Number(f.discount_reason_amount || 0),
        member_earn_per_rupiah: Math.max(1, Number(f.member_earn_per_rupiah || 10000)),
        member_redeem_per_point: Math.max(1, Number(f.member_redeem_per_point || 100)),
        low_stock_threshold: Math.max(1, Number(f.low_stock_threshold || 10)),
        service_tax_percent: Math.max(0, Math.min(100, Number(f.service_tax_percent || 0))),
      });
      setF({ ...BIZ_DEFAULTS, ...data, labels: { ...BIZ_DEFAULTS.labels, ...(data?.labels || {}) } });
      try { localStorage.setItem("gak_biz_cache", JSON.stringify({ ...BIZ_DEFAULTS, ...data, labels: { ...BIZ_DEFAULTS.labels, ...(data?.labels || {}) } })); } catch (e) {}
      toast.success("Pengaturan aplikasi disimpan — berlaku langsung di semua perangkat");
    } catch (e) { toast.error(apiError(e.response?.data?.detail)); } finally { setSaving(false); }
  };

  if (!f) return <div className="h-full grid place-items-center"><Loader2 className="animate-spin text-[#E63946]" /></div>;

  const inp = "w-full h-11 px-3 rounded-xl border border-[#E4E4E7] outline-none focus:border-[#E63946] text-sm font-num";
  const Field = ({ label, hint, children }) => (
    <div>
      <label className="text-xs uppercase tracking-wider font-bold text-[#52525B]">{label}</label>
      <div className="mt-1.5">{children}</div>
      {hint && <p className="text-[11px] text-[#a1a1aa] mt-1">{hint}</p>}
    </div>
  );
  const Card = ({ icon: Icon, title, children }) => (
    <div className="rounded-2xl border border-[#E4E4E7] bg-white p-5 space-y-3">
      <div className="flex items-center gap-2 font-extrabold"><Icon size={18} className="text-[#E63946]" /> {title}</div>
      {children}
    </div>
  );

  return (
    <div className="h-full overflow-y-auto p-6 lg:p-8" data-testid="settings-business-page">
      <div className="max-w-2xl mx-auto space-y-5">
        <div>
          <h1 className="text-2xl font-extrabold flex items-center gap-2"><SlidersHorizontal className="text-[#E63946]" /> Pengaturan Aplikasi</h1>
          <p className="text-[#52525B] text-sm mt-1">Ubah perilaku usaha tanpa mengubah kode. Perubahan berlaku langsung di server & semua perangkat.</p>
        </div>

        <Card icon={Store} title="Label & Identitas">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Nama Toko F&B" hint="Label untuk alur makan di tempat / bawa pulang">
              <input data-testid="biz-label-fnb" value={f.labels?.fnb || ""} onChange={(e) => setF({ ...f, labels: { ...f.labels, fnb: e.target.value } })} className={inp} />
            </Field>
            <Field label="Nama Toko Retail" hint="Label untuk alur produk retail">
              <input data-testid="biz-label-retail" value={f.labels?.retail || ""} onChange={(e) => setF({ ...f, labels: { ...f.labels, retail: e.target.value } })} className={inp} />
            </Field>
          </div>
          <Field label="Prefiks Nomor Order" hint="Dipakai untuk nomor struk, contoh: GAK-20260908-0001">
            <input data-testid="biz-order-prefix" value={f.order_prefix || ""} onChange={(e) => set("order_prefix", e.target.value)} className={`${inp} max-w-[180px]`} />
          </Field>
        </Card>

        <Card icon={BadgePercent} title="Diskon">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Alasan wajib jika diskon % di atas" hint="0 = tidak pernah wajib">
              <input data-testid="biz-disc-pct" type="number" min="0" max="100" value={f.discount_reason_percent} onChange={(e) => set("discount_reason_percent", e.target.value)} className={inp} />
            </Field>
            <Field label="Alasan wajib jika diskon Rp di atas">
              <input data-testid="biz-disc-amt" type="number" min="0" value={f.discount_reason_amount} onChange={(e) => set("discount_reason_amount", e.target.value)} className={inp} />
            </Field>
          </div>
          <p className="text-[11px] text-[#a1a1aa]">Diskon % bisa hingga 100% (gratis). HPP &amp; bagi hasil vendor tetap dihitung penuh — diskon ditanggung outlet.</p>
        </Card>

        <Card icon={Users} title="Member & Poin">
          <div className="grid grid-cols-2 gap-3">
            <Field label="1 poin per belanja Rp">
              <input data-testid="biz-point-earn" type="number" min="1" value={f.member_earn_per_rupiah} onChange={(e) => set("member_earn_per_rupiah", e.target.value)} className={inp} />
            </Field>
            <Field label="Nilai tukar 1 poin (Rp)">
              <input data-testid="biz-point-redeem" type="number" min="1" value={f.member_redeem_per_point} onChange={(e) => set("member_redeem_per_point", e.target.value)} className={inp} />
            </Field>
          </div>
        </Card>

        <Card icon={Percent} title="Pajak Layanan (Opsional)">
          <Field label="Tarif pajak layanan (%)" hint="0 = nonaktif. Dikenakan di atas total bersih (setelah semua diskon) dan ditambahkan ke total struk.">
            <input data-testid="biz-service-tax" type="number" min="0" max="100" step="0.5" value={f.service_tax_percent} onChange={(e) => set("service_tax_percent", e.target.value)} className={`${inp} max-w-[180px]`} />
          </Field>
        </Card>

        <Card icon={AlertTriangle} title="Stok & Peringatan">
          <Field label="Ambang stok menipis (default jika produk tanpa min_stock)">
            <input data-testid="biz-lowstock" type="number" min="1" value={f.low_stock_threshold} onChange={(e) => set("low_stock_threshold", e.target.value)} className={`${inp} max-w-[180px]`} />
          </Field>
        </Card>

        <button data-testid="biz-save" onClick={save} disabled={saving}
          className="tap w-full h-12 rounded-xl bg-[#E63946] hover:bg-[#BE123C] text-white font-bold flex items-center justify-center gap-2 disabled:opacity-60">
          {saving ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />} Simpan Pengaturan Aplikasi
        </button>
      </div>
    </div>
  );
}
