import { useState } from "react";
import UsersPage from "@/pages/Users";
import Tables from "@/pages/Tables";
import SettingsAI from "@/pages/SettingsAI";
import SettingsData from "@/pages/SettingsData";
import SettingsBusiness from "@/pages/SettingsBusiness";
import SettingsReport from "@/pages/SettingsReport";
import SettingsInstaller from "@/pages/SettingsInstaller";
import SettingsIntegrations from "@/pages/SettingsIntegrations";
import SettingsCustomWidgets from "@/pages/SettingsCustomWidgets";
import SettingsPlatform from "@/pages/SettingsPlatform";
import SettingsUI from "@/pages/SettingsUI";
import SettingsRoles from "@/pages/SettingsRoles";
import WhatsAppReport from "@/pages/WhatsAppReport";
import DeviceSettings from "@/pages/DeviceSettings";
import Diagnostik from "@/pages/Diagnostik";
import AppVersi from "@/pages/AppVersi";
import SubTabs from "@/components/SubTabs";
import ErrorBoundary from "@/components/ErrorBoundary";
import {
  Users, Armchair, Sparkles, Trash2, MessageCircle, Download, Printer, Bug, Box,
  Settings2, SlidersHorizontal, LayoutGrid, Palette, ShieldCheck, LayoutTemplate, Gauge,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";

/* ---------------- Pengguna (Pengguna | Roles & Izin) ---------------- */
function UsersTab({ canRoles }) {
  const items = [{ key: "accounts", label: "Akun Pengguna", icon: Users, comp: UsersPage }];
  if (canRoles) items.push({ key: "roles", label: "Roles & Izin", icon: ShieldCheck, comp: SettingsRoles });
  return <SubTabs items={items} testid="users-subtab" />;
}

/* ------------- Platform & Tampilan (Identitas & Warna | Menu & Urutan) ------------- */
function PlatformTab() {
  return (
    <SubTabs
      items={[
        { key: "identity", label: "Identitas & Warna", icon: Palette, comp: SettingsPlatform },
        { key: "menu", label: "Menu & Tampilan UI", icon: LayoutTemplate, comp: SettingsUI },
      ]}
      testid="platform-subtab"
    />
  );
}

/* ------------- Fitur & Integrasi (Fitur | Diagnostik) ------------- */
function IntegrationsTab() {
  return (
    <SubTabs
      items={[
        { key: "fitur", label: "Fitur & Integrasi", icon: SlidersHorizontal, comp: SettingsIntegrations },
        { key: "diagnostik", label: "Diagnostik", icon: Bug, comp: Diagnostik },
      ]}
      testid="fitur-subtab"
    />
  );
}

const TABS = [
  { key: "users", label: "Pengguna", icon: Users, comp: UsersTab, needsRoles: true },
  { key: "app", label: "Aplikasi", icon: Settings2, comp: SettingsBusiness },
  { key: "widget", label: "Widget Kustom", icon: LayoutGrid, comp: SettingsCustomWidgets },
  { key: "platform", label: "Platform & Tampilan", icon: Palette, comp: PlatformTab },
  { key: "tables", label: "Meja", icon: Armchair, comp: Tables },
  { key: "device", label: "Perangkat", icon: Printer, comp: DeviceSettings },
  { key: "fitur", label: "Fitur & Integrasi", icon: SlidersHorizontal, comp: IntegrationsTab },
  { key: "ai", label: "Pengaturan AI", icon: Sparkles, comp: SettingsAI },
  { key: "wa", label: "WhatsApp & Laporan", icon: MessageCircle, comp: WhatsAppReport },
  { key: "installer", label: "Installer", icon: Download, comp: SettingsInstaller },
  { key: "versi", label: "Versi", icon: Box, comp: AppVersi },
  { key: "data", label: "Reset Data", icon: Trash2, comp: SettingsData },
];

// tab lama yang kini jadi SUB-TAB (agar tautan/bookmark lama tetap bekerja)
const LEGACY_TAB_MAP = { roles: "users", ui: "platform", diagnostik: "fitur" };

function initialTab() {
  try {
    const t = new URLSearchParams(window.location.search).get("tab");
    const mapped = LEGACY_TAB_MAP[t] || t;
    if (TABS.some((x) => x.key === mapped)) return mapped;
  } catch (e) {}
  return "users";
}

export default function Settings() {
  const { user } = useAuth();
  const isSuper = !!user?.is_superadmin;
  // bootstrap_owner: belum ada Super Admin sama sekali → admin boleh masuk utk mengangkat owner
  const canRoles = isSuper || !!user?.bootstrap_owner;
  const visibleTabs = TABS;
  const [tab, setTab] = useState(initialTab);
  const active = visibleTabs.find((t) => t.key === tab) || visibleTabs[0];
  const Active = active.comp;

  return (
    <div className="h-full flex flex-col">
      <div className="px-8 pt-6 bg-white border-b">
        <h1 className="text-3xl font-extrabold mb-4">Pengaturan</h1>
        <div className="flex gap-1 flex-wrap">
          {visibleTabs.map((t) => (
            <button
              key={t.key}
              data-testid={`settings-tab-${t.key}`}
              onClick={() => setTab(t.key)}
              className={`tap px-4 h-11 rounded-t-lg font-bold text-sm flex items-center gap-2 border-b-2 -mb-px ${
                tab === t.key ? "border-[#E63946] text-[#E63946]" : "border-transparent text-[#52525B] hover:text-[#0A0A0A]"
              }`}
            >
              <t.icon size={16} /> {t.label}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-hidden">
        <ErrorBoundary key={tab}>
          {active.needsRoles ? <Active canRoles={canRoles} /> : <Active />}
        </ErrorBoundary>
      </div>
    </div>
  );
}
