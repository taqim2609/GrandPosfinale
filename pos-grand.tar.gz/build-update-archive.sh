#!/usr/bin/env bash
# Bangun artefak Update Center (vibecoder.co.id) dari isi git.
#
# Menghasilkan, di folder Update Center (bawaan ../pos-grand-update):
#   pos-grand.tar.gz  -> arsip berkompresi (dipakai update-vibecoder-pi.sh di server)
#   pos-grand.tar     -> arsip TANPA kompresi (untuk dibaca / diambil sebagian)
#   version.json      -> versi (hash commit) + waktu + jumlah berkas
#
# Berkas .env, backend/.env.docker, backups/ dan .git TIDAK ikut karena arsip
# dibangun dari `git ls-files` (hanya berkas yang di-track).
#
# Pakai:  ./build-update-archive.sh [folder-tujuan]
set -euo pipefail
cd "$(dirname "$0")"

OUT="${1:-../pos-grand-update}"
mkdir -p "$OUT"
OUT="$(cd "$OUT" && pwd)"

VER="$(git rev-parse --short HEAD)"
if [ -n "$(git status --porcelain)" ]; then
  echo "PERINGATAN: masih ada perubahan yang belum di-commit."
  echo "Arsip diambil dari BERKAS DI DISK — commit dulu bila ingin arsip = commit ini:"
  git status --short | sed 's/^/  /'
  echo
fi

N="$(git ls-files | wc -l | tr -d ' ')"

# Arsip dibangun dari daftar berkas git (null-separated) -> aman untuk nama ber-spasi.
git ls-files -z | tar --null --format=ustar -cf "$OUT/pos-grand.tar" -T -
gzip -9 -c "$OUT/pos-grand.tar" > "$OUT/pos-grand.tar.gz"

cat > "$OUT/version.json" <<EOF
{
  "version": "$VER",
  "url": "pos-grand.tar.gz",
  "url_tar": "pos-grand.tar",
  "files": $N,
  "updated": "$(date -u '+%Y-%m-%d %H:%M:%S') UTC"
}
EOF

echo "Versi    : $VER ($N berkas)"
echo "Tar.gz   : $(du -h "$OUT/pos-grand.tar.gz" | cut -f1)"
echo "Tar      : $(du -h "$OUT/pos-grand.tar" | cut -f1)"
echo "version.json:"
cat "$OUT/version.json"
echo
echo "Langkah berikutnya: terbitkan app 'pos-grand-update' (PublishApp) bila isi landing berubah."
